/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Samara].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Samara":[{"name":"Europe/Samara","_offset":"3:20:36","_rule":"-","format":"LMT","_until":"1919 Jul 1 2:00"},{"name":"Europe/Samara","_offset":"3:00","_rule":"-","format":"SAMT","_until":"1930 Jun 21"},{"name":"Europe/Samara","_offset":"4:00","_rule":"-","format":"SAMT","_until":"1935 Jan 27"},{"name":"Europe/Samara","_offset":"4:00","_rule":"Russia","format":"KUY%sT","_until":"1989 Mar 26 2:00s"},{"name":"Europe/Samara","_offset":"3:00","_rule":"Russia","format":"KUY%sT","_until":"1991 Mar 31 2:00s"},{"name":"Europe/Samara","_offset":"2:00","_rule":"Russia","format":"KUY%sT","_until":"1991 Sep 29 2:00s"},{"name":"Europe/Samara","_offset":"3:00","_rule":"-","format":"KUYT","_until":"1991 Oct 20 3:00"},{"name":"Europe/Samara","_offset":"4:00","_rule":"Russia","format":"SAM%sT","_until":"2010 Mar 28 2:00s"},{"name":"Europe/Samara","_offset":"3:00","_rule":"Russia","format":"SAM%sT","_until":"2011 Mar 27 2:00s"},{"name":"Europe/Samara","_offset":"4:00","_rule":"-","format":"SAMT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);