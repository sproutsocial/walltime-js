/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Rothera].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/Rothera":[{"name":"Antarctica/Rothera","_offset":"0","_rule":"-","format":"zzz","_until":"1976 Dec 1"},{"name":"Antarctica/Rothera","_offset":"-3:00","_rule":"-","format":"ROTT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);