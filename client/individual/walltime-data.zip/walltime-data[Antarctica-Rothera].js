(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Rothera":[{"name":"Antarctica/Rothera","_offset":"0","_rule":"-","format":"zzz","_until":"1976 Dec 1"},{"name":"Antarctica/Rothera","_offset":"-3:00","_rule":"-","format":"ROTT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);