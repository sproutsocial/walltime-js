(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Rothera":[{"name":"Antarctica/Rothera","_offset":"0","_rule":"-","format":"zzz","_until":"1976 Dec 1","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1976-11-30T23:59:59.999Z"}},{"name":"Antarctica/Rothera","_offset":"-3:00","_rule":"-","format":"ROTT","_until":"","offset":{"negative":true,"hours":3,"mins":0,"secs":0},"range":{"begin":"1976-12-01T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);