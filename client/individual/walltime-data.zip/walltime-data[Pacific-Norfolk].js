/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Norfolk":[{"name":"Pacific/Norfolk","_offset":"11:11:52","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Norfolk","_offset":"11:12","_rule":"-","format":"NMT","_until":"1951"},{"name":"Pacific/Norfolk","_offset":"11:30","_rule":"-","format":"NFT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);