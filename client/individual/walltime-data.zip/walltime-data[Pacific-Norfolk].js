(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Norfolk":[{"name":"Pacific/Norfolk","_offset":"11:11:52","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":11,"mins":11,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T11:11:51.999Z"}},{"name":"Pacific/Norfolk","_offset":"11:12","_rule":"-","format":"NMT","_until":"1951","offset":{"negative":false,"hours":11,"mins":12,"secs":0},"range":{"begin":"1900-12-31T11:11:52.000Z","end":"1950-12-31T11:11:59.999Z"}},{"name":"Pacific/Norfolk","_offset":"11:30","_rule":"-","format":"NFT","_until":"","offset":{"negative":false,"hours":11,"mins":30,"secs":0},"range":{"begin":"1950-12-31T11:12:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);