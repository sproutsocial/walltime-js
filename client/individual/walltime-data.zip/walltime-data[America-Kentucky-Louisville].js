/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Kentucky-Louisville].js
    
    var tzData = {
        rules: {},
        zones: {"America/Kentucky/Louisville":[{"name":"America/Kentucky/Louisville","_offset":"-5:43:02","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:16:58"},{"name":"America/Kentucky/Louisville","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1921"},{"name":"America/Kentucky/Louisville","_offset":"-6:00","_rule":"Louisville","format":"C%sT","_until":"1942"},{"name":"America/Kentucky/Louisville","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1946"},{"name":"America/Kentucky/Louisville","_offset":"-6:00","_rule":"Louisville","format":"C%sT","_until":"1961 Jul 23 2:00"},{"name":"America/Kentucky/Louisville","_offset":"-5:00","_rule":"-","format":"EST","_until":"1968"},{"name":"America/Kentucky/Louisville","_offset":"-5:00","_rule":"US","format":"E%sT","_until":"1974 Jan 6 2:00"},{"name":"America/Kentucky/Louisville","_offset":"-6:00","_rule":"1:00","format":"CDT","_until":"1974 Oct 27 2:00"},{"name":"America/Kentucky/Louisville","_offset":"-5:00","_rule":"US","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);