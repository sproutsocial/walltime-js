/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Campo_Grande].js
    
    var tzData = {
        rules: {},
        zones: {"America/Campo_Grande":[{"name":"America/Campo_Grande","_offset":"-3:38:28","_rule":"-","format":"LMT","_until":"1914"},{"name":"America/Campo_Grande","_offset":"-4:00","_rule":"Brazil","format":"AM%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);