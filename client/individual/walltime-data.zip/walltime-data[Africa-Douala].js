(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Douala":[{"name":"Africa/Douala","_offset":"0:38:48","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Douala","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);