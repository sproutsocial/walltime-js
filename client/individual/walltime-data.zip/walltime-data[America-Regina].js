/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Regina].js
    
    var tzData = {
        rules: {},
        zones: {"America/Regina":[{"name":"America/Regina","_offset":"-6:58:36","_rule":"-","format":"LMT","_until":"1905 Sep"},{"name":"America/Regina","_offset":"-7:00","_rule":"Regina","format":"M%sT","_until":"1960 Apr lastSun 2:00"},{"name":"America/Regina","_offset":"-6:00","_rule":"-","format":"CST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);