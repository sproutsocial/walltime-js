/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Budapest].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Budapest":[{"name":"Europe/Budapest","_offset":"1:16:20","_rule":"-","format":"LMT","_until":"1890 Oct"},{"name":"Europe/Budapest","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1918"},{"name":"Europe/Budapest","_offset":"1:00","_rule":"Hungary","format":"CE%sT","_until":"1941 Apr 6 2:00"},{"name":"Europe/Budapest","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945"},{"name":"Europe/Budapest","_offset":"1:00","_rule":"Hungary","format":"CE%sT","_until":"1980 Sep 28 2:00s"},{"name":"Europe/Budapest","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);