/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Hobart].js
    
    var tzData = {
        rules: {},
        zones: {"Australia/Hobart":[{"name":"Australia/Hobart","_offset":"9:49:16","_rule":"-","format":"LMT","_until":"1895 Sep"},{"name":"Australia/Hobart","_offset":"10:00","_rule":"-","format":"EST","_until":"1916 Oct 1 2:00"},{"name":"Australia/Hobart","_offset":"10:00","_rule":"1:00","format":"EST","_until":"1917 Feb"},{"name":"Australia/Hobart","_offset":"10:00","_rule":"Aus","format":"EST","_until":"1967"},{"name":"Australia/Hobart","_offset":"10:00","_rule":"AT","format":"EST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);