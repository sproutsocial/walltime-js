/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Glace_Bay].js
    
    var tzData = {
        rules: {},
        zones: {"America/Glace_Bay":[{"name":"America/Glace_Bay","_offset":"-3:59:48","_rule":"-","format":"LMT","_until":"1902 Jun 15"},{"name":"America/Glace_Bay","_offset":"-4:00","_rule":"Canada","format":"A%sT","_until":"1953"},{"name":"America/Glace_Bay","_offset":"-4:00","_rule":"Halifax","format":"A%sT","_until":"1954"},{"name":"America/Glace_Bay","_offset":"-4:00","_rule":"-","format":"AST","_until":"1972"},{"name":"America/Glace_Bay","_offset":"-4:00","_rule":"Halifax","format":"A%sT","_until":"1974"},{"name":"America/Glace_Bay","_offset":"-4:00","_rule":"Canada","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);