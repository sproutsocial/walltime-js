(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-3":[{"name":"Etc/GMT-3","_offset":"3","_rule":"-","format":"GMT-3","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);