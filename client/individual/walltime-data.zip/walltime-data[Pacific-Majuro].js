(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Majuro":[{"name":"Pacific/Majuro","_offset":"11:24:48","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Majuro","_offset":"11:00","_rule":"-","format":"MHT","_until":"1969 Oct"},{"name":"Pacific/Majuro","_offset":"12:00","_rule":"-","format":"MHT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);