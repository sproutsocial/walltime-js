(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Majuro":[{"name":"Pacific/Majuro","_offset":"11:24:48","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":11,"mins":24,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T11:24:47.999Z"}},{"name":"Pacific/Majuro","_offset":"11:00","_rule":"-","format":"MHT","_until":"1969 Oct","offset":{"negative":false,"hours":11,"mins":0,"secs":0},"range":{"begin":"1900-12-31T11:24:48.000Z","end":"1969-09-30T10:59:59.999Z"}},{"name":"Pacific/Majuro","_offset":"12:00","_rule":"-","format":"MHT","_until":"","offset":{"negative":false,"hours":12,"mins":0,"secs":0},"range":{"begin":"1969-09-30T11:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);