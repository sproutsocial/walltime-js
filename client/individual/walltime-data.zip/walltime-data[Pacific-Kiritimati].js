/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kiritimati":[{"name":"Pacific/Kiritimati","_offset":"-10:29:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Kiritimati","_offset":"-10:40","_rule":"-","format":"LINT","_until":"1979 Oct"},{"name":"Pacific/Kiritimati","_offset":"-10:00","_rule":"-","format":"LINT","_until":"1995"},{"name":"Pacific/Kiritimati","_offset":"14:00","_rule":"-","format":"LINT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);