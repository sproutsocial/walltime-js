(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kiritimati":[{"name":"Pacific/Kiritimati","_offset":"-10:29:20","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":true,"hours":10,"mins":29,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-30T13:30:39.999Z"}},{"name":"Pacific/Kiritimati","_offset":"-10:40","_rule":"-","format":"LINT","_until":"1979 Oct","offset":{"negative":true,"hours":10,"mins":40,"secs":0},"range":{"begin":"1900-12-30T13:30:40.000Z","end":"1979-09-29T13:19:59.999Z"}},{"name":"Pacific/Kiritimati","_offset":"-10:00","_rule":"-","format":"LINT","_until":"1995","offset":{"negative":true,"hours":10,"mins":0,"secs":0},"range":{"begin":"1979-09-29T13:20:00.000Z","end":"1994-12-30T13:59:59.999Z"}},{"name":"Pacific/Kiritimati","_offset":"14:00","_rule":"-","format":"LINT","_until":"","offset":{"negative":false,"hours":14,"mins":0,"secs":0},"range":{"begin":"1994-12-30T14:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);