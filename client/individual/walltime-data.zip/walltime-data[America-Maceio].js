/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Maceio].js
    
    var tzData = {
        rules: {},
        zones: {"America/Maceio":[{"name":"America/Maceio","_offset":"-2:22:52","_rule":"-","format":"LMT","_until":"1914"},{"name":"America/Maceio","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"1990 Sep 17"},{"name":"America/Maceio","_offset":"-3:00","_rule":"-","format":"BRT","_until":"1995 Oct 13"},{"name":"America/Maceio","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"1996 Sep 4"},{"name":"America/Maceio","_offset":"-3:00","_rule":"-","format":"BRT","_until":"1999 Sep 30"},{"name":"America/Maceio","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"2000 Oct 22"},{"name":"America/Maceio","_offset":"-3:00","_rule":"-","format":"BRT","_until":"2001 Sep 13"},{"name":"America/Maceio","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"2002 Oct 1"},{"name":"America/Maceio","_offset":"-3:00","_rule":"-","format":"BRT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);