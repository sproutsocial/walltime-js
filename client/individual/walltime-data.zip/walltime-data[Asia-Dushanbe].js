/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Dushanbe].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Dushanbe":[{"name":"Asia/Dushanbe","_offset":"4:35:12","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Dushanbe","_offset":"5:00","_rule":"-","format":"DUST","_until":"1930 Jun 21"},{"name":"Asia/Dushanbe","_offset":"6:00","_rule":"RussiaAsia","format":"DUS%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Dushanbe","_offset":"5:00","_rule":"1:00","format":"DUSST","_until":"1991 Sep 9 2:00s"},{"name":"Asia/Dushanbe","_offset":"5:00","_rule":"-","format":"TJT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);