(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Port_Moresby":[{"name":"Pacific/Port_Moresby","_offset":"9:48:40","_rule":"-","format":"LMT","_until":"1880","offset":{"negative":false,"hours":9,"mins":48,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1879-12-31T09:48:39.999Z"}},{"name":"Pacific/Port_Moresby","_offset":"9:48:32","_rule":"-","format":"PMMT","_until":"1895","offset":{"negative":false,"hours":9,"mins":48,"secs":32},"range":{"begin":"1879-12-31T09:48:40.000Z","end":"1894-12-31T09:48:31.999Z"}},{"name":"Pacific/Port_Moresby","_offset":"10:00","_rule":"-","format":"PGT","_until":"","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"1894-12-31T09:48:32.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);