(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Port_Moresby":[{"name":"Pacific/Port_Moresby","_offset":"9:48:40","_rule":"-","format":"LMT","_until":"1880"},{"name":"Pacific/Port_Moresby","_offset":"9:48:32","_rule":"-","format":"PMMT","_until":"1895"},{"name":"Pacific/Port_Moresby","_offset":"10:00","_rule":"-","format":"PGT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);