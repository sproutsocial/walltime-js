/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Port_Moresby].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Port_Moresby":[{"name":"Pacific/Port_Moresby","_offset":"9:48:40","_rule":"-","format":"LMT","_until":"1880"},{"name":"Pacific/Port_Moresby","_offset":"9:48:32","_rule":"-","format":"PMMT","_until":"1895"},{"name":"Pacific/Port_Moresby","_offset":"10:00","_rule":"-","format":"PGT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);