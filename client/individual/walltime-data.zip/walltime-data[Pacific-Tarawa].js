(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Tarawa":[{"name":"Pacific/Tarawa","_offset":"11:32:04","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Tarawa","_offset":"12:00","_rule":"-","format":"GILT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);