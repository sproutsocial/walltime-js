(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Tarawa":[{"name":"Pacific/Tarawa","_offset":"11:32:04","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":11,"mins":32,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T11:32:03.999Z"}},{"name":"Pacific/Tarawa","_offset":"12:00","_rule":"-","format":"GILT","_until":"","offset":{"negative":false,"hours":12,"mins":0,"secs":0},"range":{"begin":"1900-12-31T11:32:04.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);