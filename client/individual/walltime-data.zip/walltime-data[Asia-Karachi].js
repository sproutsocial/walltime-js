/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Karachi].js
    
    var tzData = {
        rules: {"Pakistan":[{"name":"Pakistan","_from":"2002","_to":"only","type":"-","in":"Apr","on":"Sun>=2","at":"0:01","_save":"1:00","letter":"S"},{"name":"Pakistan","_from":"2002","_to":"only","type":"-","in":"Oct","on":"Sun>=2","at":"0:01","_save":"0","letter":"-"},{"name":"Pakistan","_from":"2008","_to":"only","type":"-","in":"Jun","on":"1","at":"0:00","_save":"1:00","letter":"S"},{"name":"Pakistan","_from":"2008","_to":"only","type":"-","in":"Nov","on":"1","at":"0:00","_save":"0","letter":"-"},{"name":"Pakistan","_from":"2009","_to":"only","type":"-","in":"Apr","on":"15","at":"0:00","_save":"1:00","letter":"S"},{"name":"Pakistan","_from":"2009","_to":"only","type":"-","in":"Nov","on":"1","at":"0:00","_save":"0","letter":"-"}]},
        zones: {"Asia/Karachi":[{"name":"Asia/Karachi","_offset":"4:28:12","_rule":"-","format":"LMT","_until":"1907"},{"name":"Asia/Karachi","_offset":"5:30","_rule":"-","format":"IST","_until":"1942 Sep"},{"name":"Asia/Karachi","_offset":"5:30","_rule":"1:00","format":"IST","_until":"1945 Oct 15"},{"name":"Asia/Karachi","_offset":"5:30","_rule":"-","format":"IST","_until":"1951 Sep 30"},{"name":"Asia/Karachi","_offset":"5:00","_rule":"-","format":"KART","_until":"1971 Mar 26"},{"name":"Asia/Karachi","_offset":"5:00","_rule":"Pakistan","format":"PK%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);