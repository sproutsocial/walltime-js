/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Cayman].js
    
    var tzData = {
        rules: {},
        zones: {"America/Cayman":[{"name":"America/Cayman","_offset":"-5:25:32","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Cayman","_offset":"-5:07:12","_rule":"-","format":"KMT","_until":"1912 Feb"},{"name":"America/Cayman","_offset":"-5:00","_rule":"-","format":"EST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);