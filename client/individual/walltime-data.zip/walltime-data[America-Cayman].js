(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Cayman":[{"name":"America/Cayman","_offset":"-5:25:32","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":5,"mins":25,"secs":32},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T18:34:27.999Z"}},{"name":"America/Cayman","_offset":"-5:07:12","_rule":"-","format":"KMT","_until":"1912 Feb","offset":{"negative":true,"hours":5,"mins":7,"secs":12},"range":{"begin":"1889-12-30T18:34:28.000Z","end":"1912-01-30T18:52:47.999Z"}},{"name":"America/Cayman","_offset":"-5:00","_rule":"-","format":"EST","_until":"","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"1912-01-30T18:52:48.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);