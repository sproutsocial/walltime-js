(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Cayman":[{"name":"America/Cayman","_offset":"-5:25:32","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Cayman","_offset":"-5:07:12","_rule":"-","format":"KMT","_until":"1912 Feb"},{"name":"America/Cayman","_offset":"-5:00","_rule":"-","format":"EST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);