/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Phoenix].js
    
    var tzData = {
        rules: {},
        zones: {"America/Phoenix":[{"name":"America/Phoenix","_offset":"-7:28:18","_rule":"-","format":"LMT","_until":"1883 Nov 18 11:31:42"},{"name":"America/Phoenix","_offset":"-7:00","_rule":"US","format":"M%sT","_until":"1944 Jan 1 00:01"},{"name":"America/Phoenix","_offset":"-7:00","_rule":"-","format":"MST","_until":"1944 Apr 1 00:01"},{"name":"America/Phoenix","_offset":"-7:00","_rule":"US","format":"M%sT","_until":"1944 Oct 1 00:01"},{"name":"America/Phoenix","_offset":"-7:00","_rule":"-","format":"MST","_until":"1967"},{"name":"America/Phoenix","_offset":"-7:00","_rule":"US","format":"M%sT","_until":"1968 Mar 21"},{"name":"America/Phoenix","_offset":"-7:00","_rule":"-","format":"MST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);