/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Indiana-Knox].js
    
    var tzData = {
        rules: {},
        zones: {"America/Indiana/Knox":[{"name":"America/Indiana/Knox","_offset":"-5:46:30","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:13:30"},{"name":"America/Indiana/Knox","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1947"},{"name":"America/Indiana/Knox","_offset":"-6:00","_rule":"Starke","format":"C%sT","_until":"1962 Apr 29 2:00"},{"name":"America/Indiana/Knox","_offset":"-5:00","_rule":"-","format":"EST","_until":"1963 Oct 27 2:00"},{"name":"America/Indiana/Knox","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1991 Oct 27 2:00"},{"name":"America/Indiana/Knox","_offset":"-5:00","_rule":"-","format":"EST","_until":"2006 Apr 2 2:00"},{"name":"America/Indiana/Knox","_offset":"-6:00","_rule":"US","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);