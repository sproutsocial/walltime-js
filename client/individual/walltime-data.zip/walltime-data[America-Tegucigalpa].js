/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Tegucigalpa].js
    
    var tzData = {
        rules: {},
        zones: {"America/Tegucigalpa":[{"name":"America/Tegucigalpa","_offset":"-5:48:52","_rule":"-","format":"LMT","_until":"1921 Apr"},{"name":"America/Tegucigalpa","_offset":"-6:00","_rule":"Hond","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);