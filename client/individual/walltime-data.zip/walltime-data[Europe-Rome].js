/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Rome].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Rome":[{"name":"Europe/Rome","_offset":"0:49:56","_rule":"-","format":"LMT","_until":"1866 Sep 22"},{"name":"Europe/Rome","_offset":"0:49:56","_rule":"-","format":"RMT","_until":"1893 Nov 1 0:00s"},{"name":"Europe/Rome","_offset":"1:00","_rule":"Italy","format":"CE%sT","_until":"1942 Nov 2 2:00s"},{"name":"Europe/Rome","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Jul"},{"name":"Europe/Rome","_offset":"1:00","_rule":"Italy","format":"CE%sT","_until":"1980"},{"name":"Europe/Rome","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);