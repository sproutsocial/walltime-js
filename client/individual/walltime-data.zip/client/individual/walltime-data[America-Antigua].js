(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Antigua":[{"name":"America/Antigua","_offset":"-4:07:12","_rule":"-","format":"LMT","_until":"1912 Mar 2"},{"name":"America/Antigua","_offset":"-5:00","_rule":"-","format":"EST","_until":"1951"},{"name":"America/Antigua","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);