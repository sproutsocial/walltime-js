(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Port_of_Spain":[{"name":"America/Port_of_Spain","_offset":"-4:06:04","_rule":"-","format":"LMT","_until":"1912 Mar 2"},{"name":"America/Port_of_Spain","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);