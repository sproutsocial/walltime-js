(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kiritimati":[{"name":"Pacific/Kiritimati","_offset":"-10:29:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Kiritimati","_offset":"-10:40","_rule":"-","format":"LINT","_until":"1979 Oct"},{"name":"Pacific/Kiritimati","_offset":"-10:00","_rule":"-","format":"LINT","_until":"1995"},{"name":"Pacific/Kiritimati","_offset":"14:00","_rule":"-","format":"LINT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);