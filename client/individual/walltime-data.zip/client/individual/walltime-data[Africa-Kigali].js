(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Kigali":[{"name":"Africa/Kigali","_offset":"2:00:16","_rule":"-","format":"LMT","_until":"1935 Jun"},{"name":"Africa/Kigali","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);