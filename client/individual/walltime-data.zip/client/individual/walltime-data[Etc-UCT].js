(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/UCT":[{"name":"Etc/UCT","_offset":"0","_rule":"-","format":"UCT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);