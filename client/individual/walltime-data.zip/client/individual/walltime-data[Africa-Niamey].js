(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Niamey":[{"name":"Africa/Niamey","_offset":"0:08:28","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Niamey","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1934 Feb 26"},{"name":"Africa/Niamey","_offset":"0:00","_rule":"-","format":"GMT","_until":"1960"},{"name":"Africa/Niamey","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);