(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Gambier":[{"name":"Pacific/Gambier","_offset":"-8:59:48","_rule":"-","format":"LMT","_until":"1912 Oct"},{"name":"Pacific/Gambier","_offset":"-9:00","_rule":"-","format":"GAMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);