(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-12":[{"name":"Etc/GMT-12","_offset":"12","_rule":"-","format":"GMT-12","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);