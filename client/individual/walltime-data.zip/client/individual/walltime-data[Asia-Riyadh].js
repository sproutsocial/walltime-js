(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Riyadh":[{"name":"Asia/Riyadh","_offset":"3:06:52","_rule":"-","format":"LMT","_until":"1950"},{"name":"Asia/Riyadh","_offset":"3:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);