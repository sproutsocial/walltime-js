(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Atlantic/South_Georgia":[{"name":"Atlantic/South_Georgia","_offset":"-2:26:08","_rule":"-","format":"LMT","_until":"1890"},{"name":"Atlantic/South_Georgia","_offset":"-2:00","_rule":"-","format":"GST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);