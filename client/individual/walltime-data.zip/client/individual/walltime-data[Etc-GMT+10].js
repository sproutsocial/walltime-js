(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+10":[{"name":"Etc/GMT+10","_offset":"-10","_rule":"-","format":"GMT+10","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);