(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Blantyre":[{"name":"Africa/Blantyre","_offset":"2:20:00","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Blantyre","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);