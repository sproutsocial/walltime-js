(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Vostok":[{"name":"Antarctica/Vostok","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Dec 16"},{"name":"Antarctica/Vostok","_offset":"6:00","_rule":"-","format":"VOST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);