(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/St_Kitts":[{"name":"America/St_Kitts","_offset":"-4:10:52","_rule":"-","format":"LMT","_until":"1912 Mar 2"},{"name":"America/St_Kitts","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);