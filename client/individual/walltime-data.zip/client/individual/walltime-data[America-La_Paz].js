(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/La_Paz":[{"name":"America/La_Paz","_offset":"-4:32:36","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/La_Paz","_offset":"-4:32:36","_rule":"-","format":"CMT","_until":"1931 Oct 15"},{"name":"America/La_Paz","_offset":"-4:32:36","_rule":"1:00","format":"BOST","_until":"1932 Mar 21"},{"name":"America/La_Paz","_offset":"-4:00","_rule":"-","format":"BOT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);