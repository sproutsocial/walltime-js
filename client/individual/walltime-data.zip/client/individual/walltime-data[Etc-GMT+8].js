(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+8":[{"name":"Etc/GMT+8","_offset":"-8","_rule":"-","format":"GMT+8","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);