(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Mayotte":[{"name":"Indian/Mayotte","_offset":"3:00:56","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"Indian/Mayotte","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);