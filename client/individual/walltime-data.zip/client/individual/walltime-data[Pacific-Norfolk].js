(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Norfolk":[{"name":"Pacific/Norfolk","_offset":"11:11:52","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Norfolk","_offset":"11:12","_rule":"-","format":"NMT","_until":"1951"},{"name":"Pacific/Norfolk","_offset":"11:30","_rule":"-","format":"NFT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);