(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Palau":[{"name":"Pacific/Palau","_offset":"8:57:56","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Palau","_offset":"9:00","_rule":"-","format":"PWT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);