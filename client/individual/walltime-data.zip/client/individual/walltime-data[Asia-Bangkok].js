(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Bangkok":[{"name":"Asia/Bangkok","_offset":"6:42:04","_rule":"-","format":"LMT","_until":"1880"},{"name":"Asia/Bangkok","_offset":"6:42:04","_rule":"-","format":"BMT","_until":"1920 Apr"},{"name":"Asia/Bangkok","_offset":"7:00","_rule":"-","format":"ICT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);