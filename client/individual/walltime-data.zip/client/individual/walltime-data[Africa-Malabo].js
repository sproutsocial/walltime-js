(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Malabo":[{"name":"Africa/Malabo","_offset":"0:35:08","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Malabo","_offset":"0:00","_rule":"-","format":"GMT","_until":"1963 Dec 15"},{"name":"Africa/Malabo","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);