(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Kathmandu":[{"name":"Asia/Kathmandu","_offset":"5:41:16","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Kathmandu","_offset":"5:30","_rule":"-","format":"IST","_until":"1986"},{"name":"Asia/Kathmandu","_offset":"5:45","_rule":"-","format":"NPT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);