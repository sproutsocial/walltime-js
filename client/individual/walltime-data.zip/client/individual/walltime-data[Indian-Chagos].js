(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Chagos":[{"name":"Indian/Chagos","_offset":"4:49:40","_rule":"-","format":"LMT","_until":"1907"},{"name":"Indian/Chagos","_offset":"5:00","_rule":"-","format":"IOT","_until":"1996"},{"name":"Indian/Chagos","_offset":"6:00","_rule":"-","format":"IOT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);