(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Aruba":[{"name":"America/Aruba","_offset":"-4:40:24","_rule":"-","format":"LMT","_until":"1912 Feb 12"},{"name":"America/Aruba","_offset":"-4:30","_rule":"-","format":"ANT","_until":"1965"},{"name":"America/Aruba","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);