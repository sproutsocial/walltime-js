(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Comoro":[{"name":"Indian/Comoro","_offset":"2:53:04","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"Indian/Comoro","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);