(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+6":[{"name":"Etc/GMT+6","_offset":"-6","_rule":"-","format":"GMT+6","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);