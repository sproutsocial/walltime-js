(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Muscat":[{"name":"Asia/Muscat","_offset":"3:54:20","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Muscat","_offset":"4:00","_rule":"-","format":"GST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);