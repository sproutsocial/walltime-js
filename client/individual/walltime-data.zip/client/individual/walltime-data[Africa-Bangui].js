(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Bangui":[{"name":"Africa/Bangui","_offset":"1:14:20","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Bangui","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);