(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Thimphu":[{"name":"Asia/Thimphu","_offset":"5:58:36","_rule":"-","format":"LMT","_until":"1947 Aug 15"},{"name":"Asia/Thimphu","_offset":"5:30","_rule":"-","format":"IST","_until":"1987 Oct"},{"name":"Asia/Thimphu","_offset":"6:00","_rule":"-","format":"BTT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);