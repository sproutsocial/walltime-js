(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Monrovia":[{"name":"Africa/Monrovia","_offset":"-0:43:08","_rule":"-","format":"LMT","_until":"1882"},{"name":"Africa/Monrovia","_offset":"-0:43:08","_rule":"-","format":"MMT","_until":"1919 Mar"},{"name":"Africa/Monrovia","_offset":"-0:44:30","_rule":"-","format":"LRT","_until":"1972 May"},{"name":"Africa/Monrovia","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);