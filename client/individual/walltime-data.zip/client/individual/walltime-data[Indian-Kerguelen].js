(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Kerguelen":[{"name":"Indian/Kerguelen","_offset":"0","_rule":"-","format":"zzz","_until":"1950"},{"name":"Indian/Kerguelen","_offset":"5:00","_rule":"-","format":"TFT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);