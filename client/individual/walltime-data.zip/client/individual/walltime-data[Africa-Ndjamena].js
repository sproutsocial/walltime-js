(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Ndjamena":[{"name":"Africa/Ndjamena","_offset":"1:00:12","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Ndjamena","_offset":"1:00","_rule":"-","format":"WAT","_until":"1979 Oct 14"},{"name":"Africa/Ndjamena","_offset":"1:00","_rule":"1:00","format":"WAST","_until":"1980 Mar 8"},{"name":"Africa/Ndjamena","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);