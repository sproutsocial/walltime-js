(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-5":[{"name":"Etc/GMT-5","_offset":"5","_rule":"-","format":"GMT-5","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);