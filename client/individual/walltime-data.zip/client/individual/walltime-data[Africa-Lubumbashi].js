(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Lubumbashi":[{"name":"Africa/Lubumbashi","_offset":"1:49:52","_rule":"-","format":"LMT","_until":"1897 Nov 9"},{"name":"Africa/Lubumbashi","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);