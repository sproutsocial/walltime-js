(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Pohnpei":[{"name":"Pacific/Pohnpei","_offset":"10:32:52","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Pohnpei","_offset":"11:00","_rule":"-","format":"PONT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);