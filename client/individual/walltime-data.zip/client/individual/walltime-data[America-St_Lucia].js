(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/St_Lucia":[{"name":"America/St_Lucia","_offset":"-4:04:00","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/St_Lucia","_offset":"-4:04:00","_rule":"-","format":"CMT","_until":"1912"},{"name":"America/St_Lucia","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);