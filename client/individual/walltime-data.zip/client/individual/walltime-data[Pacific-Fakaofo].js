(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Fakaofo":[{"name":"Pacific/Fakaofo","_offset":"-11:24:56","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Fakaofo","_offset":"-11:00","_rule":"-","format":"TKT","_until":"2011 Dec 30"},{"name":"Pacific/Fakaofo","_offset":"13:00","_rule":"-","format":"TKT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);