(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Factory":[{"name":"Factory","_offset":"0","_rule":"-","format":"\"Local","_until":"time zone must be set--see zic manual page\""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);