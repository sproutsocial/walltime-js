(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Reunion":[{"name":"Indian/Reunion","_offset":"3:41:52","_rule":"-","format":"LMT","_until":"1911 Jun"},{"name":"Indian/Reunion","_offset":"4:00","_rule":"-","format":"RET","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);