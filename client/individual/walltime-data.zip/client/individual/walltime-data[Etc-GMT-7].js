(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-7":[{"name":"Etc/GMT-7","_offset":"7","_rule":"-","format":"GMT-7","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);