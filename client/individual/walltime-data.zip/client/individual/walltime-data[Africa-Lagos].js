(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Lagos":[{"name":"Africa/Lagos","_offset":"0:13:36","_rule":"-","format":"LMT","_until":"1919 Sep"},{"name":"Africa/Lagos","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);