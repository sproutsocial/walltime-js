(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Christmas":[{"name":"Indian/Christmas","_offset":"7:02:52","_rule":"-","format":"LMT","_until":"1895 Feb"},{"name":"Indian/Christmas","_offset":"7:00","_rule":"-","format":"CXT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);