(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Kuwait":[{"name":"Asia/Kuwait","_offset":"3:11:56","_rule":"-","format":"LMT","_until":"1950"},{"name":"Asia/Kuwait","_offset":"3:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);