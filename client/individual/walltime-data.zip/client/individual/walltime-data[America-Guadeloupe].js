(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Guadeloupe":[{"name":"America/Guadeloupe","_offset":"-4:06:08","_rule":"-","format":"LMT","_until":"1911 Jun 8"},{"name":"America/Guadeloupe","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);