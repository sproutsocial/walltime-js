(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/El_Aaiun":[{"name":"Africa/El_Aaiun","_offset":"-0:52:48","_rule":"-","format":"LMT","_until":"1934 Jan"},{"name":"Africa/El_Aaiun","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1976 Apr 14"},{"name":"Africa/El_Aaiun","_offset":"0:00","_rule":"-","format":"WET","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);