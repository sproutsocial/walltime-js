(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Marquesas":[{"name":"Pacific/Marquesas","_offset":"-9:18:00","_rule":"-","format":"LMT","_until":"1912 Oct"},{"name":"Pacific/Marquesas","_offset":"-9:30","_rule":"-","format":"MART","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);