(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Guayaquil":[{"name":"America/Guayaquil","_offset":"-5:19:20","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Guayaquil","_offset":"-5:14:00","_rule":"-","format":"QMT","_until":"1931"},{"name":"America/Guayaquil","_offset":"-5:00","_rule":"-","format":"ECT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);