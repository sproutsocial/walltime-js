(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Pitcairn":[{"name":"Pacific/Pitcairn","_offset":"-8:40:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Pitcairn","_offset":"-8:30","_rule":"-","format":"PNT","_until":"1998 Apr 27 00:00"},{"name":"Pacific/Pitcairn","_offset":"-8:00","_rule":"-","format":"PST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);