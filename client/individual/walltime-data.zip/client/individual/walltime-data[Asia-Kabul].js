(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Kabul":[{"name":"Asia/Kabul","_offset":"4:36:48","_rule":"-","format":"LMT","_until":"1890"},{"name":"Asia/Kabul","_offset":"4:00","_rule":"-","format":"AFT","_until":"1945"},{"name":"Asia/Kabul","_offset":"4:30","_rule":"-","format":"AFT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);