(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Mbabane":[{"name":"Africa/Mbabane","_offset":"2:04:24","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Mbabane","_offset":"2:00","_rule":"-","format":"SAST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);