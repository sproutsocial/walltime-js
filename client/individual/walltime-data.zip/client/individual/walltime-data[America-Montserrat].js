(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Montserrat":[{"name":"America/Montserrat","_offset":"-4:08:52","_rule":"-","format":"LMT","_until":"1911 Jul 1 0:01"},{"name":"America/Montserrat","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);