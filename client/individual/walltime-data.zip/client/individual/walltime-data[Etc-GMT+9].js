(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+9":[{"name":"Etc/GMT+9","_offset":"-9","_rule":"-","format":"GMT+9","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);