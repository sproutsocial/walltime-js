(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Maputo":[{"name":"Africa/Maputo","_offset":"2:10:20","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Maputo","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);