(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Anguilla":[{"name":"America/Anguilla","_offset":"-4:12:16","_rule":"-","format":"LMT","_until":"1912 Mar 2"},{"name":"America/Anguilla","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);