(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Dominica":[{"name":"America/Dominica","_offset":"-4:05:36","_rule":"-","format":"LMT","_until":"1911 Jul 1 0:01"},{"name":"America/Dominica","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);