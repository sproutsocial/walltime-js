(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Grenada":[{"name":"America/Grenada","_offset":"-4:07:00","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"America/Grenada","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);