(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Creston":[{"name":"America/Creston","_offset":"-7:46:04","_rule":"-","format":"LMT","_until":"1884"},{"name":"America/Creston","_offset":"-7:00","_rule":"-","format":"MST","_until":"1916 Oct 1"},{"name":"America/Creston","_offset":"-8:00","_rule":"-","format":"PST","_until":"1918 Jun 2"},{"name":"America/Creston","_offset":"-7:00","_rule":"-","format":"MST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);