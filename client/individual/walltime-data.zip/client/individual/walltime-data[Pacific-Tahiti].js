(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Tahiti":[{"name":"Pacific/Tahiti","_offset":"-9:58:16","_rule":"-","format":"LMT","_until":"1912 Oct"},{"name":"Pacific/Tahiti","_offset":"-10:00","_rule":"-","format":"TAHT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);