(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kwajalein":[{"name":"Pacific/Kwajalein","_offset":"11:09:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Kwajalein","_offset":"11:00","_rule":"-","format":"MHT","_until":"1969 Oct"},{"name":"Pacific/Kwajalein","_offset":"-12:00","_rule":"-","format":"KWAT","_until":"1993 Aug 20"},{"name":"Pacific/Kwajalein","_offset":"12:00","_rule":"-","format":"MHT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);