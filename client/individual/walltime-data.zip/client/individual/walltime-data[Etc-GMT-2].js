(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-2":[{"name":"Etc/GMT-2","_offset":"2","_rule":"-","format":"GMT-2","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);