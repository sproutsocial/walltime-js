(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Maldives":[{"name":"Indian/Maldives","_offset":"4:54:00","_rule":"-","format":"LMT","_until":"1880"},{"name":"Indian/Maldives","_offset":"4:54:00","_rule":"-","format":"MMT","_until":"1960"},{"name":"Indian/Maldives","_offset":"5:00","_rule":"-","format":"MVT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);