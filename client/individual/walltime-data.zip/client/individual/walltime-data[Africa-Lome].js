(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Lome":[{"name":"Africa/Lome","_offset":"0:04:52","_rule":"-","format":"LMT","_until":"1893"},{"name":"Africa/Lome","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);