(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Curacao":[{"name":"America/Curacao","_offset":"-4:35:44","_rule":"-","format":"LMT","_until":"1912 Feb 12"},{"name":"America/Curacao","_offset":"-4:30","_rule":"-","format":"ANT","_until":"1965"},{"name":"America/Curacao","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);