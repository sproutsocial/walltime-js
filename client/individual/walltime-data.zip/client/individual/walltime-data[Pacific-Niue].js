(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Niue":[{"name":"Pacific/Niue","_offset":"-11:19:40","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Niue","_offset":"-11:20","_rule":"-","format":"NUT","_until":"1951"},{"name":"Pacific/Niue","_offset":"-11:30","_rule":"-","format":"NUT","_until":"1978 Oct 1"},{"name":"Pacific/Niue","_offset":"-11:00","_rule":"-","format":"NUT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);