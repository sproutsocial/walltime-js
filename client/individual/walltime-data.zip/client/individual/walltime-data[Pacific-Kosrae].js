(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kosrae":[{"name":"Pacific/Kosrae","_offset":"10:51:56","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Kosrae","_offset":"11:00","_rule":"-","format":"KOST","_until":"1969 Oct"},{"name":"Pacific/Kosrae","_offset":"12:00","_rule":"-","format":"KOST","_until":"1999"},{"name":"Pacific/Kosrae","_offset":"11:00","_rule":"-","format":"KOST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);