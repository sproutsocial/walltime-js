(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Mawson":[{"name":"Antarctica/Mawson","_offset":"0","_rule":"-","format":"zzz","_until":"1954 Feb 13"},{"name":"Antarctica/Mawson","_offset":"6:00","_rule":"-","format":"MAWT","_until":"2009 Oct 18 2:00"},{"name":"Antarctica/Mawson","_offset":"5:00","_rule":"-","format":"MAWT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);