(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Guam":[{"name":"Pacific/Guam","_offset":"-14:21:00","_rule":"-","format":"LMT","_until":"1844 Dec 31"},{"name":"Pacific/Guam","_offset":"9:39:00","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Guam","_offset":"10:00","_rule":"-","format":"GST","_until":"2000 Dec 23"},{"name":"Pacific/Guam","_offset":"10:00","_rule":"-","format":"ChST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);