/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Argentina-Mendoza].js
    
    var tzData = {
        rules: {},
        zones: {"America/Argentina/Mendoza":[{"name":"America/Argentina/Mendoza","_offset":"-4:35:16","_rule":"-","format":"LMT","_until":"1894 Oct 31"},{"name":"America/Argentina/Mendoza","_offset":"-4:16:48","_rule":"-","format":"CMT","_until":"1920 May"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"-","format":"ART","_until":"1930 Dec"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"Arg","format":"AR%sT","_until":"1969 Oct 5"},{"name":"America/Argentina/Mendoza","_offset":"-3:00","_rule":"Arg","format":"AR%sT","_until":"1990 Mar 4"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"-","format":"WART","_until":"1990 Oct 15"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"1:00","format":"WARST","_until":"1991 Mar 1"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"-","format":"WART","_until":"1991 Oct 15"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"1:00","format":"WARST","_until":"1992 Mar 1"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"-","format":"WART","_until":"1992 Oct 18"},{"name":"America/Argentina/Mendoza","_offset":"-3:00","_rule":"Arg","format":"AR%sT","_until":"1999 Oct 3"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"Arg","format":"AR%sT","_until":"2000 Mar 3"},{"name":"America/Argentina/Mendoza","_offset":"-3:00","_rule":"-","format":"ART","_until":"2004 May 23"},{"name":"America/Argentina/Mendoza","_offset":"-4:00","_rule":"-","format":"WART","_until":"2004 Sep 26"},{"name":"America/Argentina/Mendoza","_offset":"-3:00","_rule":"Arg","format":"AR%sT","_until":"2008 Oct 18"},{"name":"America/Argentina/Mendoza","_offset":"-3:00","_rule":"-","format":"ART","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);