/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Hebron].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Hebron":[{"name":"Asia/Hebron","_offset":"2:20:23","_rule":"-","format":"LMT","_until":"1900 Oct"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"Zion","format":"EET","_until":"1948 May 15"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"EgyptAsia","format":"EE%sT","_until":"1967 Jun 5"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"Zion","format":"I%sT","_until":"1996"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"Jordan","format":"EE%sT","_until":"1999"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"Palestine","format":"EE%sT","_until":"2008 Aug"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"2008 Sep"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"Palestine","format":"EE%sT","_until":"2011 Apr 1 12:01"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"2011 Aug 1"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"-","format":"EET","_until":"2011 Aug 30"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"2011 Sep 30 3:00"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"-","format":"EET","_until":"2012 Mar 30"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"2012 Sep 21 1:00"},{"name":"Asia/Hebron","_offset":"2:00","_rule":"-","format":"EET","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);