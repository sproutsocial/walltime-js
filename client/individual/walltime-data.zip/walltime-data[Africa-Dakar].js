(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Dakar":[{"name":"Africa/Dakar","_offset":"-1:09:44","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":true,"hours":1,"mins":9,"secs":44},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-30T22:50:15.999Z"}},{"name":"Africa/Dakar","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1941 Jun","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1911-12-30T22:50:16.000Z","end":"1941-05-30T22:59:59.999Z"}},{"name":"Africa/Dakar","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1941-05-30T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);