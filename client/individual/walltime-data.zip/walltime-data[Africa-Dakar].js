(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Dakar":[{"name":"Africa/Dakar","_offset":"-1:09:44","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Dakar","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1941 Jun"},{"name":"Africa/Dakar","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);