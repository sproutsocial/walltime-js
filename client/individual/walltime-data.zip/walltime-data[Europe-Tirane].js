/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Tirane].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Tirane":[{"name":"Europe/Tirane","_offset":"1:19:20","_rule":"-","format":"LMT","_until":"1914"},{"name":"Europe/Tirane","_offset":"1:00","_rule":"-","format":"CET","_until":"1940 Jun 16"},{"name":"Europe/Tirane","_offset":"1:00","_rule":"Albania","format":"CE%sT","_until":"1984 Jul"},{"name":"Europe/Tirane","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);