/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Tirane].js
    
    var tzData = {
        rules: {"Albania":[{"name":"Albania","_from":"1940","_to":"only","type":"-","in":"Jun","on":"16","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1942","_to":"only","type":"-","in":"Nov","on":"2","at":"3:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1943","_to":"only","type":"-","in":"Mar","on":"29","at":"2:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1943","_to":"only","type":"-","in":"Apr","on":"10","at":"3:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1974","_to":"only","type":"-","in":"May","on":"4","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1974","_to":"only","type":"-","in":"Oct","on":"2","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1975","_to":"only","type":"-","in":"May","on":"1","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1975","_to":"only","type":"-","in":"Oct","on":"2","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1976","_to":"only","type":"-","in":"May","on":"2","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1976","_to":"only","type":"-","in":"Oct","on":"3","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1977","_to":"only","type":"-","in":"May","on":"8","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1977","_to":"only","type":"-","in":"Oct","on":"2","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1978","_to":"only","type":"-","in":"May","on":"6","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1978","_to":"only","type":"-","in":"Oct","on":"1","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1979","_to":"only","type":"-","in":"May","on":"5","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1979","_to":"only","type":"-","in":"Sep","on":"30","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1980","_to":"only","type":"-","in":"May","on":"3","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1980","_to":"only","type":"-","in":"Oct","on":"4","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1981","_to":"only","type":"-","in":"Apr","on":"26","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1981","_to":"only","type":"-","in":"Sep","on":"27","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1982","_to":"only","type":"-","in":"May","on":"2","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1982","_to":"only","type":"-","in":"Oct","on":"3","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1983","_to":"only","type":"-","in":"Apr","on":"18","at":"0:00","_save":"1:00","letter":"S"},{"name":"Albania","_from":"1983","_to":"only","type":"-","in":"Oct","on":"1","at":"0:00","_save":"0","letter":"-"},{"name":"Albania","_from":"1984","_to":"only","type":"-","in":"Apr","on":"1","at":"0:00","_save":"1:00","letter":"S"}],"EU":[{"name":"EU","_from":"1977","_to":"1980","type":"-","in":"Apr","on":"Sun>=1","at":"1:00u","_save":"1:00","letter":"S"},{"name":"EU","_from":"1977","_to":"only","type":"-","in":"Sep","on":"lastSun","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1978","_to":"only","type":"-","in":"Oct","on":"1","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1979","_to":"1995","type":"-","in":"Sep","on":"lastSun","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1981","_to":"max","type":"-","in":"Mar","on":"lastSun","at":"1:00u","_save":"1:00","letter":"S"},{"name":"EU","_from":"1996","_to":"max","type":"-","in":"Oct","on":"lastSun","at":"1:00u","_save":"0","letter":"-"}]},
        zones: {"Europe/Tirane":[{"name":"Europe/Tirane","_offset":"1:19:20","_rule":"-","format":"LMT","_until":"1914"},{"name":"Europe/Tirane","_offset":"1:00","_rule":"-","format":"CET","_until":"1940 Jun 16"},{"name":"Europe/Tirane","_offset":"1:00","_rule":"Albania","format":"CE%sT","_until":"1984 Jul"},{"name":"Europe/Tirane","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);