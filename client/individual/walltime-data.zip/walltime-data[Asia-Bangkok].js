(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Bangkok":[{"name":"Asia/Bangkok","_offset":"6:42:04","_rule":"-","format":"LMT","_until":"1880","offset":{"negative":false,"hours":6,"mins":42,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1879-12-31T06:42:03.999Z"}},{"name":"Asia/Bangkok","_offset":"6:42:04","_rule":"-","format":"BMT","_until":"1920 Apr","offset":{"negative":false,"hours":6,"mins":42,"secs":4},"range":{"begin":"1879-12-31T06:42:04.000Z","end":"1920-03-31T06:42:03.999Z"}},{"name":"Asia/Bangkok","_offset":"7:00","_rule":"-","format":"ICT","_until":"","offset":{"negative":false,"hours":7,"mins":0,"secs":0},"range":{"begin":"1920-03-31T06:42:04.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);