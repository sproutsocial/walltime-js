/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Reykjavik].js
    
    var tzData = {
        rules: {"Iceland":[{"name":"Iceland","_from":"1917","_to":"1918","type":"-","in":"Feb","on":"19","at":"23:00","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1917","_to":"only","type":"-","in":"Oct","on":"21","at":"1:00","_save":"0","letter":"-"},{"name":"Iceland","_from":"1918","_to":"only","type":"-","in":"Nov","on":"16","at":"1:00","_save":"0","letter":"-"},{"name":"Iceland","_from":"1939","_to":"only","type":"-","in":"Apr","on":"29","at":"23:00","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1939","_to":"only","type":"-","in":"Nov","on":"29","at":"2:00","_save":"0","letter":"-"},{"name":"Iceland","_from":"1940","_to":"only","type":"-","in":"Feb","on":"25","at":"2:00","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1940","_to":"only","type":"-","in":"Nov","on":"3","at":"2:00","_save":"0","letter":"-"},{"name":"Iceland","_from":"1941","_to":"only","type":"-","in":"Mar","on":"2","at":"1:00s","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1941","_to":"only","type":"-","in":"Nov","on":"2","at":"1:00s","_save":"0","letter":"-"},{"name":"Iceland","_from":"1942","_to":"only","type":"-","in":"Mar","on":"8","at":"1:00s","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1942","_to":"only","type":"-","in":"Oct","on":"25","at":"1:00s","_save":"0","letter":"-"},{"name":"Iceland","_from":"1943","_to":"1946","type":"-","in":"Mar","on":"Sun>=1","at":"1:00s","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1943","_to":"1948","type":"-","in":"Oct","on":"Sun>=22","at":"1:00s","_save":"0","letter":"-"},{"name":"Iceland","_from":"1947","_to":"1967","type":"-","in":"Apr","on":"Sun>=1","at":"1:00s","_save":"1:00","letter":"S"},{"name":"Iceland","_from":"1949","_to":"only","type":"-","in":"Oct","on":"30","at":"1:00s","_save":"0","letter":"-"},{"name":"Iceland","_from":"1950","_to":"1966","type":"-","in":"Oct","on":"Sun>=22","at":"1:00s","_save":"0","letter":"-"},{"name":"Iceland","_from":"1967","_to":"only","type":"-","in":"Oct","on":"29","at":"1:00s","_save":"0","letter":"-"}]},
        zones: {"Atlantic/Reykjavik":[{"name":"Atlantic/Reykjavik","_offset":"-1:27:24","_rule":"-","format":"LMT","_until":"1837"},{"name":"Atlantic/Reykjavik","_offset":"-1:27:48","_rule":"-","format":"RMT","_until":"1908"},{"name":"Atlantic/Reykjavik","_offset":"-1:00","_rule":"Iceland","format":"IS%sT","_until":"1968 Apr 7 1:00s"},{"name":"Atlantic/Reykjavik","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);