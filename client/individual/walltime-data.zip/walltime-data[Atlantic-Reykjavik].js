/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Reykjavik].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/Reykjavik":[{"name":"Atlantic/Reykjavik","_offset":"-1:27:24","_rule":"-","format":"LMT","_until":"1837"},{"name":"Atlantic/Reykjavik","_offset":"-1:27:48","_rule":"-","format":"RMT","_until":"1908"},{"name":"Atlantic/Reykjavik","_offset":"-1:00","_rule":"Iceland","format":"IS%sT","_until":"1968 Apr 7 1:00s"},{"name":"Atlantic/Reykjavik","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);