/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Pangnirtung].js
    
    var tzData = {
        rules: {},
        zones: {"America/Pangnirtung":[{"name":"America/Pangnirtung","_offset":"0","_rule":"-","format":"zzz","_until":"1921"},{"name":"America/Pangnirtung","_offset":"-4:00","_rule":"NT_YK","format":"A%sT","_until":"1995 Apr Sun>=1 2:00"},{"name":"America/Pangnirtung","_offset":"-5:00","_rule":"Canada","format":"E%sT","_until":"1999 Oct 31 2:00"},{"name":"America/Pangnirtung","_offset":"-6:00","_rule":"Canada","format":"C%sT","_until":"2000 Oct 29 2:00"},{"name":"America/Pangnirtung","_offset":"-5:00","_rule":"Canada","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);