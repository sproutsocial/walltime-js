/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Halifax].js
    
    var tzData = {
        rules: {},
        zones: {"America/Halifax":[{"name":"America/Halifax","_offset":"-4:14:24","_rule":"-","format":"LMT","_until":"1902 Jun 15"},{"name":"America/Halifax","_offset":"-4:00","_rule":"Halifax","format":"A%sT","_until":"1918"},{"name":"America/Halifax","_offset":"-4:00","_rule":"Canada","format":"A%sT","_until":"1919"},{"name":"America/Halifax","_offset":"-4:00","_rule":"Halifax","format":"A%sT","_until":"1942 Feb 9 2:00s"},{"name":"America/Halifax","_offset":"-4:00","_rule":"Canada","format":"A%sT","_until":"1946"},{"name":"America/Halifax","_offset":"-4:00","_rule":"Halifax","format":"A%sT","_until":"1974"},{"name":"America/Halifax","_offset":"-4:00","_rule":"Canada","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);