(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Conakry":[{"name":"Africa/Conakry","_offset":"-0:54:52","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":true,"hours":0,"mins":54,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-30T23:05:07.999Z"}},{"name":"Africa/Conakry","_offset":"0:00","_rule":"-","format":"GMT","_until":"1934 Feb 26","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1911-12-30T23:05:08.000Z","end":"1934-02-25T23:59:59.999Z"}},{"name":"Africa/Conakry","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1960","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1934-02-26T00:00:00.000Z","end":"1959-12-30T22:59:59.999Z"}},{"name":"Africa/Conakry","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1959-12-30T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);