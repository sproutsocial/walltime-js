/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Conakry":[{"name":"Africa/Conakry","_offset":"-0:54:52","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Conakry","_offset":"0:00","_rule":"-","format":"GMT","_until":"1934 Feb 26"},{"name":"Africa/Conakry","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1960"},{"name":"Africa/Conakry","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);