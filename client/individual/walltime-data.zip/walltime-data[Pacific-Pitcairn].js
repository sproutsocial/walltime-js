/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Pitcairn":[{"name":"Pacific/Pitcairn","_offset":"-8:40:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Pitcairn","_offset":"-8:30","_rule":"-","format":"PNT","_until":"1998 Apr 27 00:00"},{"name":"Pacific/Pitcairn","_offset":"-8:00","_rule":"-","format":"PST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);