/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Pitcairn].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Pitcairn":[{"name":"Pacific/Pitcairn","_offset":"-8:40:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Pitcairn","_offset":"-8:30","_rule":"-","format":"PNT","_until":"1998 Apr 27 00:00"},{"name":"Pacific/Pitcairn","_offset":"-8:00","_rule":"-","format":"PST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);