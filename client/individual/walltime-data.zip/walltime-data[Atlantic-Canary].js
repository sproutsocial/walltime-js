/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Canary].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/Canary":[{"name":"Atlantic/Canary","_offset":"-1:01:36","_rule":"-","format":"LMT","_until":"1922 Mar"},{"name":"Atlantic/Canary","_offset":"-1:00","_rule":"-","format":"CANT","_until":"1946 Sep 30 1:00"},{"name":"Atlantic/Canary","_offset":"0:00","_rule":"-","format":"WET","_until":"1980 Apr 6 0:00s"},{"name":"Atlantic/Canary","_offset":"0:00","_rule":"1:00","format":"WEST","_until":"1980 Sep 28 0:00s"},{"name":"Atlantic/Canary","_offset":"0:00","_rule":"EU","format":"WE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);