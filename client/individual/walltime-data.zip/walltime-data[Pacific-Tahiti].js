(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Tahiti":[{"name":"Pacific/Tahiti","_offset":"-9:58:16","_rule":"-","format":"LMT","_until":"1912 Oct","offset":{"negative":true,"hours":9,"mins":58,"secs":16},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-09-29T14:01:43.999Z"}},{"name":"Pacific/Tahiti","_offset":"-10:00","_rule":"-","format":"TAHT","_until":"","offset":{"negative":true,"hours":10,"mins":0,"secs":0},"range":{"begin":"1912-09-29T14:01:44.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);