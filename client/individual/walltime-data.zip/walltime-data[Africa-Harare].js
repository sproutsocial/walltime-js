(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Harare":[{"name":"Africa/Harare","_offset":"2:04:12","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Harare","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);