/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Belgrade].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Belgrade":[{"name":"Europe/Belgrade","_offset":"1:22:00","_rule":"-","format":"LMT","_until":"1884"},{"name":"Europe/Belgrade","_offset":"1:00","_rule":"-","format":"CET","_until":"1941 Apr 18 23:00"},{"name":"Europe/Belgrade","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945"},{"name":"Europe/Belgrade","_offset":"1:00","_rule":"-","format":"CET","_until":"1945 May 8 2:00s"},{"name":"Europe/Belgrade","_offset":"1:00","_rule":"1:00","format":"CEST","_until":"1945 Sep 16 2:00s"},{"name":"Europe/Belgrade","_offset":"1:00","_rule":"-","format":"CET","_until":"1982 Nov 27"},{"name":"Europe/Belgrade","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);