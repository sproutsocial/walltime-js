/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Wallis":[{"name":"Pacific/Wallis","_offset":"12:15:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Wallis","_offset":"12:00","_rule":"-","format":"WFT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);