(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Wallis":[{"name":"Pacific/Wallis","_offset":"12:15:20","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":12,"mins":15,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T12:15:19.999Z"}},{"name":"Pacific/Wallis","_offset":"12:00","_rule":"-","format":"WFT","_until":"","offset":{"negative":false,"hours":12,"mins":0,"secs":0},"range":{"begin":"1900-12-31T12:15:20.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);