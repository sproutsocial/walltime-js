/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Indian-Antananarivo].js
    
    var tzData = {
        rules: {},
        zones: {"Indian/Antananarivo":[{"name":"Indian/Antananarivo","_offset":"3:10:04","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"Indian/Antananarivo","_offset":"3:00","_rule":"-","format":"EAT","_until":"1954 Feb 27 23:00s"},{"name":"Indian/Antananarivo","_offset":"3:00","_rule":"1:00","format":"EAST","_until":"1954 May 29 23:00s"},{"name":"Indian/Antananarivo","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);