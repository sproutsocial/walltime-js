(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Antananarivo":[{"name":"Indian/Antananarivo","_offset":"3:10:04","_rule":"-","format":"LMT","_until":"1911 Jul","offset":{"negative":false,"hours":3,"mins":10,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-06-30T03:10:03.999Z"}},{"name":"Indian/Antananarivo","_offset":"3:00","_rule":"-","format":"EAT","_until":"1954 Feb 27 23:00s","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1911-06-30T03:10:04.000Z","end":"1954-02-28T01:59:59.999Z"}},{"name":"Indian/Antananarivo","_offset":"3:00","_rule":"1:00","format":"EAST","_until":"1954 May 29 23:00s","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1954-02-28T02:00:00.000Z","end":"1954-05-30T01:59:59.999Z"}},{"name":"Indian/Antananarivo","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1954-05-30T02:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);