/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"America/Creston":[{"name":"America/Creston","_offset":"-7:46:04","_rule":"-","format":"LMT","_until":"1884"},{"name":"America/Creston","_offset":"-7:00","_rule":"-","format":"MST","_until":"1916 Oct 1"},{"name":"America/Creston","_offset":"-8:00","_rule":"-","format":"PST","_until":"1918 Jun 2"},{"name":"America/Creston","_offset":"-7:00","_rule":"-","format":"MST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);