(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Creston":[{"name":"America/Creston","_offset":"-7:46:04","_rule":"-","format":"LMT","_until":"1884","offset":{"negative":true,"hours":7,"mins":46,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1883-12-30T16:13:55.999Z"}},{"name":"America/Creston","_offset":"-7:00","_rule":"-","format":"MST","_until":"1916 Oct 1","offset":{"negative":true,"hours":7,"mins":0,"secs":0},"range":{"begin":"1883-12-30T16:13:56.000Z","end":"1916-09-30T16:59:59.999Z"}},{"name":"America/Creston","_offset":"-8:00","_rule":"-","format":"PST","_until":"1918 Jun 2","offset":{"negative":true,"hours":8,"mins":0,"secs":0},"range":{"begin":"1916-09-30T17:00:00.000Z","end":"1918-06-01T15:59:59.999Z"}},{"name":"America/Creston","_offset":"-7:00","_rule":"-","format":"MST","_until":"","offset":{"negative":true,"hours":7,"mins":0,"secs":0},"range":{"begin":"1918-06-01T16:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);