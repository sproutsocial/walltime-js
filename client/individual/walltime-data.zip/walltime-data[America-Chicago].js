/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Chicago].js
    
    var tzData = {
        rules: {},
        zones: {"America/Chicago":[{"name":"America/Chicago","_offset":"-5:50:36","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:09:24"},{"name":"America/Chicago","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1920"},{"name":"America/Chicago","_offset":"-6:00","_rule":"Chicago","format":"C%sT","_until":"1936 Mar 1 2:00"},{"name":"America/Chicago","_offset":"-5:00","_rule":"-","format":"EST","_until":"1936 Nov 15 2:00"},{"name":"America/Chicago","_offset":"-6:00","_rule":"Chicago","format":"C%sT","_until":"1942"},{"name":"America/Chicago","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1946"},{"name":"America/Chicago","_offset":"-6:00","_rule":"Chicago","format":"C%sT","_until":"1967"},{"name":"America/Chicago","_offset":"-6:00","_rule":"US","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);