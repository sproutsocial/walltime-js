(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Tortola":[{"name":"America/Tortola","_offset":"-4:18:28","_rule":"-","format":"LMT","_until":"1911 Jul","offset":{"negative":true,"hours":4,"mins":18,"secs":28},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-06-29T19:41:31.999Z"}},{"name":"America/Tortola","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1911-06-29T19:41:32.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);