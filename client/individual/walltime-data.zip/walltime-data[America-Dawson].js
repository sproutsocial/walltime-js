/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Dawson].js
    
    var tzData = {
        rules: {},
        zones: {"America/Dawson":[{"name":"America/Dawson","_offset":"-9:17:40","_rule":"-","format":"LMT","_until":"1900 Aug 20"},{"name":"America/Dawson","_offset":"-9:00","_rule":"NT_YK","format":"Y%sT","_until":"1973 Oct 28 0:00"},{"name":"America/Dawson","_offset":"-8:00","_rule":"NT_YK","format":"P%sT","_until":"1980"},{"name":"America/Dawson","_offset":"-8:00","_rule":"Canada","format":"P%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);