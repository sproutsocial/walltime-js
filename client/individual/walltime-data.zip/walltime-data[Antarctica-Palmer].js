/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Palmer].js
    
    var tzData = {
        rules: {"ArgAQ":[{"name":"ArgAQ","_from":"1964","_to":"1966","type":"-","in":"Mar","on":"1","at":"0:00","_save":"0","letter":"-"},{"name":"ArgAQ","_from":"1964","_to":"1966","type":"-","in":"Oct","on":"15","at":"0:00","_save":"1:00","letter":"S"},{"name":"ArgAQ","_from":"1967","_to":"only","type":"-","in":"Apr","on":"2","at":"0:00","_save":"0","letter":"-"},{"name":"ArgAQ","_from":"1967","_to":"1968","type":"-","in":"Oct","on":"Sun>=1","at":"0:00","_save":"1:00","letter":"S"},{"name":"ArgAQ","_from":"1968","_to":"1969","type":"-","in":"Apr","on":"Sun>=1","at":"0:00","_save":"0","letter":"-"},{"name":"ArgAQ","_from":"1974","_to":"only","type":"-","in":"Jan","on":"23","at":"0:00","_save":"1:00","letter":"S"},{"name":"ArgAQ","_from":"1974","_to":"only","type":"-","in":"May","on":"1","at":"0:00","_save":"0","letter":"-"}],"ChileAQ":[{"name":"ChileAQ","_from":"1972","_to":"1986","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1974","_to":"1987","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"1987","_to":"only","type":"-","in":"Apr","on":"12","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1988","_to":"1989","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1988","_to":"only","type":"-","in":"Oct","on":"Sun>=1","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"1989","_to":"only","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"1990","_to":"only","type":"-","in":"Mar","on":"18","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1990","_to":"only","type":"-","in":"Sep","on":"16","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"1991","_to":"1996","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1991","_to":"1997","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"1997","_to":"only","type":"-","in":"Mar","on":"30","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1998","_to":"only","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1998","_to":"only","type":"-","in":"Sep","on":"27","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"1999","_to":"only","type":"-","in":"Apr","on":"4","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"1999","_to":"2010","type":"-","in":"Oct","on":"Sun>=9","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"2000","_to":"2007","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"2008","_to":"only","type":"-","in":"Mar","on":"30","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"2009","_to":"only","type":"-","in":"Mar","on":"Sun>=9","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"2010","_to":"only","type":"-","in":"Apr","on":"Sun>=1","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"2011","_to":"only","type":"-","in":"May","on":"Sun>=2","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"2011","_to":"only","type":"-","in":"Aug","on":"Sun>=16","at":"4:00u","_save":"1:00","letter":"S"},{"name":"ChileAQ","_from":"2012","_to":"max","type":"-","in":"Apr","on":"Sun>=23","at":"3:00u","_save":"0","letter":"-"},{"name":"ChileAQ","_from":"2012","_to":"max","type":"-","in":"Sep","on":"Sun>=2","at":"4:00u","_save":"1:00","letter":"S"}]},
        zones: {"Antarctica/Palmer":[{"name":"Antarctica/Palmer","_offset":"0","_rule":"-","format":"zzz","_until":"1965"},{"name":"Antarctica/Palmer","_offset":"-4:00","_rule":"ArgAQ","format":"AR%sT","_until":"1969 Oct 5"},{"name":"Antarctica/Palmer","_offset":"-3:00","_rule":"ArgAQ","format":"AR%sT","_until":"1982 May"},{"name":"Antarctica/Palmer","_offset":"-4:00","_rule":"ChileAQ","format":"CL%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);