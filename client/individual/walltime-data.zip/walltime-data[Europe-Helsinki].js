/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Helsinki].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Helsinki":[{"name":"Europe/Helsinki","_offset":"1:39:52","_rule":"-","format":"LMT","_until":"1878 May 31"},{"name":"Europe/Helsinki","_offset":"1:39:52","_rule":"-","format":"HMT","_until":"1921 May"},{"name":"Europe/Helsinki","_offset":"2:00","_rule":"Finland","format":"EE%sT","_until":"1983"},{"name":"Europe/Helsinki","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);