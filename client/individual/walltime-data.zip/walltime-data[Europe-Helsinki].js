/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Helsinki].js
    
    var tzData = {
        rules: {"Finland":[{"name":"Finland","_from":"1942","_to":"only","type":"-","in":"Apr","on":"3","at":"0:00","_save":"1:00","letter":"S"},{"name":"Finland","_from":"1942","_to":"only","type":"-","in":"Oct","on":"3","at":"0:00","_save":"0","letter":"-"},{"name":"Finland","_from":"1981","_to":"1982","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"1:00","letter":"S"},{"name":"Finland","_from":"1981","_to":"1982","type":"-","in":"Sep","on":"lastSun","at":"3:00","_save":"0","letter":"-"}],"EU":[{"name":"EU","_from":"1977","_to":"1980","type":"-","in":"Apr","on":"Sun>=1","at":"1:00u","_save":"1:00","letter":"S"},{"name":"EU","_from":"1977","_to":"only","type":"-","in":"Sep","on":"lastSun","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1978","_to":"only","type":"-","in":"Oct","on":"1","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1979","_to":"1995","type":"-","in":"Sep","on":"lastSun","at":"1:00u","_save":"0","letter":"-"},{"name":"EU","_from":"1981","_to":"max","type":"-","in":"Mar","on":"lastSun","at":"1:00u","_save":"1:00","letter":"S"},{"name":"EU","_from":"1996","_to":"max","type":"-","in":"Oct","on":"lastSun","at":"1:00u","_save":"0","letter":"-"}]},
        zones: {"Europe/Helsinki":[{"name":"Europe/Helsinki","_offset":"1:39:52","_rule":"-","format":"LMT","_until":"1878 May 31"},{"name":"Europe/Helsinki","_offset":"1:39:52","_rule":"-","format":"HMT","_until":"1921 May"},{"name":"Europe/Helsinki","_offset":"2:00","_rule":"Finland","format":"EE%sT","_until":"1983"},{"name":"Europe/Helsinki","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);