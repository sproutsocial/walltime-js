/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Baku].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Baku":[{"name":"Asia/Baku","_offset":"3:19:24","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Baku","_offset":"3:00","_rule":"-","format":"BAKT","_until":"1957 Mar"},{"name":"Asia/Baku","_offset":"4:00","_rule":"RussiaAsia","format":"BAK%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Baku","_offset":"3:00","_rule":"1:00","format":"BAKST","_until":"1991 Aug 30"},{"name":"Asia/Baku","_offset":"3:00","_rule":"RussiaAsia","format":"AZ%sT","_until":"1992 Sep lastSat 23:00"},{"name":"Asia/Baku","_offset":"4:00","_rule":"-","format":"AZT","_until":"1996"},{"name":"Asia/Baku","_offset":"4:00","_rule":"EUAsia","format":"AZ%sT","_until":"1997"},{"name":"Asia/Baku","_offset":"4:00","_rule":"Azer","format":"AZ%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);