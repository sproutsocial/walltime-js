(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Gambier":[{"name":"Pacific/Gambier","_offset":"-8:59:48","_rule":"-","format":"LMT","_until":"1912 Oct","offset":{"negative":true,"hours":8,"mins":59,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-09-29T15:00:11.999Z"}},{"name":"Pacific/Gambier","_offset":"-9:00","_rule":"-","format":"GAMT","_until":"","offset":{"negative":true,"hours":9,"mins":0,"secs":0},"range":{"begin":"1912-09-29T15:00:12.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);