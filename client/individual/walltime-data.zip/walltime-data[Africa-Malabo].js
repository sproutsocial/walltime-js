(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Malabo":[{"name":"Africa/Malabo","_offset":"0:35:08","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":false,"hours":0,"mins":35,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-31T00:35:07.999Z"}},{"name":"Africa/Malabo","_offset":"0:00","_rule":"-","format":"GMT","_until":"1963 Dec 15","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1911-12-31T00:35:08.000Z","end":"1963-12-14T23:59:59.999Z"}},{"name":"Africa/Malabo","_offset":"1:00","_rule":"-","format":"WAT","_until":"","offset":{"negative":false,"hours":1,"mins":0,"secs":0},"range":{"begin":"1963-12-15T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);