/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Malabo":[{"name":"Africa/Malabo","_offset":"0:35:08","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Malabo","_offset":"0:00","_rule":"-","format":"GMT","_until":"1963 Dec 15"},{"name":"Africa/Malabo","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);