/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Eucla].js
    
    var tzData = {
        rules: {"Aus":[{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Jan","on":"1","at":"0:01","_save":"1:00","letter":"-"},{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Mar","on":"25","at":"2:00","_save":"0","letter":"-"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Jan","on":"1","at":"2:00","_save":"1:00","letter":"-"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Mar","on":"29","at":"2:00","_save":"0","letter":"-"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Sep","on":"27","at":"2:00","_save":"1:00","letter":"-"},{"name":"Aus","_from":"1943","_to":"1944","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"0","letter":"-"},{"name":"Aus","_from":"1943","_to":"only","type":"-","in":"Oct","on":"3","at":"2:00","_save":"1:00","letter":"-"}],"AW":[{"name":"AW","_from":"1974","_to":"only","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AW","_from":"1975","_to":"only","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"-"},{"name":"AW","_from":"1983","_to":"only","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AW","_from":"1984","_to":"only","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"-"},{"name":"AW","_from":"1991","_to":"only","type":"-","in":"Nov","on":"17","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AW","_from":"1992","_to":"only","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"-"},{"name":"AW","_from":"2006","_to":"only","type":"-","in":"Dec","on":"3","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AW","_from":"2007","_to":"2009","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"-"},{"name":"AW","_from":"2007","_to":"2008","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"-"}]},
        zones: {"Australia/Eucla":[{"name":"Australia/Eucla","_offset":"8:35:28","_rule":"-","format":"LMT","_until":"1895 Dec"},{"name":"Australia/Eucla","_offset":"8:45","_rule":"Aus","format":"CWST","_until":"1943 Jul"},{"name":"Australia/Eucla","_offset":"8:45","_rule":"AW","format":"CWST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);