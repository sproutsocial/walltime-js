/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Nassau].js
    
    var tzData = {
        rules: {},
        zones: {"America/Nassau":[{"name":"America/Nassau","_offset":"-5:09:30","_rule":"-","format":"LMT","_until":"1912 Mar 2"},{"name":"America/Nassau","_offset":"-5:00","_rule":"Bahamas","format":"E%sT","_until":"1976"},{"name":"America/Nassau","_offset":"-5:00","_rule":"US","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);