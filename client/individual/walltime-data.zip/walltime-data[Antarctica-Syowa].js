(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Syowa":[{"name":"Antarctica/Syowa","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Jan 29"},{"name":"Antarctica/Syowa","_offset":"3:00","_rule":"-","format":"SYOT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);