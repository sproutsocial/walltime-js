(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Syowa":[{"name":"Antarctica/Syowa","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Jan 29","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1957-01-28T23:59:59.999Z"}},{"name":"Antarctica/Syowa","_offset":"3:00","_rule":"-","format":"SYOT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1957-01-29T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);