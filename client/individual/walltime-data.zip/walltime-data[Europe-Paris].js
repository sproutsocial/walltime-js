/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Paris].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Paris":[{"name":"Europe/Paris","_offset":"0:09:21","_rule":"-","format":"LMT","_until":"1891 Mar 15 0:01"},{"name":"Europe/Paris","_offset":"0:09:21","_rule":"-","format":"PMT","_until":"1911 Mar 11 0:01"},{"name":"Europe/Paris","_offset":"0:00","_rule":"France","format":"WE%sT","_until":"1940 Jun 14 23:00"},{"name":"Europe/Paris","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Aug 25"},{"name":"Europe/Paris","_offset":"0:00","_rule":"France","format":"WE%sT","_until":"1945 Sep 16 3:00"},{"name":"Europe/Paris","_offset":"1:00","_rule":"France","format":"CE%sT","_until":"1977"},{"name":"Europe/Paris","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);