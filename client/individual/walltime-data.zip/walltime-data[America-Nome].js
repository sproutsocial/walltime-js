/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Nome].js
    
    var tzData = {
        rules: {},
        zones: {"America/Nome":[{"name":"America/Nome","_offset":"12:58:21","_rule":"-","format":"LMT","_until":"1867 Oct 18"},{"name":"America/Nome","_offset":"-11:01:38","_rule":"-","format":"LMT","_until":"1900 Aug 20 12:00"},{"name":"America/Nome","_offset":"-11:00","_rule":"-","format":"NST","_until":"1942"},{"name":"America/Nome","_offset":"-11:00","_rule":"US","format":"N%sT","_until":"1946"},{"name":"America/Nome","_offset":"-11:00","_rule":"-","format":"NST","_until":"1967 Apr"},{"name":"America/Nome","_offset":"-11:00","_rule":"-","format":"BST","_until":"1969"},{"name":"America/Nome","_offset":"-11:00","_rule":"US","format":"B%sT","_until":"1983 Oct 30 2:00"},{"name":"America/Nome","_offset":"-9:00","_rule":"US","format":"Y%sT","_until":"1983 Nov 30"},{"name":"America/Nome","_offset":"-9:00","_rule":"US","format":"AK%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);