/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Luxembourg].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Luxembourg":[{"name":"Europe/Luxembourg","_offset":"0:24:36","_rule":"-","format":"LMT","_until":"1904 Jun"},{"name":"Europe/Luxembourg","_offset":"1:00","_rule":"Lux","format":"CE%sT","_until":"1918 Nov 25"},{"name":"Europe/Luxembourg","_offset":"0:00","_rule":"Lux","format":"WE%sT","_until":"1929 Oct 6 2:00s"},{"name":"Europe/Luxembourg","_offset":"0:00","_rule":"Belgium","format":"WE%sT","_until":"1940 May 14 3:00"},{"name":"Europe/Luxembourg","_offset":"1:00","_rule":"C-Eur","format":"WE%sT","_until":"1944 Sep 18 3:00"},{"name":"Europe/Luxembourg","_offset":"1:00","_rule":"Belgium","format":"CE%sT","_until":"1977"},{"name":"Europe/Luxembourg","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);