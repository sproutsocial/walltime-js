(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Port_of_Spain":[{"name":"America/Port_of_Spain","_offset":"-4:06:04","_rule":"-","format":"LMT","_until":"1912 Mar 2","offset":{"negative":true,"hours":4,"mins":6,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-03-01T19:53:55.999Z"}},{"name":"America/Port_of_Spain","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1912-03-01T19:53:56.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);