/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Bermuda].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/Bermuda":[{"name":"Atlantic/Bermuda","_offset":"-4:19:04","_rule":"-","format":"LMT","_until":"1930 Jan 1 2:00"},{"name":"Atlantic/Bermuda","_offset":"-4:00","_rule":"-","format":"AST","_until":"1974 Apr 28 2:00"},{"name":"Atlantic/Bermuda","_offset":"-4:00","_rule":"Bahamas","format":"A%sT","_until":"1976"},{"name":"Atlantic/Bermuda","_offset":"-4:00","_rule":"US","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);