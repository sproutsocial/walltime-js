(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Kathmandu":[{"name":"Asia/Kathmandu","_offset":"5:41:16","_rule":"-","format":"LMT","_until":"1920","offset":{"negative":false,"hours":5,"mins":41,"secs":16},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1919-12-31T05:41:15.999Z"}},{"name":"Asia/Kathmandu","_offset":"5:30","_rule":"-","format":"IST","_until":"1986","offset":{"negative":false,"hours":5,"mins":30,"secs":0},"range":{"begin":"1919-12-31T05:41:16.000Z","end":"1985-12-31T05:29:59.999Z"}},{"name":"Asia/Kathmandu","_offset":"5:45","_rule":"-","format":"NPT","_until":"","offset":{"negative":false,"hours":5,"mins":45,"secs":0},"range":{"begin":"1985-12-31T05:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);