/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Volgograd].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Volgograd":[{"name":"Europe/Volgograd","_offset":"2:57:40","_rule":"-","format":"LMT","_until":"1920 Jan 3"},{"name":"Europe/Volgograd","_offset":"3:00","_rule":"-","format":"TSAT","_until":"1925 Apr 6"},{"name":"Europe/Volgograd","_offset":"3:00","_rule":"-","format":"STAT","_until":"1930 Jun 21"},{"name":"Europe/Volgograd","_offset":"4:00","_rule":"-","format":"STAT","_until":"1961 Nov 11"},{"name":"Europe/Volgograd","_offset":"4:00","_rule":"Russia","format":"VOL%sT","_until":"1989 Mar 26 2:00s"},{"name":"Europe/Volgograd","_offset":"3:00","_rule":"Russia","format":"VOL%sT","_until":"1991 Mar 31 2:00s"},{"name":"Europe/Volgograd","_offset":"4:00","_rule":"-","format":"VOLT","_until":"1992 Mar 29 2:00s"},{"name":"Europe/Volgograd","_offset":"3:00","_rule":"Russia","format":"VOL%sT","_until":"2011 Mar 27 2:00s"},{"name":"Europe/Volgograd","_offset":"4:00","_rule":"-","format":"VOLT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);