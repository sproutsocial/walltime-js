/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"EST":[{"name":"EST","_offset":"-5:00","_rule":"-","format":"EST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);