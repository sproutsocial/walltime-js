(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"EST":[{"name":"EST","_offset":"-5:00","_rule":"-","format":"EST","_until":"","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);