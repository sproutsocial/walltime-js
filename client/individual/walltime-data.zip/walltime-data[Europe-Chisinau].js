/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Chisinau].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Chisinau":[{"name":"Europe/Chisinau","_offset":"1:55:20","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Chisinau","_offset":"1:55","_rule":"-","format":"CMT","_until":"1918 Feb 15"},{"name":"Europe/Chisinau","_offset":"1:44:24","_rule":"-","format":"BMT","_until":"1931 Jul 24"},{"name":"Europe/Chisinau","_offset":"2:00","_rule":"Romania","format":"EE%sT","_until":"1940 Aug 15"},{"name":"Europe/Chisinau","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"1941 Jul 17"},{"name":"Europe/Chisinau","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Aug 24"},{"name":"Europe/Chisinau","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1990"},{"name":"Europe/Chisinau","_offset":"3:00","_rule":"-","format":"MSK","_until":"1990 May 6"},{"name":"Europe/Chisinau","_offset":"2:00","_rule":"-","format":"EET","_until":"1991"},{"name":"Europe/Chisinau","_offset":"2:00","_rule":"Russia","format":"EE%sT","_until":"1992"},{"name":"Europe/Chisinau","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1997"},{"name":"Europe/Chisinau","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);