/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Riyadh88].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Riyadh88":[{"name":"Asia/Riyadh88","_offset":"3:07:04","_rule":"-","format":"zzz","_until":"1988"},{"name":"Asia/Riyadh88","_offset":"3:07:04","_rule":"sol88","format":"zzz","_until":"1989"},{"name":"Asia/Riyadh88","_offset":"3:07:04","_rule":"-","format":"zzz","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);