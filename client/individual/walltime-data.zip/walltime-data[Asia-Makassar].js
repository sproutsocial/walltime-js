(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Makassar":[{"name":"Asia/Makassar","_offset":"7:57:36","_rule":"-","format":"LMT","_until":"1920","offset":{"negative":false,"hours":7,"mins":57,"secs":36},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1919-12-31T07:57:35.999Z"}},{"name":"Asia/Makassar","_offset":"7:57:36","_rule":"-","format":"MMT","_until":"1932 Nov","offset":{"negative":false,"hours":7,"mins":57,"secs":36},"range":{"begin":"1919-12-31T07:57:36.000Z","end":"1932-10-31T07:57:35.999Z"}},{"name":"Asia/Makassar","_offset":"8:00","_rule":"-","format":"CIT","_until":"1942 Feb 9","offset":{"negative":false,"hours":8,"mins":0,"secs":0},"range":{"begin":"1932-10-31T07:57:36.000Z","end":"1942-02-09T07:59:59.999Z"}},{"name":"Asia/Makassar","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 23","offset":{"negative":false,"hours":9,"mins":0,"secs":0},"range":{"begin":"1942-02-09T08:00:00.000Z","end":"1945-09-23T08:59:59.999Z"}},{"name":"Asia/Makassar","_offset":"8:00","_rule":"-","format":"CIT","_until":"","offset":{"negative":false,"hours":8,"mins":0,"secs":0},"range":{"begin":"1945-09-23T09:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);