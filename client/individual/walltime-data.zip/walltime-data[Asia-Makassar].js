(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Makassar":[{"name":"Asia/Makassar","_offset":"7:57:36","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Makassar","_offset":"7:57:36","_rule":"-","format":"MMT","_until":"1932 Nov"},{"name":"Asia/Makassar","_offset":"8:00","_rule":"-","format":"CIT","_until":"1942 Feb 9"},{"name":"Asia/Makassar","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 23"},{"name":"Asia/Makassar","_offset":"8:00","_rule":"-","format":"CIT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);