/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Makassar].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Makassar":[{"name":"Asia/Makassar","_offset":"7:57:36","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Makassar","_offset":"7:57:36","_rule":"-","format":"MMT","_until":"1932 Nov"},{"name":"Asia/Makassar","_offset":"8:00","_rule":"-","format":"CIT","_until":"1942 Feb 9"},{"name":"Asia/Makassar","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 23"},{"name":"Asia/Makassar","_offset":"8:00","_rule":"-","format":"CIT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);