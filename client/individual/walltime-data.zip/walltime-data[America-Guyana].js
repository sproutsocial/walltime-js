(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Guyana":[{"name":"America/Guyana","_offset":"-3:52:40","_rule":"-","format":"LMT","_until":"1915 Mar","offset":{"negative":true,"hours":3,"mins":52,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1915-02-27T20:07:19.999Z"}},{"name":"America/Guyana","_offset":"-3:45","_rule":"-","format":"GBGT","_until":"1966 May 26","offset":{"negative":true,"hours":3,"mins":45,"secs":0},"range":{"begin":"1915-02-27T20:07:20.000Z","end":"1966-05-25T20:14:59.999Z"}},{"name":"America/Guyana","_offset":"-3:45","_rule":"-","format":"GYT","_until":"1975 Jul 31","offset":{"negative":true,"hours":3,"mins":45,"secs":0},"range":{"begin":"1966-05-25T20:15:00.000Z","end":"1975-07-30T20:14:59.999Z"}},{"name":"America/Guyana","_offset":"-3:00","_rule":"-","format":"GYT","_until":"1991","offset":{"negative":true,"hours":3,"mins":0,"secs":0},"range":{"begin":"1975-07-30T20:15:00.000Z","end":"1990-12-30T20:59:59.999Z"}},{"name":"America/Guyana","_offset":"-4:00","_rule":"-","format":"GYT","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1990-12-30T21:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);