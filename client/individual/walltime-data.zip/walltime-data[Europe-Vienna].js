/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Vienna].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Vienna":[{"name":"Europe/Vienna","_offset":"1:05:20","_rule":"-","format":"LMT","_until":"1893 Apr"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1920"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"Austria","format":"CE%sT","_until":"1940 Apr 1 2:00s"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945 Apr 2 2:00s"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"1:00","format":"CEST","_until":"1945 Apr 12 2:00s"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"-","format":"CET","_until":"1946"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"Austria","format":"CE%sT","_until":"1981"},{"name":"Europe/Vienna","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);