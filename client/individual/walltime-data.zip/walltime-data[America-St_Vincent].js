(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/St_Vincent":[{"name":"America/St_Vincent","_offset":"-4:04:56","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/St_Vincent","_offset":"-4:04:56","_rule":"-","format":"KMT","_until":"1912"},{"name":"America/St_Vincent","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);