/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Uzhgorod].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Uzhgorod":[{"name":"Europe/Uzhgorod","_offset":"1:29:12","_rule":"-","format":"LMT","_until":"1890 Oct"},{"name":"Europe/Uzhgorod","_offset":"1:00","_rule":"-","format":"CET","_until":"1940"},{"name":"Europe/Uzhgorod","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Oct"},{"name":"Europe/Uzhgorod","_offset":"1:00","_rule":"1:00","format":"CEST","_until":"1944 Oct 26"},{"name":"Europe/Uzhgorod","_offset":"1:00","_rule":"-","format":"CET","_until":"1945 Jun 29"},{"name":"Europe/Uzhgorod","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1990"},{"name":"Europe/Uzhgorod","_offset":"3:00","_rule":"-","format":"MSK","_until":"1990 Jul 1 2:00"},{"name":"Europe/Uzhgorod","_offset":"1:00","_rule":"-","format":"CET","_until":"1991 Mar 31 3:00"},{"name":"Europe/Uzhgorod","_offset":"2:00","_rule":"-","format":"EET","_until":"1992"},{"name":"Europe/Uzhgorod","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1995"},{"name":"Europe/Uzhgorod","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);