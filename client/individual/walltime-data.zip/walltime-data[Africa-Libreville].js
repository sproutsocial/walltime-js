/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Libreville":[{"name":"Africa/Libreville","_offset":"0:37:48","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Libreville","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);