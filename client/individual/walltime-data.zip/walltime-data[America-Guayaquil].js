(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Guayaquil":[{"name":"America/Guayaquil","_offset":"-5:19:20","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":5,"mins":19,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T18:40:39.999Z"}},{"name":"America/Guayaquil","_offset":"-5:14:00","_rule":"-","format":"QMT","_until":"1931","offset":{"negative":true,"hours":5,"mins":14,"secs":0},"range":{"begin":"1889-12-30T18:40:40.000Z","end":"1930-12-30T18:45:59.999Z"}},{"name":"America/Guayaquil","_offset":"-5:00","_rule":"-","format":"ECT","_until":"","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"1930-12-30T18:46:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);