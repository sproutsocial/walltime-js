/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Stanley].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/Stanley":[{"name":"Atlantic/Stanley","_offset":"-3:51:24","_rule":"-","format":"LMT","_until":"1890"},{"name":"Atlantic/Stanley","_offset":"-3:51:24","_rule":"-","format":"SMT","_until":"1912 Mar 12"},{"name":"Atlantic/Stanley","_offset":"-4:00","_rule":"Falk","format":"FK%sT","_until":"1983 May"},{"name":"Atlantic/Stanley","_offset":"-3:00","_rule":"Falk","format":"FK%sT","_until":"1985 Sep 15"},{"name":"Atlantic/Stanley","_offset":"-4:00","_rule":"Falk","format":"FK%sT","_until":"2010 Sep 5 02:00"},{"name":"Atlantic/Stanley","_offset":"-3:00","_rule":"-","format":"FKST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);