(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Chagos":[{"name":"Indian/Chagos","_offset":"4:49:40","_rule":"-","format":"LMT","_until":"1907","offset":{"negative":false,"hours":4,"mins":49,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1906-12-31T04:49:39.999Z"}},{"name":"Indian/Chagos","_offset":"5:00","_rule":"-","format":"IOT","_until":"1996","offset":{"negative":false,"hours":5,"mins":0,"secs":0},"range":{"begin":"1906-12-31T04:49:40.000Z","end":"1995-12-31T04:59:59.999Z"}},{"name":"Indian/Chagos","_offset":"6:00","_rule":"-","format":"IOT","_until":"","offset":{"negative":false,"hours":6,"mins":0,"secs":0},"range":{"begin":"1995-12-31T05:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);