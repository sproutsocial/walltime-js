/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Indian-Chagos].js
    
    var tzData = {
        rules: {},
        zones: {"Indian/Chagos":[{"name":"Indian/Chagos","_offset":"4:49:40","_rule":"-","format":"LMT","_until":"1907"},{"name":"Indian/Chagos","_offset":"5:00","_rule":"-","format":"IOT","_until":"1996"},{"name":"Indian/Chagos","_offset":"6:00","_rule":"-","format":"IOT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);