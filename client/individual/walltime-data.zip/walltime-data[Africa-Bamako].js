(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Bamako":[{"name":"Africa/Bamako","_offset":"-0:32:00","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Bamako","_offset":"0:00","_rule":"-","format":"GMT","_until":"1934 Feb 26"},{"name":"Africa/Bamako","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1960 Jun 20"},{"name":"Africa/Bamako","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);