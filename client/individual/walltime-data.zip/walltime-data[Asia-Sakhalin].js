/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Sakhalin].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Sakhalin":[{"name":"Asia/Sakhalin","_offset":"9:30:48","_rule":"-","format":"LMT","_until":"1905 Aug 23"},{"name":"Asia/Sakhalin","_offset":"9:00","_rule":"-","format":"CJT","_until":"1938"},{"name":"Asia/Sakhalin","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Aug 25"},{"name":"Asia/Sakhalin","_offset":"11:00","_rule":"Russia","format":"SAK%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Sakhalin","_offset":"10:00","_rule":"Russia","format":"SAK%sT","_until":"1992 Jan 19 2:00s"},{"name":"Asia/Sakhalin","_offset":"11:00","_rule":"Russia","format":"SAK%sT","_until":"1997 Mar lastSun 2:00s"},{"name":"Asia/Sakhalin","_offset":"10:00","_rule":"Russia","format":"SAK%sT","_until":"2011 Mar 27 2:00s"},{"name":"Asia/Sakhalin","_offset":"11:00","_rule":"-","format":"SAKT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);