(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+1":[{"name":"Etc/GMT+1","_offset":"-1","_rule":"-","format":"GMT+1","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);