(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Curacao":[{"name":"America/Curacao","_offset":"-4:35:44","_rule":"-","format":"LMT","_until":"1912 Feb 12","offset":{"negative":true,"hours":4,"mins":35,"secs":44},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-02-11T19:24:15.999Z"}},{"name":"America/Curacao","_offset":"-4:30","_rule":"-","format":"ANT","_until":"1965","offset":{"negative":true,"hours":4,"mins":30,"secs":0},"range":{"begin":"1912-02-11T19:24:16.000Z","end":"1964-12-30T19:29:59.999Z"}},{"name":"America/Curacao","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1964-12-30T19:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);