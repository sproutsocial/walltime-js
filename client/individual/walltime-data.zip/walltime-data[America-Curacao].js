/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"America/Curacao":[{"name":"America/Curacao","_offset":"-4:35:44","_rule":"-","format":"LMT","_until":"1912 Feb 12"},{"name":"America/Curacao","_offset":"-4:30","_rule":"-","format":"ANT","_until":"1965"},{"name":"America/Curacao","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);