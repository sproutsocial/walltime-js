/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Stockholm].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Stockholm":[{"name":"Europe/Stockholm","_offset":"1:12:12","_rule":"-","format":"LMT","_until":"1879 Jan 1"},{"name":"Europe/Stockholm","_offset":"1:00:14","_rule":"-","format":"SET","_until":"1900 Jan 1"},{"name":"Europe/Stockholm","_offset":"1:00","_rule":"-","format":"CET","_until":"1916 May 14 23:00"},{"name":"Europe/Stockholm","_offset":"1:00","_rule":"1:00","format":"CEST","_until":"1916 Oct 1 01:00"},{"name":"Europe/Stockholm","_offset":"1:00","_rule":"-","format":"CET","_until":"1980"},{"name":"Europe/Stockholm","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);