(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Wake":[{"name":"Pacific/Wake","_offset":"11:06:28","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Wake","_offset":"12:00","_rule":"-","format":"WAKT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);