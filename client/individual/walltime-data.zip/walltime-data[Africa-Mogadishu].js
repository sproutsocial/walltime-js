(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Mogadishu":[{"name":"Africa/Mogadishu","_offset":"3:01:28","_rule":"-","format":"LMT","_until":"1893 Nov"},{"name":"Africa/Mogadishu","_offset":"3:00","_rule":"-","format":"EAT","_until":"1931"},{"name":"Africa/Mogadishu","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1957"},{"name":"Africa/Mogadishu","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);