(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Mogadishu":[{"name":"Africa/Mogadishu","_offset":"3:01:28","_rule":"-","format":"LMT","_until":"1893 Nov","offset":{"negative":false,"hours":3,"mins":1,"secs":28},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1893-10-31T03:01:27.999Z"}},{"name":"Africa/Mogadishu","_offset":"3:00","_rule":"-","format":"EAT","_until":"1931","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1893-10-31T03:01:28.000Z","end":"1930-12-31T02:59:59.999Z"}},{"name":"Africa/Mogadishu","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1957","offset":{"negative":false,"hours":2,"mins":30,"secs":0},"range":{"begin":"1930-12-31T03:00:00.000Z","end":"1956-12-31T02:29:59.999Z"}},{"name":"Africa/Mogadishu","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1956-12-31T02:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);