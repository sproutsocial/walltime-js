(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {"Ghana":[{"name":"Ghana","_from":"1936","_to":"1942","type":"-","in":"Sep","on":"1","at":"0:00","_save":"0:20","letter":"GHST","from":1936,"isMax":false,"to":1942,"save":{"hours":0,"mins":20}},{"name":"Ghana","_from":"1936","_to":"1942","type":"-","in":"Dec","on":"31","at":"0:00","_save":"0","letter":"GMT","from":1936,"isMax":false,"to":1942,"save":{"hours":0,"mins":0}}]},
        zones: {"Africa/Accra":[{"name":"Africa/Accra","_offset":"-0:00:52","_rule":"-","format":"LMT","_until":"1918","offset":{"negative":true,"hours":0,"mins":0,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1917-12-30T23:59:07.999Z"}},{"name":"Africa/Accra","_offset":"0:00","_rule":"Ghana","format":"%s","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1917-12-30T23:59:08.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);