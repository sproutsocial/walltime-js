/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Galapagos].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Galapagos":[{"name":"Pacific/Galapagos","_offset":"-5:58:24","_rule":"-","format":"LMT","_until":"1931"},{"name":"Pacific/Galapagos","_offset":"-5:00","_rule":"-","format":"ECT","_until":"1986"},{"name":"Pacific/Galapagos","_offset":"-6:00","_rule":"-","format":"GALT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);