(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Galapagos":[{"name":"Pacific/Galapagos","_offset":"-5:58:24","_rule":"-","format":"LMT","_until":"1931"},{"name":"Pacific/Galapagos","_offset":"-5:00","_rule":"-","format":"ECT","_until":"1986"},{"name":"Pacific/Galapagos","_offset":"-6:00","_rule":"-","format":"GALT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);