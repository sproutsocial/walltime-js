(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Galapagos":[{"name":"Pacific/Galapagos","_offset":"-5:58:24","_rule":"-","format":"LMT","_until":"1931","offset":{"negative":true,"hours":5,"mins":58,"secs":24},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1930-12-30T18:01:35.999Z"}},{"name":"Pacific/Galapagos","_offset":"-5:00","_rule":"-","format":"ECT","_until":"1986","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"1930-12-30T18:01:36.000Z","end":"1985-12-30T18:59:59.999Z"}},{"name":"Pacific/Galapagos","_offset":"-6:00","_rule":"-","format":"GALT","_until":"","offset":{"negative":true,"hours":6,"mins":0,"secs":0},"range":{"begin":"1985-12-30T19:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);