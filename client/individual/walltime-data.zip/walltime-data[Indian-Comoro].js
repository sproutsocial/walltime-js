/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Indian/Comoro":[{"name":"Indian/Comoro","_offset":"2:53:04","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"Indian/Comoro","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);