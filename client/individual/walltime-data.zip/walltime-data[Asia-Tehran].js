/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Tehran].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Tehran":[{"name":"Asia/Tehran","_offset":"3:25:44","_rule":"-","format":"LMT","_until":"1916"},{"name":"Asia/Tehran","_offset":"3:25:44","_rule":"-","format":"TMT","_until":"1946"},{"name":"Asia/Tehran","_offset":"3:30","_rule":"-","format":"IRST","_until":"1977 Nov"},{"name":"Asia/Tehran","_offset":"4:00","_rule":"Iran","format":"IR%sT","_until":"1979"},{"name":"Asia/Tehran","_offset":"3:30","_rule":"Iran","format":"IR%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);