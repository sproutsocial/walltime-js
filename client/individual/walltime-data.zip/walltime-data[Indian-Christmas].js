(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Christmas":[{"name":"Indian/Christmas","_offset":"7:02:52","_rule":"-","format":"LMT","_until":"1895 Feb","offset":{"negative":false,"hours":7,"mins":2,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1895-01-31T07:02:51.999Z"}},{"name":"Indian/Christmas","_offset":"7:00","_rule":"-","format":"CXT","_until":"","offset":{"negative":false,"hours":7,"mins":0,"secs":0},"range":{"begin":"1895-01-31T07:02:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);