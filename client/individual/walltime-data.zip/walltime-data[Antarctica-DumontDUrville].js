(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/DumontDUrville":[{"name":"Antarctica/DumontDUrville","_offset":"0","_rule":"-","format":"zzz","_until":"1947"},{"name":"Antarctica/DumontDUrville","_offset":"10:00","_rule":"-","format":"PMT","_until":"1952 Jan 14"},{"name":"Antarctica/DumontDUrville","_offset":"0","_rule":"-","format":"zzz","_until":"1956 Nov"},{"name":"Antarctica/DumontDUrville","_offset":"10:00","_rule":"-","format":"DDUT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);