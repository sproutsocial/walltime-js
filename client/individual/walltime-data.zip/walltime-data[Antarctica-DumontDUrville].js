(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/DumontDUrville":[{"name":"Antarctica/DumontDUrville","_offset":"0","_rule":"-","format":"zzz","_until":"1947","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1946-12-30T23:59:59.999Z"}},{"name":"Antarctica/DumontDUrville","_offset":"10:00","_rule":"-","format":"PMT","_until":"1952 Jan 14","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"1946-12-31T00:00:00.000Z","end":"1952-01-14T09:59:59.999Z"}},{"name":"Antarctica/DumontDUrville","_offset":"0","_rule":"-","format":"zzz","_until":"1956 Nov","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"1952-01-14T10:00:00.000Z","end":"1956-10-30T23:59:59.999Z"}},{"name":"Antarctica/DumontDUrville","_offset":"10:00","_rule":"-","format":"DDUT","_until":"","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"1956-10-31T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);