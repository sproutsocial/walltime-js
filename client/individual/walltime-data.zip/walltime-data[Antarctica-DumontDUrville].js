/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-DumontDUrville].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/DumontDUrville":[{"name":"Antarctica/DumontDUrville","_offset":"0","_rule":"-","format":"zzz","_until":"1947"},{"name":"Antarctica/DumontDUrville","_offset":"10:00","_rule":"-","format":"PMT","_until":"1952 Jan 14"},{"name":"Antarctica/DumontDUrville","_offset":"0","_rule":"-","format":"zzz","_until":"1956 Nov"},{"name":"Antarctica/DumontDUrville","_offset":"10:00","_rule":"-","format":"DDUT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);