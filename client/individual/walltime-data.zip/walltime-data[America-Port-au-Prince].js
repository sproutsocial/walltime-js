/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Port-au-Prince].js
    
    var tzData = {
        rules: {"Haiti":[{"name":"Haiti","_from":"1983","_to":"only","type":"-","in":"May","on":"8","at":"0:00","_save":"1:00","letter":"D"},{"name":"Haiti","_from":"1984","_to":"1987","type":"-","in":"Apr","on":"lastSun","at":"0:00","_save":"1:00","letter":"D"},{"name":"Haiti","_from":"1983","_to":"1987","type":"-","in":"Oct","on":"lastSun","at":"0:00","_save":"0","letter":"S"},{"name":"Haiti","_from":"1988","_to":"1997","type":"-","in":"Apr","on":"Sun>=1","at":"1:00s","_save":"1:00","letter":"D"},{"name":"Haiti","_from":"1988","_to":"1997","type":"-","in":"Oct","on":"lastSun","at":"1:00s","_save":"0","letter":"S"},{"name":"Haiti","_from":"2005","_to":"2006","type":"-","in":"Apr","on":"Sun>=1","at":"0:00","_save":"1:00","letter":"D"},{"name":"Haiti","_from":"2005","_to":"2006","type":"-","in":"Oct","on":"lastSun","at":"0:00","_save":"0","letter":"S"},{"name":"Haiti","_from":"2012","_to":"max","type":"-","in":"Mar","on":"Sun>=8","at":"2:00","_save":"1:00","letter":"D"},{"name":"Haiti","_from":"2012","_to":"max","type":"-","in":"Nov","on":"Sun>=1","at":"2:00","_save":"0","letter":"S"}]},
        zones: {"America/Port-au-Prince":[{"name":"America/Port-au-Prince","_offset":"-4:49:20","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Port-au-Prince","_offset":"-4:49","_rule":"-","format":"PPMT","_until":"1917 Jan 24 12:00"},{"name":"America/Port-au-Prince","_offset":"-5:00","_rule":"Haiti","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);