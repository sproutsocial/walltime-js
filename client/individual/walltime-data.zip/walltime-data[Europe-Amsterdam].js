/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Amsterdam].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Amsterdam":[{"name":"Europe/Amsterdam","_offset":"0:19:32","_rule":"-","format":"LMT","_until":"1835"},{"name":"Europe/Amsterdam","_offset":"0:19:32","_rule":"Neth","format":"%s","_until":"1937 Jul 1"},{"name":"Europe/Amsterdam","_offset":"0:20","_rule":"Neth","format":"NE%sT","_until":"1940 May 16 0:00"},{"name":"Europe/Amsterdam","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945 Apr 2 2:00"},{"name":"Europe/Amsterdam","_offset":"1:00","_rule":"Neth","format":"CE%sT","_until":"1977"},{"name":"Europe/Amsterdam","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);