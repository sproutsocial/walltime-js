(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Addis_Ababa":[{"name":"Africa/Addis_Ababa","_offset":"2:34:48","_rule":"-","format":"LMT","_until":"1870"},{"name":"Africa/Addis_Ababa","_offset":"2:35:20","_rule":"-","format":"ADMT","_until":"1936 May 5"},{"name":"Africa/Addis_Ababa","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);