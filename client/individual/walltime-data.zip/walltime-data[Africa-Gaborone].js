/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Gaborone].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Gaborone":[{"name":"Africa/Gaborone","_offset":"1:43:40","_rule":"-","format":"LMT","_until":"1885"},{"name":"Africa/Gaborone","_offset":"1:30","_rule":"-","format":"SAST","_until":"1903 Mar"},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"-","format":"CAT","_until":"1943 Sep 19 2:00"},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"1:00","format":"CAST","_until":"1944 Mar 19 2:00"},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);