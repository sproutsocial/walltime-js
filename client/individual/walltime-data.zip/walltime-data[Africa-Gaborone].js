(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Gaborone":[{"name":"Africa/Gaborone","_offset":"1:43:40","_rule":"-","format":"LMT","_until":"1885","offset":{"negative":false,"hours":1,"mins":43,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1884-12-31T01:43:39.999Z"}},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"-","format":"CAT","_until":"1943 Sep 19 2:00","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1884-12-31T01:43:40.000Z","end":"1943-09-19T03:59:59.999Z"}},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"1:00","format":"CAST","_until":"1944 Mar 19 2:00","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1943-09-19T04:00:00.000Z","end":"1944-03-19T03:59:59.999Z"}},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"-","format":"CAT","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1944-03-19T04:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);