(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Gaborone":[{"name":"Africa/Gaborone","_offset":"1:43:40","_rule":"-","format":"LMT","_until":"1885"},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"-","format":"CAT","_until":"1943 Sep 19 2:00"},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"1:00","format":"CAST","_until":"1944 Mar 19 2:00"},{"name":"Africa/Gaborone","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);