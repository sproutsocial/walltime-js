/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Detroit].js
    
    var tzData = {
        rules: {},
        zones: {"America/Detroit":[{"name":"America/Detroit","_offset":"-5:32:11","_rule":"-","format":"LMT","_until":"1905"},{"name":"America/Detroit","_offset":"-6:00","_rule":"-","format":"CST","_until":"1915 May 15 2:00"},{"name":"America/Detroit","_offset":"-5:00","_rule":"-","format":"EST","_until":"1942"},{"name":"America/Detroit","_offset":"-5:00","_rule":"US","format":"E%sT","_until":"1946"},{"name":"America/Detroit","_offset":"-5:00","_rule":"Detroit","format":"E%sT","_until":"1973"},{"name":"America/Detroit","_offset":"-5:00","_rule":"US","format":"E%sT","_until":"1975"},{"name":"America/Detroit","_offset":"-5:00","_rule":"-","format":"EST","_until":"1975 Apr 27 2:00"},{"name":"America/Detroit","_offset":"-5:00","_rule":"US","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);