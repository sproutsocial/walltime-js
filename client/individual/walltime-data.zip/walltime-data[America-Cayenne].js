(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Cayenne":[{"name":"America/Cayenne","_offset":"-3:29:20","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"America/Cayenne","_offset":"-4:00","_rule":"-","format":"GFT","_until":"1967 Oct"},{"name":"America/Cayenne","_offset":"-3:00","_rule":"-","format":"GFT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);