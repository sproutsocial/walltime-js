/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"America/Cayenne":[{"name":"America/Cayenne","_offset":"-3:29:20","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"America/Cayenne","_offset":"-4:00","_rule":"-","format":"GFT","_until":"1967 Oct"},{"name":"America/Cayenne","_offset":"-3:00","_rule":"-","format":"GFT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);