(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Cayenne":[{"name":"America/Cayenne","_offset":"-3:29:20","_rule":"-","format":"LMT","_until":"1911 Jul","offset":{"negative":true,"hours":3,"mins":29,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-06-29T20:30:39.999Z"}},{"name":"America/Cayenne","_offset":"-4:00","_rule":"-","format":"GFT","_until":"1967 Oct","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1911-06-29T20:30:40.000Z","end":"1967-09-29T19:59:59.999Z"}},{"name":"America/Cayenne","_offset":"-3:00","_rule":"-","format":"GFT","_until":"","offset":{"negative":true,"hours":3,"mins":0,"secs":0},"range":{"begin":"1967-09-29T20:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);