(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Brunei":[{"name":"Asia/Brunei","_offset":"7:39:40","_rule":"-","format":"LMT","_until":"1926 Mar"},{"name":"Asia/Brunei","_offset":"7:30","_rule":"-","format":"BNT","_until":"1933"},{"name":"Asia/Brunei","_offset":"8:00","_rule":"-","format":"BNT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);