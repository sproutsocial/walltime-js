(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Brunei":[{"name":"Asia/Brunei","_offset":"7:39:40","_rule":"-","format":"LMT","_until":"1926 Mar","offset":{"negative":false,"hours":7,"mins":39,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1926-02-28T07:39:39.999Z"}},{"name":"Asia/Brunei","_offset":"7:30","_rule":"-","format":"BNT","_until":"1933","offset":{"negative":false,"hours":7,"mins":30,"secs":0},"range":{"begin":"1926-02-28T07:39:40.000Z","end":"1932-12-31T07:29:59.999Z"}},{"name":"Asia/Brunei","_offset":"8:00","_rule":"-","format":"BNT","_until":"","offset":{"negative":false,"hours":8,"mins":0,"secs":0},"range":{"begin":"1932-12-31T07:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);