/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Brunei":[{"name":"Asia/Brunei","_offset":"7:39:40","_rule":"-","format":"LMT","_until":"1926 Mar"},{"name":"Asia/Brunei","_offset":"7:30","_rule":"-","format":"BNT","_until":"1933"},{"name":"Asia/Brunei","_offset":"8:00","_rule":"-","format":"BNT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);