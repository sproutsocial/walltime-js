/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Nipigon].js
    
    var tzData = {
        rules: {},
        zones: {"America/Nipigon":[{"name":"America/Nipigon","_offset":"-5:53:04","_rule":"-","format":"LMT","_until":"1895"},{"name":"America/Nipigon","_offset":"-5:00","_rule":"Canada","format":"E%sT","_until":"1940 Sep 29"},{"name":"America/Nipigon","_offset":"-5:00","_rule":"1:00","format":"EDT","_until":"1942 Feb 9 2:00s"},{"name":"America/Nipigon","_offset":"-5:00","_rule":"Canada","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);