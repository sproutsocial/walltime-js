/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Montevideo].js
    
    var tzData = {
        rules: {},
        zones: {"America/Montevideo":[{"name":"America/Montevideo","_offset":"-3:44:44","_rule":"-","format":"LMT","_until":"1898 Jun 28"},{"name":"America/Montevideo","_offset":"-3:44:44","_rule":"-","format":"MMT","_until":"1920 May 1"},{"name":"America/Montevideo","_offset":"-3:30","_rule":"Uruguay","format":"UY%sT","_until":"1942 Dec 14"},{"name":"America/Montevideo","_offset":"-3:00","_rule":"Uruguay","format":"UY%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);