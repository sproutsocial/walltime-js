/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Anadyr].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Anadyr":[{"name":"Asia/Anadyr","_offset":"11:49:56","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Anadyr","_offset":"12:00","_rule":"-","format":"ANAT","_until":"1930 Jun 21"},{"name":"Asia/Anadyr","_offset":"13:00","_rule":"Russia","format":"ANA%sT","_until":"1982 Apr 1 0:00s"},{"name":"Asia/Anadyr","_offset":"12:00","_rule":"Russia","format":"ANA%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Anadyr","_offset":"11:00","_rule":"Russia","format":"ANA%sT","_until":"1992 Jan 19 2:00s"},{"name":"Asia/Anadyr","_offset":"12:00","_rule":"Russia","format":"ANA%sT","_until":"2010 Mar 28 2:00s"},{"name":"Asia/Anadyr","_offset":"11:00","_rule":"Russia","format":"ANA%sT","_until":"2011 Mar 27 2:00s"},{"name":"Asia/Anadyr","_offset":"12:00","_rule":"-","format":"ANAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);