(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Sao_Tome":[{"name":"Africa/Sao_Tome","_offset":"0:26:56","_rule":"-","format":"LMT","_until":"1884","offset":{"negative":false,"hours":0,"mins":26,"secs":56},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1883-12-31T00:26:55.999Z"}},{"name":"Africa/Sao_Tome","_offset":"-0:36:32","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":true,"hours":0,"mins":36,"secs":32},"range":{"begin":"1883-12-31T00:26:56.000Z","end":"1911-12-30T23:23:27.999Z"}},{"name":"Africa/Sao_Tome","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1911-12-30T23:23:28.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);