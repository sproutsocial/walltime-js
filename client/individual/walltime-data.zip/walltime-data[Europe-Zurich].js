/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Zurich].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Zurich":[{"name":"Europe/Zurich","_offset":"0:34:08","_rule":"-","format":"LMT","_until":"1848 Sep 12"},{"name":"Europe/Zurich","_offset":"0:29:44","_rule":"-","format":"BMT","_until":"1894 Jun"},{"name":"Europe/Zurich","_offset":"1:00","_rule":"Swiss","format":"CE%sT","_until":"1981"},{"name":"Europe/Zurich","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);