/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Pyongyang":[{"name":"Asia/Pyongyang","_offset":"8:23:00","_rule":"-","format":"LMT","_until":"1890"},{"name":"Asia/Pyongyang","_offset":"8:30","_rule":"-","format":"KST","_until":"1904 Dec"},{"name":"Asia/Pyongyang","_offset":"9:00","_rule":"-","format":"KST","_until":"1928"},{"name":"Asia/Pyongyang","_offset":"8:30","_rule":"-","format":"KST","_until":"1932"},{"name":"Asia/Pyongyang","_offset":"9:00","_rule":"-","format":"KST","_until":"1954 Mar 21"},{"name":"Asia/Pyongyang","_offset":"8:00","_rule":"-","format":"KST","_until":"1961 Aug 10"},{"name":"Asia/Pyongyang","_offset":"9:00","_rule":"-","format":"KST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);