/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Pyongyang].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Pyongyang":[{"name":"Asia/Pyongyang","_offset":"8:23:00","_rule":"-","format":"LMT","_until":"1890"},{"name":"Asia/Pyongyang","_offset":"8:30","_rule":"-","format":"KST","_until":"1904 Dec"},{"name":"Asia/Pyongyang","_offset":"9:00","_rule":"-","format":"KST","_until":"1928"},{"name":"Asia/Pyongyang","_offset":"8:30","_rule":"-","format":"KST","_until":"1932"},{"name":"Asia/Pyongyang","_offset":"9:00","_rule":"-","format":"KST","_until":"1954 Mar 21"},{"name":"Asia/Pyongyang","_offset":"8:00","_rule":"-","format":"KST","_until":"1961 Aug 10"},{"name":"Asia/Pyongyang","_offset":"9:00","_rule":"-","format":"KST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);