/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Zaporozhye].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Zaporozhye":[{"name":"Europe/Zaporozhye","_offset":"2:20:40","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Zaporozhye","_offset":"2:20","_rule":"-","format":"CUT","_until":"1924 May 2"},{"name":"Europe/Zaporozhye","_offset":"2:00","_rule":"-","format":"EET","_until":"1930 Jun 21"},{"name":"Europe/Zaporozhye","_offset":"3:00","_rule":"-","format":"MSK","_until":"1941 Aug 25"},{"name":"Europe/Zaporozhye","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1943 Oct 25"},{"name":"Europe/Zaporozhye","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1991 Mar 31 2:00"},{"name":"Europe/Zaporozhye","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1995"},{"name":"Europe/Zaporozhye","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);