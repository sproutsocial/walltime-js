(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Panama":[{"name":"America/Panama","_offset":"-5:18:08","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Panama","_offset":"-5:19:36","_rule":"-","format":"CMT","_until":"1908 Apr 22"},{"name":"America/Panama","_offset":"-5:00","_rule":"-","format":"EST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);