(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Panama":[{"name":"America/Panama","_offset":"-5:18:08","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":5,"mins":18,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T18:41:51.999Z"}},{"name":"America/Panama","_offset":"-5:19:36","_rule":"-","format":"CMT","_until":"1908 Apr 22","offset":{"negative":true,"hours":5,"mins":19,"secs":36},"range":{"begin":"1889-12-30T18:41:52.000Z","end":"1908-04-21T18:40:23.999Z"}},{"name":"America/Panama","_offset":"-5:00","_rule":"-","format":"EST","_until":"","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"1908-04-21T18:40:24.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);