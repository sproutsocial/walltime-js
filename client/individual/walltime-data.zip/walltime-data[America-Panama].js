/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"America/Panama":[{"name":"America/Panama","_offset":"-5:18:08","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Panama","_offset":"-5:19:36","_rule":"-","format":"CMT","_until":"1908 Apr 22"},{"name":"America/Panama","_offset":"-5:00","_rule":"-","format":"EST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);