(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Niue":[{"name":"Pacific/Niue","_offset":"-11:19:40","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":true,"hours":11,"mins":19,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-30T12:40:19.999Z"}},{"name":"Pacific/Niue","_offset":"-11:20","_rule":"-","format":"NUT","_until":"1951","offset":{"negative":true,"hours":11,"mins":20,"secs":0},"range":{"begin":"1900-12-30T12:40:20.000Z","end":"1950-12-30T12:39:59.999Z"}},{"name":"Pacific/Niue","_offset":"-11:30","_rule":"-","format":"NUT","_until":"1978 Oct 1","offset":{"negative":true,"hours":11,"mins":30,"secs":0},"range":{"begin":"1950-12-30T12:40:00.000Z","end":"1978-09-30T12:29:59.999Z"}},{"name":"Pacific/Niue","_offset":"-11:00","_rule":"-","format":"NUT","_until":"","offset":{"negative":true,"hours":11,"mins":0,"secs":0},"range":{"begin":"1978-09-30T12:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);