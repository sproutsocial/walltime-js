(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Mahe":[{"name":"Indian/Mahe","_offset":"3:41:48","_rule":"-","format":"LMT","_until":"1906 Jun","offset":{"negative":false,"hours":3,"mins":41,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1906-05-31T03:41:47.999Z"}},{"name":"Indian/Mahe","_offset":"4:00","_rule":"-","format":"SCT","_until":"","offset":{"negative":false,"hours":4,"mins":0,"secs":0},"range":{"begin":"1906-05-31T03:41:48.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);