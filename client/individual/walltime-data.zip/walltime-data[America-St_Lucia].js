(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/St_Lucia":[{"name":"America/St_Lucia","_offset":"-4:04:00","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":4,"mins":4,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T19:55:59.999Z"}},{"name":"America/St_Lucia","_offset":"-4:04:00","_rule":"-","format":"CMT","_until":"1912","offset":{"negative":true,"hours":4,"mins":4,"secs":0},"range":{"begin":"1889-12-30T19:56:00.000Z","end":"1911-12-30T19:55:59.999Z"}},{"name":"America/St_Lucia","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1911-12-30T19:56:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);