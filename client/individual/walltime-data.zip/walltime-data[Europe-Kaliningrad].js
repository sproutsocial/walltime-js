/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Kaliningrad].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Kaliningrad":[{"name":"Europe/Kaliningrad","_offset":"1:22:00","_rule":"-","format":"LMT","_until":"1893 Apr"},{"name":"Europe/Kaliningrad","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945"},{"name":"Europe/Kaliningrad","_offset":"2:00","_rule":"Poland","format":"CE%sT","_until":"1946"},{"name":"Europe/Kaliningrad","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1991 Mar 31 2:00s"},{"name":"Europe/Kaliningrad","_offset":"2:00","_rule":"Russia","format":"EE%sT","_until":"2011 Mar 27 2:00s"},{"name":"Europe/Kaliningrad","_offset":"3:00","_rule":"-","format":"FET","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);