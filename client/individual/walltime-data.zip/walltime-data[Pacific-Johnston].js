(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Johnston":[{"name":"Pacific/Johnston","_offset":"-10:00","_rule":"-","format":"HST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);