(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Johnston":[{"name":"Pacific/Johnston","_offset":"-10:00","_rule":"-","format":"HST","_until":"","offset":{"negative":true,"hours":10,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);