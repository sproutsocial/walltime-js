(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Marquesas":[{"name":"Pacific/Marquesas","_offset":"-9:18:00","_rule":"-","format":"LMT","_until":"1912 Oct","offset":{"negative":true,"hours":9,"mins":18,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-09-29T14:41:59.999Z"}},{"name":"Pacific/Marquesas","_offset":"-9:30","_rule":"-","format":"MART","_until":"","offset":{"negative":true,"hours":9,"mins":30,"secs":0},"range":{"begin":"1912-09-29T14:42:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);