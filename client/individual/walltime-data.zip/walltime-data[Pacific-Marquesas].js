/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Marquesas":[{"name":"Pacific/Marquesas","_offset":"-9:18:00","_rule":"-","format":"LMT","_until":"1912 Oct"},{"name":"Pacific/Marquesas","_offset":"-9:30","_rule":"-","format":"MART","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);