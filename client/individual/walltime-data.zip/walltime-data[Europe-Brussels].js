/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Brussels].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Brussels":[{"name":"Europe/Brussels","_offset":"0:17:30","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Brussels","_offset":"0:17:30","_rule":"-","format":"BMT","_until":"1892 May 1 12:00"},{"name":"Europe/Brussels","_offset":"0:00","_rule":"-","format":"WET","_until":"1914 Nov 8"},{"name":"Europe/Brussels","_offset":"1:00","_rule":"-","format":"CET","_until":"1916 May 1 0:00"},{"name":"Europe/Brussels","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1918 Nov 11 11:00u"},{"name":"Europe/Brussels","_offset":"0:00","_rule":"Belgium","format":"WE%sT","_until":"1940 May 20 2:00s"},{"name":"Europe/Brussels","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Sep 3"},{"name":"Europe/Brussels","_offset":"1:00","_rule":"Belgium","format":"CE%sT","_until":"1977"},{"name":"Europe/Brussels","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);