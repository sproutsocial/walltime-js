/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Guam":[{"name":"Pacific/Guam","_offset":"-14:21:00","_rule":"-","format":"LMT","_until":"1844 Dec 31"},{"name":"Pacific/Guam","_offset":"9:39:00","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Guam","_offset":"10:00","_rule":"-","format":"GST","_until":"2000 Dec 23"},{"name":"Pacific/Guam","_offset":"10:00","_rule":"-","format":"ChST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);