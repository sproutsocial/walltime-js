(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Guam":[{"name":"Pacific/Guam","_offset":"-14:21:00","_rule":"-","format":"LMT","_until":"1844 Dec 31","offset":{"negative":true,"hours":14,"mins":21,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1844-12-30T09:38:59.999Z"}},{"name":"Pacific/Guam","_offset":"9:39:00","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":9,"mins":39,"secs":0},"range":{"begin":"1844-12-30T09:39:00.000Z","end":"1900-12-31T09:38:59.999Z"}},{"name":"Pacific/Guam","_offset":"10:00","_rule":"-","format":"GST","_until":"2000 Dec 23","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"1900-12-31T09:39:00.000Z","end":"2000-12-23T09:59:59.999Z"}},{"name":"Pacific/Guam","_offset":"10:00","_rule":"-","format":"ChST","_until":"","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"2000-12-23T10:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);