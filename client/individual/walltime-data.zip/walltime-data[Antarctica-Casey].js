/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Casey].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/Casey":[{"name":"Antarctica/Casey","_offset":"0","_rule":"-","format":"zzz","_until":"1969"},{"name":"Antarctica/Casey","_offset":"8:00","_rule":"-","format":"WST","_until":"2009 Oct 18 2:00"},{"name":"Antarctica/Casey","_offset":"11:00","_rule":"-","format":"CAST","_until":"2010 Mar 5 2:00"},{"name":"Antarctica/Casey","_offset":"8:00","_rule":"-","format":"WST","_until":"2011 Oct 28 2:00"},{"name":"Antarctica/Casey","_offset":"11:00","_rule":"-","format":"CAST","_until":"2012 Feb 21 17:00u"},{"name":"Antarctica/Casey","_offset":"8:00","_rule":"-","format":"WST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);