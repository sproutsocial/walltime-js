/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Godthab].js
    
    var tzData = {
        rules: {},
        zones: {"America/Godthab":[{"name":"America/Godthab","_offset":"-3:26:56","_rule":"-","format":"LMT","_until":"1916 Jul 28"},{"name":"America/Godthab","_offset":"-3:00","_rule":"-","format":"WGT","_until":"1980 Apr 6 2:00"},{"name":"America/Godthab","_offset":"-3:00","_rule":"EU","format":"WG%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);