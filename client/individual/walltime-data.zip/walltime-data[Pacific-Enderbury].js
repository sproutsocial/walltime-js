(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Enderbury":[{"name":"Pacific/Enderbury","_offset":"-11:24:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Enderbury","_offset":"-12:00","_rule":"-","format":"PHOT","_until":"1979 Oct"},{"name":"Pacific/Enderbury","_offset":"-11:00","_rule":"-","format":"PHOT","_until":"1995"},{"name":"Pacific/Enderbury","_offset":"13:00","_rule":"-","format":"PHOT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);