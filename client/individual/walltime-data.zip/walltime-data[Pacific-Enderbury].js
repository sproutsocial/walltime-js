(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Enderbury":[{"name":"Pacific/Enderbury","_offset":"-11:24:20","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":true,"hours":11,"mins":24,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-30T12:35:39.999Z"}},{"name":"Pacific/Enderbury","_offset":"-12:00","_rule":"-","format":"PHOT","_until":"1979 Oct","offset":{"negative":true,"hours":12,"mins":0,"secs":0},"range":{"begin":"1900-12-30T12:35:40.000Z","end":"1979-09-29T11:59:59.999Z"}},{"name":"Pacific/Enderbury","_offset":"-11:00","_rule":"-","format":"PHOT","_until":"1995","offset":{"negative":true,"hours":11,"mins":0,"secs":0},"range":{"begin":"1979-09-29T12:00:00.000Z","end":"1994-12-30T12:59:59.999Z"}},{"name":"Pacific/Enderbury","_offset":"13:00","_rule":"-","format":"PHOT","_until":"","offset":{"negative":false,"hours":13,"mins":0,"secs":0},"range":{"begin":"1994-12-30T13:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);