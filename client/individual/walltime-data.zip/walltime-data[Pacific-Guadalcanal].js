(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Guadalcanal":[{"name":"Pacific/Guadalcanal","_offset":"10:39:48","_rule":"-","format":"LMT","_until":"1912 Oct","offset":{"negative":false,"hours":10,"mins":39,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-09-30T10:39:47.999Z"}},{"name":"Pacific/Guadalcanal","_offset":"11:00","_rule":"-","format":"SBT","_until":"","offset":{"negative":false,"hours":11,"mins":0,"secs":0},"range":{"begin":"1912-09-30T10:39:48.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);