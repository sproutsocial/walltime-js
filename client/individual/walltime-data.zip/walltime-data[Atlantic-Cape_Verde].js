(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Atlantic/Cape_Verde":[{"name":"Atlantic/Cape_Verde","_offset":"-1:34:04","_rule":"-","format":"LMT","_until":"1907","offset":{"negative":true,"hours":1,"mins":34,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1906-12-30T22:25:55.999Z"}},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"-","format":"CVT","_until":"1942 Sep","offset":{"negative":true,"hours":2,"mins":0,"secs":0},"range":{"begin":"1906-12-30T22:25:56.000Z","end":"1942-08-30T21:59:59.999Z"}},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"1:00","format":"CVST","_until":"1945 Oct 15","offset":{"negative":true,"hours":2,"mins":0,"secs":0},"range":{"begin":"1942-08-30T22:00:00.000Z","end":"1945-10-14T21:59:59.999Z"}},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"-","format":"CVT","_until":"1975 Nov 25 2:00","offset":{"negative":true,"hours":2,"mins":0,"secs":0},"range":{"begin":"1945-10-14T22:00:00.000Z","end":"1975-11-24T23:59:59.999Z"}},{"name":"Atlantic/Cape_Verde","_offset":"-1:00","_rule":"-","format":"CVT","_until":"","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1975-11-25T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);