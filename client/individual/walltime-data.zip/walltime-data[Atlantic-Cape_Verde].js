/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Atlantic/Cape_Verde":[{"name":"Atlantic/Cape_Verde","_offset":"-1:34:04","_rule":"-","format":"LMT","_until":"1907"},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"-","format":"CVT","_until":"1942 Sep"},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"1:00","format":"CVST","_until":"1945 Oct 15"},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"-","format":"CVT","_until":"1975 Nov 25 2:00"},{"name":"Atlantic/Cape_Verde","_offset":"-1:00","_rule":"-","format":"CVT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);