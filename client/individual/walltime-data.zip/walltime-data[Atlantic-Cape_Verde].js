/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Cape_Verde].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/Cape_Verde":[{"name":"Atlantic/Cape_Verde","_offset":"-1:34:04","_rule":"-","format":"LMT","_until":"1907"},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"-","format":"CVT","_until":"1942 Sep"},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"1:00","format":"CVST","_until":"1945 Oct 15"},{"name":"Atlantic/Cape_Verde","_offset":"-2:00","_rule":"-","format":"CVT","_until":"1975 Nov 25 2:00"},{"name":"Atlantic/Cape_Verde","_offset":"-1:00","_rule":"-","format":"CVT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);