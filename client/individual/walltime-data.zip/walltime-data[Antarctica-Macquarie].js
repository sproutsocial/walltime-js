/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Macquarie].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/Macquarie":[{"name":"Antarctica/Macquarie","_offset":"0","_rule":"-","format":"zzz","_until":"1899 Nov"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"-","format":"EST","_until":"1916 Oct 1 2:00"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"1:00","format":"EST","_until":"1917 Feb"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"Aus","format":"EST","_until":"1919 Apr 1 0:00s"},{"name":"Antarctica/Macquarie","_offset":"0","_rule":"-","format":"zzz","_until":"1948 Mar 25"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"Aus","format":"EST","_until":"1967"},{"name":"Antarctica/Macquarie","_offset":"10:00","_rule":"AT","format":"EST","_until":"2010 Apr 4 3:00"},{"name":"Antarctica/Macquarie","_offset":"11:00","_rule":"-","format":"MIST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);