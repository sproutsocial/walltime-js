/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Monrovia":[{"name":"Africa/Monrovia","_offset":"-0:43:08","_rule":"-","format":"LMT","_until":"1882"},{"name":"Africa/Monrovia","_offset":"-0:43:08","_rule":"-","format":"MMT","_until":"1919 Mar"},{"name":"Africa/Monrovia","_offset":"-0:44:30","_rule":"-","format":"LRT","_until":"1972 May"},{"name":"Africa/Monrovia","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);