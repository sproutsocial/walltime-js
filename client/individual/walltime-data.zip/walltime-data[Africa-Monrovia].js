(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Monrovia":[{"name":"Africa/Monrovia","_offset":"-0:43:08","_rule":"-","format":"LMT","_until":"1882","offset":{"negative":true,"hours":0,"mins":43,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1881-12-30T23:16:51.999Z"}},{"name":"Africa/Monrovia","_offset":"-0:43:08","_rule":"-","format":"MMT","_until":"1919 Mar","offset":{"negative":true,"hours":0,"mins":43,"secs":8},"range":{"begin":"1881-12-30T23:16:52.000Z","end":"1919-02-27T23:16:51.999Z"}},{"name":"Africa/Monrovia","_offset":"-0:44:30","_rule":"-","format":"LRT","_until":"1972 May","offset":{"negative":true,"hours":0,"mins":44,"secs":30},"range":{"begin":"1919-02-27T23:16:52.000Z","end":"1972-04-29T23:15:29.999Z"}},{"name":"Africa/Monrovia","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1972-04-29T23:15:30.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);