(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Jayapura":[{"name":"Asia/Jayapura","_offset":"9:22:48","_rule":"-","format":"LMT","_until":"1932 Nov","offset":{"negative":false,"hours":9,"mins":22,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1932-10-31T09:22:47.999Z"}},{"name":"Asia/Jayapura","_offset":"9:00","_rule":"-","format":"EIT","_until":"1944 Sep 1","offset":{"negative":false,"hours":9,"mins":0,"secs":0},"range":{"begin":"1932-10-31T09:22:48.000Z","end":"1944-09-01T08:59:59.999Z"}},{"name":"Asia/Jayapura","_offset":"9:30","_rule":"-","format":"CST","_until":"1964","offset":{"negative":false,"hours":9,"mins":30,"secs":0},"range":{"begin":"1944-09-01T09:00:00.000Z","end":"1963-12-31T09:29:59.999Z"}},{"name":"Asia/Jayapura","_offset":"9:00","_rule":"-","format":"EIT","_until":"","offset":{"negative":false,"hours":9,"mins":0,"secs":0},"range":{"begin":"1963-12-31T09:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);