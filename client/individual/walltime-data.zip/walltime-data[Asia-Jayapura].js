/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Jayapura":[{"name":"Asia/Jayapura","_offset":"9:22:48","_rule":"-","format":"LMT","_until":"1932 Nov"},{"name":"Asia/Jayapura","_offset":"9:00","_rule":"-","format":"EIT","_until":"1944 Sep 1"},{"name":"Asia/Jayapura","_offset":"9:30","_rule":"-","format":"CST","_until":"1964"},{"name":"Asia/Jayapura","_offset":"9:00","_rule":"-","format":"EIT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);