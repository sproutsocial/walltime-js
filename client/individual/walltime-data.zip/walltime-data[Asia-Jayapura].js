(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Jayapura":[{"name":"Asia/Jayapura","_offset":"9:22:48","_rule":"-","format":"LMT","_until":"1932 Nov"},{"name":"Asia/Jayapura","_offset":"9:00","_rule":"-","format":"EIT","_until":"1944 Sep 1"},{"name":"Asia/Jayapura","_offset":"9:30","_rule":"-","format":"CST","_until":"1964"},{"name":"Asia/Jayapura","_offset":"9:00","_rule":"-","format":"EIT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);