(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/St_Thomas":[{"name":"America/St_Thomas","_offset":"-4:19:44","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"America/St_Thomas","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);