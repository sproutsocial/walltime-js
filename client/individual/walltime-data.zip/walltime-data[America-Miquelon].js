/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Miquelon].js
    
    var tzData = {
        rules: {},
        zones: {"America/Miquelon":[{"name":"America/Miquelon","_offset":"-3:44:40","_rule":"-","format":"LMT","_until":"1911 May 15"},{"name":"America/Miquelon","_offset":"-4:00","_rule":"-","format":"AST","_until":"1980 May"},{"name":"America/Miquelon","_offset":"-3:00","_rule":"-","format":"PMST","_until":"1987"},{"name":"America/Miquelon","_offset":"-3:00","_rule":"Canada","format":"PM%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);