(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Caracas":[{"name":"America/Caracas","_offset":"-4:27:44","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Caracas","_offset":"-4:27:40","_rule":"-","format":"CMT","_until":"1912 Feb 12"},{"name":"America/Caracas","_offset":"-4:30","_rule":"-","format":"VET","_until":"1965"},{"name":"America/Caracas","_offset":"-4:00","_rule":"-","format":"VET","_until":"2007 Dec 9 03:00"},{"name":"America/Caracas","_offset":"-4:30","_rule":"-","format":"VET","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);