(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Caracas":[{"name":"America/Caracas","_offset":"-4:27:44","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":4,"mins":27,"secs":44},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T19:32:15.999Z"}},{"name":"America/Caracas","_offset":"-4:27:40","_rule":"-","format":"CMT","_until":"1912 Feb 12","offset":{"negative":true,"hours":4,"mins":27,"secs":40},"range":{"begin":"1889-12-30T19:32:16.000Z","end":"1912-02-11T19:32:19.999Z"}},{"name":"America/Caracas","_offset":"-4:30","_rule":"-","format":"VET","_until":"1965","offset":{"negative":true,"hours":4,"mins":30,"secs":0},"range":{"begin":"1912-02-11T19:32:20.000Z","end":"1964-12-30T19:29:59.999Z"}},{"name":"America/Caracas","_offset":"-4:00","_rule":"-","format":"VET","_until":"2007 Dec 9 03:00","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1964-12-30T19:30:00.000Z","end":"2007-12-08T22:59:59.999Z"}},{"name":"America/Caracas","_offset":"-4:30","_rule":"-","format":"VET","_until":"","offset":{"negative":true,"hours":4,"mins":30,"secs":0},"range":{"begin":"2007-12-08T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);