(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {"NC":[{"name":"NC","_from":"1977","_to":"1978","type":"-","in":"Dec","on":"Sun>=1","at":"0:00","_save":"1:00","letter":"S","from":1977,"isMax":false,"to":1978,"save":{"hours":1,"mins":0}},{"name":"NC","_from":"1978","_to":"1979","type":"-","in":"Feb","on":"27","at":"0:00","_save":"0","letter":"-","from":1978,"isMax":false,"to":1979,"save":{"hours":0,"mins":0}},{"name":"NC","_from":"1996","_to":"only","type":"-","in":"Dec","on":"1","at":"2:00s","_save":"1:00","letter":"S","from":1996,"isMax":false,"to":1996,"save":{"hours":1,"mins":0}},{"name":"NC","_from":"1997","_to":"only","type":"-","in":"Mar","on":"2","at":"2:00s","_save":"0","letter":"-","from":1997,"isMax":false,"to":1997,"save":{"hours":0,"mins":0}}]},
        zones: {"Pacific/Noumea":[{"name":"Pacific/Noumea","_offset":"11:05:48","_rule":"-","format":"LMT","_until":"1912 Jan 13","offset":{"negative":false,"hours":11,"mins":5,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-01-13T11:05:47.999Z"}},{"name":"Pacific/Noumea","_offset":"11:00","_rule":"NC","format":"NC%sT","_until":"","offset":{"negative":false,"hours":11,"mins":0,"secs":0},"range":{"begin":"1912-01-13T11:05:48.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);