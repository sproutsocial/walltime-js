/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Menominee].js
    
    var tzData = {
        rules: {},
        zones: {"America/Menominee":[{"name":"America/Menominee","_offset":"-5:50:27","_rule":"-","format":"LMT","_until":"1885 Sep 18 12:00"},{"name":"America/Menominee","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1946"},{"name":"America/Menominee","_offset":"-6:00","_rule":"Menominee","format":"C%sT","_until":"1969 Apr 27 2:00"},{"name":"America/Menominee","_offset":"-5:00","_rule":"-","format":"EST","_until":"1973 Apr 29 2:00"},{"name":"America/Menominee","_offset":"-6:00","_rule":"US","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);