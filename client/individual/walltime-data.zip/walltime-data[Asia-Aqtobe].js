/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Aqtobe].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Aqtobe":[{"name":"Asia/Aqtobe","_offset":"3:48:40","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Aqtobe","_offset":"4:00","_rule":"-","format":"AKTT","_until":"1930 Jun 21"},{"name":"Asia/Aqtobe","_offset":"5:00","_rule":"-","format":"AKTT","_until":"1981 Apr 1"},{"name":"Asia/Aqtobe","_offset":"5:00","_rule":"1:00","format":"AKTST","_until":"1981 Oct 1"},{"name":"Asia/Aqtobe","_offset":"6:00","_rule":"-","format":"AKTT","_until":"1982 Apr 1"},{"name":"Asia/Aqtobe","_offset":"5:00","_rule":"RussiaAsia","format":"AKT%sT","_until":"1991"},{"name":"Asia/Aqtobe","_offset":"5:00","_rule":"-","format":"AKTT","_until":"1991 Dec 16"},{"name":"Asia/Aqtobe","_offset":"5:00","_rule":"RussiaAsia","format":"AQT%sT","_until":"2005 Mar 15"},{"name":"Asia/Aqtobe","_offset":"5:00","_rule":"-","format":"AQTT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);