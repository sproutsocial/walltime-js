(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Reunion":[{"name":"Indian/Reunion","_offset":"3:41:52","_rule":"-","format":"LMT","_until":"1911 Jun","offset":{"negative":false,"hours":3,"mins":41,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-05-31T03:41:51.999Z"}},{"name":"Indian/Reunion","_offset":"4:00","_rule":"-","format":"RET","_until":"","offset":{"negative":false,"hours":4,"mins":0,"secs":0},"range":{"begin":"1911-05-31T03:41:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);