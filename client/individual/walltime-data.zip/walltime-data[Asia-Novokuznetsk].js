/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Novokuznetsk].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Novokuznetsk":[{"name":"Asia/Novokuznetsk","_offset":"5:48:48","_rule":"-","format":"NMT","_until":"1920 Jan 6"},{"name":"Asia/Novokuznetsk","_offset":"6:00","_rule":"-","format":"KRAT","_until":"1930 Jun 21"},{"name":"Asia/Novokuznetsk","_offset":"7:00","_rule":"Russia","format":"KRA%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Novokuznetsk","_offset":"6:00","_rule":"Russia","format":"KRA%sT","_until":"1992 Jan 19 2:00s"},{"name":"Asia/Novokuznetsk","_offset":"7:00","_rule":"Russia","format":"KRA%sT","_until":"2010 Mar 28 2:00s"},{"name":"Asia/Novokuznetsk","_offset":"6:00","_rule":"Russia","format":"NOV%sT","_until":"2011 Mar 27 2:00s"},{"name":"Asia/Novokuznetsk","_offset":"7:00","_rule":"-","format":"NOVT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);