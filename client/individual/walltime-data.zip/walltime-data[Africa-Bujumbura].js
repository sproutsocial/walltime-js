/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Bujumbura":[{"name":"Africa/Bujumbura","_offset":"1:57:28","_rule":"-","format":"LMT","_until":"1890"},{"name":"Africa/Bujumbura","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);