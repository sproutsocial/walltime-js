(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Bujumbura":[{"name":"Africa/Bujumbura","_offset":"1:57:28","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":false,"hours":1,"mins":57,"secs":28},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-31T01:57:27.999Z"}},{"name":"Africa/Bujumbura","_offset":"2:00","_rule":"-","format":"CAT","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1889-12-31T01:57:28.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);