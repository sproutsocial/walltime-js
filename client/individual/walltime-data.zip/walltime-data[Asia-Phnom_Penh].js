(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Phnom_Penh":[{"name":"Asia/Phnom_Penh","_offset":"6:59:40","_rule":"-","format":"LMT","_until":"1906 Jun 9","offset":{"negative":false,"hours":6,"mins":59,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1906-06-09T06:59:39.999Z"}},{"name":"Asia/Phnom_Penh","_offset":"7:06:20","_rule":"-","format":"SMT","_until":"1911 Mar 11 0:01","offset":{"negative":false,"hours":7,"mins":6,"secs":20},"range":{"begin":"1906-06-09T06:59:40.000Z","end":"1911-03-11T07:07:19.999Z"}},{"name":"Asia/Phnom_Penh","_offset":"7:00","_rule":"-","format":"ICT","_until":"1912 May","offset":{"negative":false,"hours":7,"mins":0,"secs":0},"range":{"begin":"1911-03-11T07:07:20.000Z","end":"1912-04-30T06:59:59.999Z"}},{"name":"Asia/Phnom_Penh","_offset":"8:00","_rule":"-","format":"ICT","_until":"1931 May","offset":{"negative":false,"hours":8,"mins":0,"secs":0},"range":{"begin":"1912-04-30T07:00:00.000Z","end":"1931-04-30T07:59:59.999Z"}},{"name":"Asia/Phnom_Penh","_offset":"7:00","_rule":"-","format":"ICT","_until":"","offset":{"negative":false,"hours":7,"mins":0,"secs":0},"range":{"begin":"1931-04-30T08:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);