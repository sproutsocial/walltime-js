/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Istanbul].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Istanbul":[{"name":"Europe/Istanbul","_offset":"1:55:52","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Istanbul","_offset":"1:56:56","_rule":"-","format":"IMT","_until":"1910 Oct"},{"name":"Europe/Istanbul","_offset":"2:00","_rule":"Turkey","format":"EE%sT","_until":"1978 Oct 15"},{"name":"Europe/Istanbul","_offset":"3:00","_rule":"Turkey","format":"TR%sT","_until":"1985 Apr 20"},{"name":"Europe/Istanbul","_offset":"2:00","_rule":"Turkey","format":"EE%sT","_until":"2007"},{"name":"Europe/Istanbul","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":"2011 Mar 27 1:00u"},{"name":"Europe/Istanbul","_offset":"2:00","_rule":"-","format":"EET","_until":"2011 Mar 28 1:00u"},{"name":"Europe/Istanbul","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);