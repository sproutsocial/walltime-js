/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+4":[{"name":"Etc/GMT+4","_offset":"-4","_rule":"-","format":"GMT+4","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);