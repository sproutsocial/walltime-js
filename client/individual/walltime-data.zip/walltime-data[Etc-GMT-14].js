(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-14":[{"name":"Etc/GMT-14","_offset":"14","_rule":"-","format":"GMT-14","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);