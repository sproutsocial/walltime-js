/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {"CO":[{"name":"CO","_from":"1992","_to":"only","type":"-","in":"May","on":"3","at":"0:00","_save":"1:00","letter":"S"},{"name":"CO","_from":"1993","_to":"only","type":"-","in":"Apr","on":"4","at":"0:00","_save":"0","letter":"-"}]},
        zones: {"America/Bogota":[{"name":"America/Bogota","_offset":"-4:56:20","_rule":"-","format":"LMT","_until":"1884 Mar 13"},{"name":"America/Bogota","_offset":"-4:56:20","_rule":"-","format":"BMT","_until":"1914 Nov 23"},{"name":"America/Bogota","_offset":"-5:00","_rule":"CO","format":"CO%sT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);