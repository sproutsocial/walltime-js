(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {"CO":[{"name":"CO","_from":"1992","_to":"only","type":"-","in":"May","on":"3","at":"0:00","_save":"1:00","letter":"S","from":1992,"isMax":false,"to":1992,"save":{"hours":1,"mins":0}},{"name":"CO","_from":"1993","_to":"only","type":"-","in":"Apr","on":"4","at":"0:00","_save":"0","letter":"-","from":1993,"isMax":false,"to":1993,"save":{"hours":0,"mins":0}}]},
        zones: {"America/Bogota":[{"name":"America/Bogota","_offset":"-4:56:20","_rule":"-","format":"LMT","_until":"1884 Mar 13","offset":{"negative":true,"hours":4,"mins":56,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1884-03-12T19:03:39.999Z"}},{"name":"America/Bogota","_offset":"-4:56:20","_rule":"-","format":"BMT","_until":"1914 Nov 23","offset":{"negative":true,"hours":4,"mins":56,"secs":20},"range":{"begin":"1884-03-12T19:03:40.000Z","end":"1914-11-22T19:03:39.999Z"}},{"name":"America/Bogota","_offset":"-5:00","_rule":"CO","format":"CO%sT","_until":"","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"1914-11-22T19:03:40.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);