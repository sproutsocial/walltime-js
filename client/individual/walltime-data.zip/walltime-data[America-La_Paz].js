(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/La_Paz":[{"name":"America/La_Paz","_offset":"-4:32:36","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":4,"mins":32,"secs":36},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T19:27:23.999Z"}},{"name":"America/La_Paz","_offset":"-4:32:36","_rule":"-","format":"CMT","_until":"1931 Oct 15","offset":{"negative":true,"hours":4,"mins":32,"secs":36},"range":{"begin":"1889-12-30T19:27:24.000Z","end":"1931-10-14T19:27:23.999Z"}},{"name":"America/La_Paz","_offset":"-4:32:36","_rule":"1:00","format":"BOST","_until":"1932 Mar 21","offset":{"negative":true,"hours":4,"mins":32,"secs":36},"range":{"begin":"1931-10-14T19:27:24.000Z","end":"1932-03-20T19:27:23.999Z"}},{"name":"America/La_Paz","_offset":"-4:00","_rule":"-","format":"BOT","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1932-03-20T19:27:24.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);