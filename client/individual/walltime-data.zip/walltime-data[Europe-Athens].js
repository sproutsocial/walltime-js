/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Athens].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Athens":[{"name":"Europe/Athens","_offset":"1:34:52","_rule":"-","format":"LMT","_until":"1895 Sep 14"},{"name":"Europe/Athens","_offset":"1:34:52","_rule":"-","format":"AMT","_until":"1916 Jul 28 0:01"},{"name":"Europe/Athens","_offset":"2:00","_rule":"Greece","format":"EE%sT","_until":"1941 Apr 30"},{"name":"Europe/Athens","_offset":"1:00","_rule":"Greece","format":"CE%sT","_until":"1944 Apr 4"},{"name":"Europe/Athens","_offset":"2:00","_rule":"Greece","format":"EE%sT","_until":"1981"},{"name":"Europe/Athens","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);