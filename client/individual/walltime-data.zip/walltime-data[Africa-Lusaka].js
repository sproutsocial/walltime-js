(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Lusaka":[{"name":"Africa/Lusaka","_offset":"1:53:08","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Lusaka","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);