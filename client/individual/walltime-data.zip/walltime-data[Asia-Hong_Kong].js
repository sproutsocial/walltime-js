/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Hong_Kong].js
    
    var tzData = {
        rules: {"HK":[{"name":"HK","_from":"1941","_to":"only","type":"-","in":"Apr","on":"1","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1941","_to":"only","type":"-","in":"Sep","on":"30","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1946","_to":"only","type":"-","in":"Apr","on":"20","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1946","_to":"only","type":"-","in":"Dec","on":"1","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1947","_to":"only","type":"-","in":"Apr","on":"13","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1947","_to":"only","type":"-","in":"Dec","on":"30","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1948","_to":"only","type":"-","in":"May","on":"2","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1948","_to":"1951","type":"-","in":"Oct","on":"lastSun","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1952","_to":"only","type":"-","in":"Oct","on":"25","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1949","_to":"1953","type":"-","in":"Apr","on":"Sun>=1","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1953","_to":"only","type":"-","in":"Nov","on":"1","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1954","_to":"1964","type":"-","in":"Mar","on":"Sun>=18","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1954","_to":"only","type":"-","in":"Oct","on":"31","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1955","_to":"1964","type":"-","in":"Nov","on":"Sun>=1","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1965","_to":"1976","type":"-","in":"Apr","on":"Sun>=16","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1965","_to":"1976","type":"-","in":"Oct","on":"Sun>=16","at":"3:30","_save":"0","letter":"-"},{"name":"HK","_from":"1973","_to":"only","type":"-","in":"Dec","on":"30","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1979","_to":"only","type":"-","in":"May","on":"Sun>=8","at":"3:30","_save":"1:00","letter":"S"},{"name":"HK","_from":"1979","_to":"only","type":"-","in":"Oct","on":"Sun>=16","at":"3:30","_save":"0","letter":"-"}]},
        zones: {"Asia/Hong_Kong":[{"name":"Asia/Hong_Kong","_offset":"7:36:42","_rule":"-","format":"LMT","_until":"1904 Oct 30"},{"name":"Asia/Hong_Kong","_offset":"8:00","_rule":"HK","format":"HK%sT","_until":"1941 Dec 25"},{"name":"Asia/Hong_Kong","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 15"},{"name":"Asia/Hong_Kong","_offset":"8:00","_rule":"HK","format":"HK%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);