/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Hong_Kong].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Hong_Kong":[{"name":"Asia/Hong_Kong","_offset":"7:36:36","_rule":"-","format":"LMT","_until":"1904 Oct 30"},{"name":"Asia/Hong_Kong","_offset":"8:00","_rule":"HK","format":"HK%sT","_until":"1941 Dec 25"},{"name":"Asia/Hong_Kong","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 15"},{"name":"Asia/Hong_Kong","_offset":"8:00","_rule":"HK","format":"HK%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);