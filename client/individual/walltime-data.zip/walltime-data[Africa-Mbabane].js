/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Mbabane":[{"name":"Africa/Mbabane","_offset":"2:04:24","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Mbabane","_offset":"2:00","_rule":"-","format":"SAST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);