(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Mbabane":[{"name":"Africa/Mbabane","_offset":"2:04:24","_rule":"-","format":"LMT","_until":"1903 Mar","offset":{"negative":false,"hours":2,"mins":4,"secs":24},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1903-02-28T02:04:23.999Z"}},{"name":"Africa/Mbabane","_offset":"2:00","_rule":"-","format":"SAST","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1903-02-28T02:04:24.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);