/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Nairobi":[{"name":"Africa/Nairobi","_offset":"2:27:16","_rule":"-","format":"LMT","_until":"1928 Jul"},{"name":"Africa/Nairobi","_offset":"3:00","_rule":"-","format":"EAT","_until":"1930"},{"name":"Africa/Nairobi","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1940"},{"name":"Africa/Nairobi","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1960"},{"name":"Africa/Nairobi","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);