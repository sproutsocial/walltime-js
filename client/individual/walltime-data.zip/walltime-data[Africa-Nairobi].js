(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Nairobi":[{"name":"Africa/Nairobi","_offset":"2:27:16","_rule":"-","format":"LMT","_until":"1928 Jul","offset":{"negative":false,"hours":2,"mins":27,"secs":16},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1928-06-30T02:27:15.999Z"}},{"name":"Africa/Nairobi","_offset":"3:00","_rule":"-","format":"EAT","_until":"1930","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1928-06-30T02:27:16.000Z","end":"1929-12-31T02:59:59.999Z"}},{"name":"Africa/Nairobi","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1940","offset":{"negative":false,"hours":2,"mins":30,"secs":0},"range":{"begin":"1929-12-31T03:00:00.000Z","end":"1939-12-31T02:29:59.999Z"}},{"name":"Africa/Nairobi","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1960","offset":{"negative":false,"hours":2,"mins":45,"secs":0},"range":{"begin":"1939-12-31T02:30:00.000Z","end":"1959-12-31T02:44:59.999Z"}},{"name":"Africa/Nairobi","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1959-12-31T02:45:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);