/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Kashgar].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Kashgar":[{"name":"Asia/Kashgar","_offset":"5:03:56","_rule":"-","format":"LMT","_until":"1928"},{"name":"Asia/Kashgar","_offset":"5:30","_rule":"-","format":"KAST","_until":"1940"},{"name":"Asia/Kashgar","_offset":"5:00","_rule":"-","format":"KAST","_until":"1980 May"},{"name":"Asia/Kashgar","_offset":"8:00","_rule":"PRC","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);