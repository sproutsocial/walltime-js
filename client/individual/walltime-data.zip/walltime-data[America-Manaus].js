/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Manaus].js
    
    var tzData = {
        rules: {},
        zones: {"America/Manaus":[{"name":"America/Manaus","_offset":"-4:00:04","_rule":"-","format":"LMT","_until":"1914"},{"name":"America/Manaus","_offset":"-4:00","_rule":"Brazil","format":"AM%sT","_until":"1988 Sep 12"},{"name":"America/Manaus","_offset":"-4:00","_rule":"-","format":"AMT","_until":"1993 Sep 28"},{"name":"America/Manaus","_offset":"-4:00","_rule":"Brazil","format":"AM%sT","_until":"1994 Sep 22"},{"name":"America/Manaus","_offset":"-4:00","_rule":"-","format":"AMT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);