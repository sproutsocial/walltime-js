(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Ouagadougou":[{"name":"Africa/Ouagadougou","_offset":"-0:06:04","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Ouagadougou","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);