(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Ouagadougou":[{"name":"Africa/Ouagadougou","_offset":"-0:06:04","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":true,"hours":0,"mins":6,"secs":4},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-30T23:53:55.999Z"}},{"name":"Africa/Ouagadougou","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1911-12-30T23:53:56.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);