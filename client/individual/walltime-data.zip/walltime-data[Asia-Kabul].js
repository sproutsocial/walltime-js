(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Kabul":[{"name":"Asia/Kabul","_offset":"4:36:48","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":false,"hours":4,"mins":36,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-31T04:36:47.999Z"}},{"name":"Asia/Kabul","_offset":"4:00","_rule":"-","format":"AFT","_until":"1945","offset":{"negative":false,"hours":4,"mins":0,"secs":0},"range":{"begin":"1889-12-31T04:36:48.000Z","end":"1944-12-31T03:59:59.999Z"}},{"name":"Asia/Kabul","_offset":"4:30","_rule":"-","format":"AFT","_until":"","offset":{"negative":false,"hours":4,"mins":30,"secs":0},"range":{"begin":"1944-12-31T04:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);