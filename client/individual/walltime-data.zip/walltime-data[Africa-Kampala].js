(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Kampala":[{"name":"Africa/Kampala","_offset":"2:09:40","_rule":"-","format":"LMT","_until":"1928 Jul","offset":{"negative":false,"hours":2,"mins":9,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1928-06-30T02:09:39.999Z"}},{"name":"Africa/Kampala","_offset":"3:00","_rule":"-","format":"EAT","_until":"1930","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1928-06-30T02:09:40.000Z","end":"1929-12-31T02:59:59.999Z"}},{"name":"Africa/Kampala","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1948","offset":{"negative":false,"hours":2,"mins":30,"secs":0},"range":{"begin":"1929-12-31T03:00:00.000Z","end":"1947-12-31T02:29:59.999Z"}},{"name":"Africa/Kampala","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1957","offset":{"negative":false,"hours":2,"mins":45,"secs":0},"range":{"begin":"1947-12-31T02:30:00.000Z","end":"1956-12-31T02:44:59.999Z"}},{"name":"Africa/Kampala","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1956-12-31T02:45:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);