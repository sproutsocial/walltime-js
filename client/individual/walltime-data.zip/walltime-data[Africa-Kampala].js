/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Kampala].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Kampala":[{"name":"Africa/Kampala","_offset":"2:09:40","_rule":"-","format":"LMT","_until":"1928 Jul"},{"name":"Africa/Kampala","_offset":"3:00","_rule":"-","format":"EAT","_until":"1930"},{"name":"Africa/Kampala","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1948"},{"name":"Africa/Kampala","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1957"},{"name":"Africa/Kampala","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);