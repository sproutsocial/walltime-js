/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Kampala":[{"name":"Africa/Kampala","_offset":"2:09:40","_rule":"-","format":"LMT","_until":"1928 Jul"},{"name":"Africa/Kampala","_offset":"3:00","_rule":"-","format":"EAT","_until":"1930"},{"name":"Africa/Kampala","_offset":"2:30","_rule":"-","format":"BEAT","_until":"1948"},{"name":"Africa/Kampala","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1957"},{"name":"Africa/Kampala","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);