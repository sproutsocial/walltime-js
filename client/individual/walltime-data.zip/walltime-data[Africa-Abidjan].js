/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Abidjan":[{"name":"Africa/Abidjan","_offset":"-0:16:08","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Abidjan","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);