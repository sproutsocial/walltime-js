(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kosrae":[{"name":"Pacific/Kosrae","_offset":"10:51:56","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":10,"mins":51,"secs":56},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T10:51:55.999Z"}},{"name":"Pacific/Kosrae","_offset":"11:00","_rule":"-","format":"KOST","_until":"1969 Oct","offset":{"negative":false,"hours":11,"mins":0,"secs":0},"range":{"begin":"1900-12-31T10:51:56.000Z","end":"1969-09-30T10:59:59.999Z"}},{"name":"Pacific/Kosrae","_offset":"12:00","_rule":"-","format":"KOST","_until":"1999","offset":{"negative":false,"hours":12,"mins":0,"secs":0},"range":{"begin":"1969-09-30T11:00:00.000Z","end":"1998-12-31T11:59:59.999Z"}},{"name":"Pacific/Kosrae","_offset":"11:00","_rule":"-","format":"KOST","_until":"","offset":{"negative":false,"hours":11,"mins":0,"secs":0},"range":{"begin":"1998-12-31T12:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);