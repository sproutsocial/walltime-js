/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Santiago].js
    
    var tzData = {
        rules: {},
        zones: {"America/Santiago":[{"name":"America/Santiago","_offset":"-4:42:46","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Santiago","_offset":"-4:42:46","_rule":"-","format":"SMT","_until":"1910"},{"name":"America/Santiago","_offset":"-5:00","_rule":"-","format":"CLT","_until":"1916 Jul 1"},{"name":"America/Santiago","_offset":"-4:42:46","_rule":"-","format":"SMT","_until":"1918 Sep 1"},{"name":"America/Santiago","_offset":"-4:00","_rule":"-","format":"CLT","_until":"1919 Jul 1"},{"name":"America/Santiago","_offset":"-4:42:46","_rule":"-","format":"SMT","_until":"1927 Sep 1"},{"name":"America/Santiago","_offset":"-5:00","_rule":"Chile","format":"CL%sT","_until":"1947 May 22"},{"name":"America/Santiago","_offset":"-4:00","_rule":"Chile","format":"CL%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);