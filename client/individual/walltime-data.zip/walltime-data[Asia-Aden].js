(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Aden":[{"name":"Asia/Aden","_offset":"3:00:48","_rule":"-","format":"LMT","_until":"1950","offset":{"negative":false,"hours":3,"mins":0,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1949-12-31T03:00:47.999Z"}},{"name":"Asia/Aden","_offset":"3:00","_rule":"-","format":"AST","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1949-12-31T03:00:48.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);