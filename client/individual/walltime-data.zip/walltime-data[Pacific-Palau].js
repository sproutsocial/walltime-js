/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Palau":[{"name":"Pacific/Palau","_offset":"8:57:56","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Palau","_offset":"9:00","_rule":"-","format":"PWT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);