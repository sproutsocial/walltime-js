(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Kigali":[{"name":"Africa/Kigali","_offset":"2:00:16","_rule":"-","format":"LMT","_until":"1935 Jun","offset":{"negative":false,"hours":2,"mins":0,"secs":16},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1935-05-31T02:00:15.999Z"}},{"name":"Africa/Kigali","_offset":"2:00","_rule":"-","format":"CAT","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1935-05-31T02:00:16.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);