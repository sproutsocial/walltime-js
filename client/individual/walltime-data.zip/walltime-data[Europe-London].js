/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-London].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/London":[{"name":"Europe/London","_offset":"-0:01:15","_rule":"-","format":"LMT","_until":"1847 Dec 1 0:00s"},{"name":"Europe/London","_offset":"0:00","_rule":"GB-Eire","format":"%s","_until":"1968 Oct 27"},{"name":"Europe/London","_offset":"1:00","_rule":"-","format":"BST","_until":"1971 Oct 31 2:00u"},{"name":"Europe/London","_offset":"0:00","_rule":"GB-Eire","format":"%s","_until":"1996"},{"name":"Europe/London","_offset":"0:00","_rule":"EU","format":"GMT/BST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);