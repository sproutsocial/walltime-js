(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/UTC":[{"name":"Etc/UTC","_offset":"0","_rule":"-","format":"UTC","_until":"","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);