/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Boise].js
    
    var tzData = {
        rules: {},
        zones: {"America/Boise":[{"name":"America/Boise","_offset":"-7:44:49","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:15:11"},{"name":"America/Boise","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1923 May 13 2:00"},{"name":"America/Boise","_offset":"-7:00","_rule":"US","format":"M%sT","_until":"1974"},{"name":"America/Boise","_offset":"-7:00","_rule":"-","format":"MST","_until":"1974 Feb 3 2:00"},{"name":"America/Boise","_offset":"-7:00","_rule":"US","format":"M%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);