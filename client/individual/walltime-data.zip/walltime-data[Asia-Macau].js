/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Macau].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Macau":[{"name":"Asia/Macau","_offset":"7:34:20","_rule":"-","format":"LMT","_until":"1912"},{"name":"Asia/Macau","_offset":"8:00","_rule":"Macau","format":"MO%sT","_until":"1999 Dec 20"},{"name":"Asia/Macau","_offset":"8:00","_rule":"PRC","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);