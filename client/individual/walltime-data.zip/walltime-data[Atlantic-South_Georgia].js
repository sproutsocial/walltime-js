(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Atlantic/South_Georgia":[{"name":"Atlantic/South_Georgia","_offset":"-2:26:08","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":2,"mins":26,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T21:33:51.999Z"}},{"name":"Atlantic/South_Georgia","_offset":"-2:00","_rule":"-","format":"GST","_until":"","offset":{"negative":true,"hours":2,"mins":0,"secs":0},"range":{"begin":"1889-12-30T21:33:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);