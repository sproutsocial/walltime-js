/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Goose_Bay].js
    
    var tzData = {
        rules: {},
        zones: {"America/Goose_Bay":[{"name":"America/Goose_Bay","_offset":"-4:01:40","_rule":"-","format":"LMT","_until":"1884"},{"name":"America/Goose_Bay","_offset":"-3:30:52","_rule":"-","format":"NST","_until":"1918"},{"name":"America/Goose_Bay","_offset":"-3:30:52","_rule":"Canada","format":"N%sT","_until":"1919"},{"name":"America/Goose_Bay","_offset":"-3:30:52","_rule":"-","format":"NST","_until":"1935 Mar 30"},{"name":"America/Goose_Bay","_offset":"-3:30","_rule":"-","format":"NST","_until":"1936"},{"name":"America/Goose_Bay","_offset":"-3:30","_rule":"StJohns","format":"N%sT","_until":"1942 May 11"},{"name":"America/Goose_Bay","_offset":"-3:30","_rule":"Canada","format":"N%sT","_until":"1946"},{"name":"America/Goose_Bay","_offset":"-3:30","_rule":"StJohns","format":"N%sT","_until":"1966 Mar 15 2:00"},{"name":"America/Goose_Bay","_offset":"-4:00","_rule":"StJohns","format":"A%sT","_until":"2011 Nov"},{"name":"America/Goose_Bay","_offset":"-4:00","_rule":"Canada","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);