/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Kentucky-Monticello].js
    
    var tzData = {
        rules: {},
        zones: {"America/Kentucky/Monticello":[{"name":"America/Kentucky/Monticello","_offset":"-5:39:24","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:20:36"},{"name":"America/Kentucky/Monticello","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1946"},{"name":"America/Kentucky/Monticello","_offset":"-6:00","_rule":"-","format":"CST","_until":"1968"},{"name":"America/Kentucky/Monticello","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"2000 Oct 29 2:00"},{"name":"America/Kentucky/Monticello","_offset":"-5:00","_rule":"US","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);