/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Kiev].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Kiev":[{"name":"Europe/Kiev","_offset":"2:02:04","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Kiev","_offset":"2:02:04","_rule":"-","format":"KMT","_until":"1924 May 2"},{"name":"Europe/Kiev","_offset":"2:00","_rule":"-","format":"EET","_until":"1930 Jun 21"},{"name":"Europe/Kiev","_offset":"3:00","_rule":"-","format":"MSK","_until":"1941 Sep 20"},{"name":"Europe/Kiev","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1943 Nov 6"},{"name":"Europe/Kiev","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1990"},{"name":"Europe/Kiev","_offset":"3:00","_rule":"-","format":"MSK","_until":"1990 Jul 1 2:00"},{"name":"Europe/Kiev","_offset":"2:00","_rule":"-","format":"EET","_until":"1992"},{"name":"Europe/Kiev","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1995"},{"name":"Europe/Kiev","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);