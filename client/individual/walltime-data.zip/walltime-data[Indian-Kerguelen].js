(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Kerguelen":[{"name":"Indian/Kerguelen","_offset":"0","_rule":"-","format":"zzz","_until":"1950","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1949-12-30T23:59:59.999Z"}},{"name":"Indian/Kerguelen","_offset":"5:00","_rule":"-","format":"TFT","_until":"","offset":{"negative":false,"hours":5,"mins":0,"secs":0},"range":{"begin":"1949-12-31T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);