/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Rankin_Inlet].js
    
    var tzData = {
        rules: {},
        zones: {"America/Rankin_Inlet":[{"name":"America/Rankin_Inlet","_offset":"0","_rule":"-","format":"zzz","_until":"1957"},{"name":"America/Rankin_Inlet","_offset":"-6:00","_rule":"NT_YK","format":"C%sT","_until":"2000 Oct 29 2:00"},{"name":"America/Rankin_Inlet","_offset":"-5:00","_rule":"-","format":"EST","_until":"2001 Apr 1 3:00"},{"name":"America/Rankin_Inlet","_offset":"-6:00","_rule":"Canada","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);