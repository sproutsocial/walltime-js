/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Tunis].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Tunis":[{"name":"Africa/Tunis","_offset":"0:40:44","_rule":"-","format":"LMT","_until":"1881 May 12"},{"name":"Africa/Tunis","_offset":"0:09:21","_rule":"-","format":"PMT","_until":"1911 Mar 11"},{"name":"Africa/Tunis","_offset":"1:00","_rule":"Tunisia","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);