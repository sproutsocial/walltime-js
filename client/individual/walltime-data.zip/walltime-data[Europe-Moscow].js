/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Moscow].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Moscow":[{"name":"Europe/Moscow","_offset":"2:30:20","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Moscow","_offset":"2:30","_rule":"-","format":"MMT","_until":"1916 Jul 3"},{"name":"Europe/Moscow","_offset":"2:30:48","_rule":"Russia","format":"%s","_until":"1919 Jul 1 2:00"},{"name":"Europe/Moscow","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1922 Oct"},{"name":"Europe/Moscow","_offset":"2:00","_rule":"-","format":"EET","_until":"1930 Jun 21"},{"name":"Europe/Moscow","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1991 Mar 31 2:00s"},{"name":"Europe/Moscow","_offset":"2:00","_rule":"Russia","format":"EE%sT","_until":"1992 Jan 19 2:00s"},{"name":"Europe/Moscow","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"2011 Mar 27 2:00s"},{"name":"Europe/Moscow","_offset":"4:00","_rule":"-","format":"MSK","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);