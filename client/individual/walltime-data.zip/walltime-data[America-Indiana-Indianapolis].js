/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Indiana-Indianapolis].js
    
    var tzData = {
        rules: {},
        zones: {"America/Indiana/Indianapolis":[{"name":"America/Indiana/Indianapolis","_offset":"-5:44:38","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:15:22"},{"name":"America/Indiana/Indianapolis","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1920"},{"name":"America/Indiana/Indianapolis","_offset":"-6:00","_rule":"Indianapolis","format":"C%sT","_until":"1942"},{"name":"America/Indiana/Indianapolis","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1946"},{"name":"America/Indiana/Indianapolis","_offset":"-6:00","_rule":"Indianapolis","format":"C%sT","_until":"1955 Apr 24 2:00"},{"name":"America/Indiana/Indianapolis","_offset":"-5:00","_rule":"-","format":"EST","_until":"1957 Sep 29 2:00"},{"name":"America/Indiana/Indianapolis","_offset":"-6:00","_rule":"-","format":"CST","_until":"1958 Apr 27 2:00"},{"name":"America/Indiana/Indianapolis","_offset":"-5:00","_rule":"-","format":"EST","_until":"1969"},{"name":"America/Indiana/Indianapolis","_offset":"-5:00","_rule":"US","format":"E%sT","_until":"1971"},{"name":"America/Indiana/Indianapolis","_offset":"-5:00","_rule":"-","format":"EST","_until":"2006"},{"name":"America/Indiana/Indianapolis","_offset":"-5:00","_rule":"US","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);