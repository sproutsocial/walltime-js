(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"MST":[{"name":"MST","_offset":"-7:00","_rule":"-","format":"MST","_until":"","offset":{"negative":true,"hours":7,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);