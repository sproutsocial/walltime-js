(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"MST":[{"name":"MST","_offset":"-7:00","_rule":"-","format":"MST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);