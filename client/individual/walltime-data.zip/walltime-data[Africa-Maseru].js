/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Maseru":[{"name":"Africa/Maseru","_offset":"1:50:00","_rule":"-","format":"LMT","_until":"1903 Mar"},{"name":"Africa/Maseru","_offset":"2:00","_rule":"-","format":"SAST","_until":"1943 Sep 19 2:00"},{"name":"Africa/Maseru","_offset":"2:00","_rule":"1:00","format":"SAST","_until":"1944 Mar 19 2:00"},{"name":"Africa/Maseru","_offset":"2:00","_rule":"-","format":"SAST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);