(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Maseru":[{"name":"Africa/Maseru","_offset":"1:50:00","_rule":"-","format":"LMT","_until":"1903 Mar","offset":{"negative":false,"hours":1,"mins":50,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1903-02-28T01:49:59.999Z"}},{"name":"Africa/Maseru","_offset":"2:00","_rule":"-","format":"SAST","_until":"1943 Sep 19 2:00","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1903-02-28T01:50:00.000Z","end":"1943-09-19T03:59:59.999Z"}},{"name":"Africa/Maseru","_offset":"2:00","_rule":"1:00","format":"SAST","_until":"1944 Mar 19 2:00","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1943-09-19T04:00:00.000Z","end":"1944-03-19T03:59:59.999Z"}},{"name":"Africa/Maseru","_offset":"2:00","_rule":"-","format":"SAST","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1944-03-19T04:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);