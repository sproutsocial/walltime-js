/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Oral].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Oral":[{"name":"Asia/Oral","_offset":"3:25:24","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Oral","_offset":"4:00","_rule":"-","format":"URAT","_until":"1930 Jun 21"},{"name":"Asia/Oral","_offset":"5:00","_rule":"-","format":"URAT","_until":"1981 Apr 1"},{"name":"Asia/Oral","_offset":"5:00","_rule":"1:00","format":"URAST","_until":"1981 Oct 1"},{"name":"Asia/Oral","_offset":"6:00","_rule":"-","format":"URAT","_until":"1982 Apr 1"},{"name":"Asia/Oral","_offset":"5:00","_rule":"RussiaAsia","format":"URA%sT","_until":"1989 Mar 26 2:00"},{"name":"Asia/Oral","_offset":"4:00","_rule":"RussiaAsia","format":"URA%sT","_until":"1991"},{"name":"Asia/Oral","_offset":"4:00","_rule":"-","format":"URAT","_until":"1991 Dec 16"},{"name":"Asia/Oral","_offset":"4:00","_rule":"RussiaAsia","format":"ORA%sT","_until":"2005 Mar 15"},{"name":"Asia/Oral","_offset":"5:00","_rule":"-","format":"ORAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);