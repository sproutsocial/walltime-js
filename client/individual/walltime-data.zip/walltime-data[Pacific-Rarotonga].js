/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Rarotonga].js
    
    var tzData = {
        rules: {"Cook":[{"name":"Cook","_from":"1978","_to":"only","type":"-","in":"Nov","on":"12","at":"0:00","_save":"0:30","letter":"HS"},{"name":"Cook","_from":"1979","_to":"1991","type":"-","in":"Mar","on":"Sun>=1","at":"0:00","_save":"0","letter":"-"},{"name":"Cook","_from":"1979","_to":"1990","type":"-","in":"Oct","on":"lastSun","at":"0:00","_save":"0:30","letter":"HS"}]},
        zones: {"Pacific/Rarotonga":[{"name":"Pacific/Rarotonga","_offset":"-10:39:04","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Rarotonga","_offset":"-10:30","_rule":"-","format":"CKT","_until":"1978 Nov 12"},{"name":"Pacific/Rarotonga","_offset":"-10:00","_rule":"Cook","format":"CK%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);