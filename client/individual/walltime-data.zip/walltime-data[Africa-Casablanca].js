/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Casablanca].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Casablanca":[{"name":"Africa/Casablanca","_offset":"-0:30:20","_rule":"-","format":"LMT","_until":"1913 Oct 26"},{"name":"Africa/Casablanca","_offset":"0:00","_rule":"Morocco","format":"WE%sT","_until":"1984 Mar 16"},{"name":"Africa/Casablanca","_offset":"1:00","_rule":"-","format":"CET","_until":"1986"},{"name":"Africa/Casablanca","_offset":"0:00","_rule":"Morocco","format":"WE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);