/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Kwajalein":[{"name":"Pacific/Kwajalein","_offset":"11:09:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Kwajalein","_offset":"11:00","_rule":"-","format":"MHT","_until":"1969 Oct"},{"name":"Pacific/Kwajalein","_offset":"-12:00","_rule":"-","format":"KWAT","_until":"1993 Aug 20"},{"name":"Pacific/Kwajalein","_offset":"12:00","_rule":"-","format":"MHT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);