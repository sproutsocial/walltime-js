/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Lisbon].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Lisbon":[{"name":"Europe/Lisbon","_offset":"-0:36:32","_rule":"-","format":"LMT","_until":"1884"},{"name":"Europe/Lisbon","_offset":"-0:36:32","_rule":"-","format":"LMT","_until":"1912 Jan 1"},{"name":"Europe/Lisbon","_offset":"0:00","_rule":"Port","format":"WE%sT","_until":"1966 Apr 3 2:00"},{"name":"Europe/Lisbon","_offset":"1:00","_rule":"-","format":"CET","_until":"1976 Sep 26 1:00"},{"name":"Europe/Lisbon","_offset":"0:00","_rule":"Port","format":"WE%sT","_until":"1983 Sep 25 1:00s"},{"name":"Europe/Lisbon","_offset":"0:00","_rule":"W-Eur","format":"WE%sT","_until":"1992 Sep 27 1:00s"},{"name":"Europe/Lisbon","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":"1996 Mar 31 1:00u"},{"name":"Europe/Lisbon","_offset":"0:00","_rule":"EU","format":"WE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);