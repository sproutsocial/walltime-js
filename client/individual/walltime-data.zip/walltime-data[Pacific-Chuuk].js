(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Chuuk":[{"name":"Pacific/Chuuk","_offset":"10:07:08","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":10,"mins":7,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T10:07:07.999Z"}},{"name":"Pacific/Chuuk","_offset":"10:00","_rule":"-","format":"CHUT","_until":"","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"1900-12-31T10:07:08.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);