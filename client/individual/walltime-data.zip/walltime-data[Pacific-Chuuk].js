(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Chuuk":[{"name":"Pacific/Chuuk","_offset":"10:07:08","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Chuuk","_offset":"10:00","_rule":"-","format":"CHUT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);