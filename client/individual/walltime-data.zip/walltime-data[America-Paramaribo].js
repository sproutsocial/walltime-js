/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Paramaribo].js
    
    var tzData = {
        rules: {},
        zones: {"America/Paramaribo":[{"name":"America/Paramaribo","_offset":"-3:40:40","_rule":"-","format":"LMT","_until":"1911"},{"name":"America/Paramaribo","_offset":"-3:40:52","_rule":"-","format":"PMT","_until":"1935"},{"name":"America/Paramaribo","_offset":"-3:40:36","_rule":"-","format":"PMT","_until":"1945 Oct"},{"name":"America/Paramaribo","_offset":"-3:30","_rule":"-","format":"NEGT","_until":"1975 Nov 20"},{"name":"America/Paramaribo","_offset":"-3:30","_rule":"-","format":"SRT","_until":"1984 Oct"},{"name":"America/Paramaribo","_offset":"-3:00","_rule":"-","format":"SRT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);