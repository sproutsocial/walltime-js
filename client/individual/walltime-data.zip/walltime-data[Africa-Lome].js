(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Lome":[{"name":"Africa/Lome","_offset":"0:04:52","_rule":"-","format":"LMT","_until":"1893","offset":{"negative":false,"hours":0,"mins":4,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1892-12-31T00:04:51.999Z"}},{"name":"Africa/Lome","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1892-12-31T00:04:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);