/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Winnipeg].js
    
    var tzData = {
        rules: {},
        zones: {"America/Winnipeg":[{"name":"America/Winnipeg","_offset":"-6:28:36","_rule":"-","format":"LMT","_until":"1887 Jul 16"},{"name":"America/Winnipeg","_offset":"-6:00","_rule":"Winn","format":"C%sT","_until":"2006"},{"name":"America/Winnipeg","_offset":"-6:00","_rule":"Canada","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);