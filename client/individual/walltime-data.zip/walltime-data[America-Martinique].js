(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Martinique":[{"name":"America/Martinique","_offset":"-4:04:20","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":4,"mins":4,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T19:55:39.999Z"}},{"name":"America/Martinique","_offset":"-4:04:20","_rule":"-","format":"FFMT","_until":"1911 May","offset":{"negative":true,"hours":4,"mins":4,"secs":20},"range":{"begin":"1889-12-30T19:55:40.000Z","end":"1911-04-29T19:55:39.999Z"}},{"name":"America/Martinique","_offset":"-4:00","_rule":"-","format":"AST","_until":"1980 Apr 6","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1911-04-29T19:55:40.000Z","end":"1980-04-05T19:59:59.999Z"}},{"name":"America/Martinique","_offset":"-4:00","_rule":"1:00","format":"ADT","_until":"1980 Sep 28","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1980-04-05T20:00:00.000Z","end":"1980-09-27T19:59:59.999Z"}},{"name":"America/Martinique","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1980-09-27T20:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);