/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Martinique].js
    
    var tzData = {
        rules: {},
        zones: {"America/Martinique":[{"name":"America/Martinique","_offset":"-4:04:20","_rule":"-","format":"LMT","_until":"1890"},{"name":"America/Martinique","_offset":"-4:04:20","_rule":"-","format":"FFMT","_until":"1911 May"},{"name":"America/Martinique","_offset":"-4:00","_rule":"-","format":"AST","_until":"1980 Apr 6"},{"name":"America/Martinique","_offset":"-4:00","_rule":"1:00","format":"ADT","_until":"1980 Sep 28"},{"name":"America/Martinique","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);