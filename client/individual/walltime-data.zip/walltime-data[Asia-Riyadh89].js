/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Riyadh89].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Riyadh89":[{"name":"Asia/Riyadh89","_offset":"3:07:04","_rule":"-","format":"zzz","_until":"1989"},{"name":"Asia/Riyadh89","_offset":"3:07:04","_rule":"sol89","format":"zzz","_until":"1990"},{"name":"Asia/Riyadh89","_offset":"3:07:04","_rule":"-","format":"zzz","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);