/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Sao_Paulo].js
    
    var tzData = {
        rules: {},
        zones: {"America/Sao_Paulo":[{"name":"America/Sao_Paulo","_offset":"-3:06:28","_rule":"-","format":"LMT","_until":"1914"},{"name":"America/Sao_Paulo","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"1963 Oct 23 00:00"},{"name":"America/Sao_Paulo","_offset":"-3:00","_rule":"1:00","format":"BRST","_until":"1964"},{"name":"America/Sao_Paulo","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);