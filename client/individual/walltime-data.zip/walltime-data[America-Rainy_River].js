/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Rainy_River].js
    
    var tzData = {
        rules: {},
        zones: {"America/Rainy_River":[{"name":"America/Rainy_River","_offset":"-6:18:16","_rule":"-","format":"LMT","_until":"1895"},{"name":"America/Rainy_River","_offset":"-6:00","_rule":"Canada","format":"C%sT","_until":"1940 Sep 29"},{"name":"America/Rainy_River","_offset":"-6:00","_rule":"1:00","format":"CDT","_until":"1942 Feb 9 2:00s"},{"name":"America/Rainy_River","_offset":"-6:00","_rule":"Canada","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);