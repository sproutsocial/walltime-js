(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Cocos":[{"name":"Indian/Cocos","_offset":"6:27:40","_rule":"-","format":"LMT","_until":"1900"},{"name":"Indian/Cocos","_offset":"6:30","_rule":"-","format":"CCT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);