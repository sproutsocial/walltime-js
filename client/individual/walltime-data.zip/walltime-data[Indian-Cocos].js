/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Indian/Cocos":[{"name":"Indian/Cocos","_offset":"6:27:40","_rule":"-","format":"LMT","_until":"1900"},{"name":"Indian/Cocos","_offset":"6:30","_rule":"-","format":"CCT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);