(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Cocos":[{"name":"Indian/Cocos","_offset":"6:27:40","_rule":"-","format":"LMT","_until":"1900","offset":{"negative":false,"hours":6,"mins":27,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1899-12-31T06:27:39.999Z"}},{"name":"Indian/Cocos","_offset":"6:30","_rule":"-","format":"CCT","_until":"","offset":{"negative":false,"hours":6,"mins":30,"secs":0},"range":{"begin":"1899-12-31T06:27:40.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);