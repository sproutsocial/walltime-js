/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Indian-Cocos].js
    
    var tzData = {
        rules: {},
        zones: {"Indian/Cocos":[{"name":"Indian/Cocos","_offset":"6:27:40","_rule":"-","format":"LMT","_until":"1900"},{"name":"Indian/Cocos","_offset":"6:30","_rule":"-","format":"CCT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);