/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Thunder_Bay].js
    
    var tzData = {
        rules: {},
        zones: {"America/Thunder_Bay":[{"name":"America/Thunder_Bay","_offset":"-5:57:00","_rule":"-","format":"LMT","_until":"1895"},{"name":"America/Thunder_Bay","_offset":"-6:00","_rule":"-","format":"CST","_until":"1910"},{"name":"America/Thunder_Bay","_offset":"-5:00","_rule":"-","format":"EST","_until":"1942"},{"name":"America/Thunder_Bay","_offset":"-5:00","_rule":"Canada","format":"E%sT","_until":"1970"},{"name":"America/Thunder_Bay","_offset":"-5:00","_rule":"Mont","format":"E%sT","_until":"1973"},{"name":"America/Thunder_Bay","_offset":"-5:00","_rule":"-","format":"EST","_until":"1974"},{"name":"America/Thunder_Bay","_offset":"-5:00","_rule":"Canada","format":"E%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);