(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Kuwait":[{"name":"Asia/Kuwait","_offset":"3:11:56","_rule":"-","format":"LMT","_until":"1950","offset":{"negative":false,"hours":3,"mins":11,"secs":56},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1949-12-31T03:11:55.999Z"}},{"name":"Asia/Kuwait","_offset":"3:00","_rule":"-","format":"AST","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1949-12-31T03:11:56.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);