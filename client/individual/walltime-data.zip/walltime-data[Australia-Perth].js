/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Perth].js
    
    var tzData = {
        rules: {},
        zones: {"Australia/Perth":[{"name":"Australia/Perth","_offset":"7:43:24","_rule":"-","format":"LMT","_until":"1895 Dec"},{"name":"Australia/Perth","_offset":"8:00","_rule":"Aus","format":"WST","_until":"1943 Jul"},{"name":"Australia/Perth","_offset":"8:00","_rule":"AW","format":"WST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);