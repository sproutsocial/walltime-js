(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Dubai":[{"name":"Asia/Dubai","_offset":"3:41:12","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Dubai","_offset":"4:00","_rule":"-","format":"GST","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);