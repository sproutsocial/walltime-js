(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Bangui":[{"name":"Africa/Bangui","_offset":"1:14:20","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":false,"hours":1,"mins":14,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-31T01:14:19.999Z"}},{"name":"Africa/Bangui","_offset":"1:00","_rule":"-","format":"WAT","_until":"","offset":{"negative":false,"hours":1,"mins":0,"secs":0},"range":{"begin":"1911-12-31T01:14:20.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);