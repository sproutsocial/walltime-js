/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Bangui":[{"name":"Africa/Bangui","_offset":"1:14:20","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Bangui","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);