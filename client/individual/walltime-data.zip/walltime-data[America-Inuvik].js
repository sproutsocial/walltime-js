/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Inuvik].js
    
    var tzData = {
        rules: {},
        zones: {"America/Inuvik":[{"name":"America/Inuvik","_offset":"0","_rule":"-","format":"zzz","_until":"1953"},{"name":"America/Inuvik","_offset":"-8:00","_rule":"NT_YK","format":"P%sT","_until":"1979 Apr lastSun 2:00"},{"name":"America/Inuvik","_offset":"-7:00","_rule":"NT_YK","format":"M%sT","_until":"1980"},{"name":"America/Inuvik","_offset":"-7:00","_rule":"Canada","format":"M%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);