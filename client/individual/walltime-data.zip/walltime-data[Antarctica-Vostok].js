/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Vostok].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/Vostok":[{"name":"Antarctica/Vostok","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Dec 16"},{"name":"Antarctica/Vostok","_offset":"6:00","_rule":"-","format":"VOST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);