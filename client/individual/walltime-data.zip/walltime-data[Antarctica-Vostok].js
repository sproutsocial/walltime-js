(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Vostok":[{"name":"Antarctica/Vostok","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Dec 16","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1957-12-15T23:59:59.999Z"}},{"name":"Antarctica/Vostok","_offset":"6:00","_rule":"-","format":"VOST","_until":"","offset":{"negative":false,"hours":6,"mins":0,"secs":0},"range":{"begin":"1957-12-16T00:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);