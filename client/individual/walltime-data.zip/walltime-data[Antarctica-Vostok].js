/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Vostok":[{"name":"Antarctica/Vostok","_offset":"0","_rule":"-","format":"zzz","_until":"1957 Dec 16"},{"name":"Antarctica/Vostok","_offset":"6:00","_rule":"-","format":"VOST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);