(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Pohnpei":[{"name":"Pacific/Pohnpei","_offset":"10:32:52","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":10,"mins":32,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T10:32:51.999Z"}},{"name":"Pacific/Pohnpei","_offset":"11:00","_rule":"-","format":"PONT","_until":"","offset":{"negative":false,"hours":11,"mins":0,"secs":0},"range":{"begin":"1900-12-31T10:32:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);