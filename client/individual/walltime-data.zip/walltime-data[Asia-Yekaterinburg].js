/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Yekaterinburg].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Yekaterinburg":[{"name":"Asia/Yekaterinburg","_offset":"4:02:24","_rule":"-","format":"LMT","_until":"1919 Jul 15 4:00"},{"name":"Asia/Yekaterinburg","_offset":"4:00","_rule":"-","format":"SVET","_until":"1930 Jun 21"},{"name":"Asia/Yekaterinburg","_offset":"5:00","_rule":"Russia","format":"SVE%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Yekaterinburg","_offset":"4:00","_rule":"Russia","format":"SVE%sT","_until":"1992 Jan 19 2:00s"},{"name":"Asia/Yekaterinburg","_offset":"5:00","_rule":"Russia","format":"YEK%sT","_until":"2011 Mar 27 2:00s"},{"name":"Asia/Yekaterinburg","_offset":"6:00","_rule":"-","format":"YEKT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);