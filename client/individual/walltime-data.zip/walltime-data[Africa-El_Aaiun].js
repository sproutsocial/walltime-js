(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/El_Aaiun":[{"name":"Africa/El_Aaiun","_offset":"-0:52:48","_rule":"-","format":"LMT","_until":"1934 Jan","offset":{"negative":true,"hours":0,"mins":52,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1933-12-30T23:07:11.999Z"}},{"name":"Africa/El_Aaiun","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1976 Apr 14","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1933-12-30T23:07:12.000Z","end":"1976-04-13T22:59:59.999Z"}},{"name":"Africa/El_Aaiun","_offset":"0:00","_rule":"-","format":"WET","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1976-04-13T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);