/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-El_Salvador].js
    
    var tzData = {
        rules: {},
        zones: {"America/El_Salvador":[{"name":"America/El_Salvador","_offset":"-5:56:48","_rule":"-","format":"LMT","_until":"1921"},{"name":"America/El_Salvador","_offset":"-6:00","_rule":"Salv","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);