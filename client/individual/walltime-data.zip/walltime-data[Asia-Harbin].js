/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Harbin].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Harbin":[{"name":"Asia/Harbin","_offset":"8:26:44","_rule":"-","format":"LMT","_until":"1928"},{"name":"Asia/Harbin","_offset":"8:30","_rule":"-","format":"CHAT","_until":"1932 Mar"},{"name":"Asia/Harbin","_offset":"8:00","_rule":"-","format":"CST","_until":"1940"},{"name":"Asia/Harbin","_offset":"9:00","_rule":"-","format":"CHAT","_until":"1966 May"},{"name":"Asia/Harbin","_offset":"8:30","_rule":"-","format":"CHAT","_until":"1980 May"},{"name":"Asia/Harbin","_offset":"8:00","_rule":"PRC","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);