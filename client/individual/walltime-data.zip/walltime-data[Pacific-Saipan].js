/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Saipan].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Saipan":[{"name":"Pacific/Saipan","_offset":"-14:17:00","_rule":"-","format":"LMT","_until":"1844 Dec 31"},{"name":"Pacific/Saipan","_offset":"9:43:00","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Saipan","_offset":"9:00","_rule":"-","format":"MPT","_until":"1969 Oct"},{"name":"Pacific/Saipan","_offset":"10:00","_rule":"-","format":"MPT","_until":"2000 Dec 23"},{"name":"Pacific/Saipan","_offset":"10:00","_rule":"-","format":"ChST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);