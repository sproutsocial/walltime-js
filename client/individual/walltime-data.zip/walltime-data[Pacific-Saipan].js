/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Saipan":[{"name":"Pacific/Saipan","_offset":"-14:17:00","_rule":"-","format":"LMT","_until":"1844 Dec 31"},{"name":"Pacific/Saipan","_offset":"9:43:00","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Saipan","_offset":"9:00","_rule":"-","format":"MPT","_until":"1969 Oct"},{"name":"Pacific/Saipan","_offset":"10:00","_rule":"-","format":"MPT","_until":"2000 Dec 23"},{"name":"Pacific/Saipan","_offset":"10:00","_rule":"-","format":"ChST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);