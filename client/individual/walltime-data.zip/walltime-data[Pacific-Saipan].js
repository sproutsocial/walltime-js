(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Saipan":[{"name":"Pacific/Saipan","_offset":"-14:17:00","_rule":"-","format":"LMT","_until":"1844 Dec 31","offset":{"negative":true,"hours":14,"mins":17,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1844-12-30T09:42:59.999Z"}},{"name":"Pacific/Saipan","_offset":"9:43:00","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":9,"mins":43,"secs":0},"range":{"begin":"1844-12-30T09:43:00.000Z","end":"1900-12-31T09:42:59.999Z"}},{"name":"Pacific/Saipan","_offset":"9:00","_rule":"-","format":"MPT","_until":"1969 Oct","offset":{"negative":false,"hours":9,"mins":0,"secs":0},"range":{"begin":"1900-12-31T09:43:00.000Z","end":"1969-09-30T08:59:59.999Z"}},{"name":"Pacific/Saipan","_offset":"10:00","_rule":"-","format":"MPT","_until":"2000 Dec 23","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"1969-09-30T09:00:00.000Z","end":"2000-12-23T09:59:59.999Z"}},{"name":"Pacific/Saipan","_offset":"10:00","_rule":"-","format":"ChST","_until":"","offset":{"negative":false,"hours":10,"mins":0,"secs":0},"range":{"begin":"2000-12-23T10:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);