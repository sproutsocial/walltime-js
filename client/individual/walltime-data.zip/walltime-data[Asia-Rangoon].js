/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Rangoon":[{"name":"Asia/Rangoon","_offset":"6:24:40","_rule":"-","format":"LMT","_until":"1880"},{"name":"Asia/Rangoon","_offset":"6:24:36","_rule":"-","format":"RMT","_until":"1920"},{"name":"Asia/Rangoon","_offset":"6:30","_rule":"-","format":"BURT","_until":"1942 May"},{"name":"Asia/Rangoon","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 May 3"},{"name":"Asia/Rangoon","_offset":"6:30","_rule":"-","format":"MMT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);