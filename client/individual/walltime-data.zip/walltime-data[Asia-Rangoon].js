(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Rangoon":[{"name":"Asia/Rangoon","_offset":"6:24:40","_rule":"-","format":"LMT","_until":"1880","offset":{"negative":false,"hours":6,"mins":24,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1879-12-31T06:24:39.999Z"}},{"name":"Asia/Rangoon","_offset":"6:24:36","_rule":"-","format":"RMT","_until":"1920","offset":{"negative":false,"hours":6,"mins":24,"secs":36},"range":{"begin":"1879-12-31T06:24:40.000Z","end":"1919-12-31T06:24:35.999Z"}},{"name":"Asia/Rangoon","_offset":"6:30","_rule":"-","format":"BURT","_until":"1942 May","offset":{"negative":false,"hours":6,"mins":30,"secs":0},"range":{"begin":"1919-12-31T06:24:36.000Z","end":"1942-04-30T06:29:59.999Z"}},{"name":"Asia/Rangoon","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 May 3","offset":{"negative":false,"hours":9,"mins":0,"secs":0},"range":{"begin":"1942-04-30T06:30:00.000Z","end":"1945-05-03T08:59:59.999Z"}},{"name":"Asia/Rangoon","_offset":"6:30","_rule":"-","format":"MMT","_until":"","offset":{"negative":false,"hours":6,"mins":30,"secs":0},"range":{"begin":"1945-05-03T09:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);