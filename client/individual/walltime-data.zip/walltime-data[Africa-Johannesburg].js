(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {"SA":[{"name":"SA","_from":"1942","_to":"1943","type":"-","in":"Sep","on":"Sun>=15","at":"2:00","_save":"1:00","letter":"-","from":1942,"isMax":false,"to":1943,"save":{"hours":1,"mins":0}},{"name":"SA","_from":"1943","_to":"1944","type":"-","in":"Mar","on":"Sun>=15","at":"2:00","_save":"0","letter":"-","from":1943,"isMax":false,"to":1944,"save":{"hours":0,"mins":0}}]},
        zones: {"Africa/Johannesburg":[{"name":"Africa/Johannesburg","_offset":"1:52:00","_rule":"-","format":"LMT","_until":"1892 Feb 8","offset":{"negative":false,"hours":1,"mins":52,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1892-02-08T01:51:59.999Z"}},{"name":"Africa/Johannesburg","_offset":"1:30","_rule":"-","format":"SAST","_until":"1903 Mar","offset":{"negative":false,"hours":1,"mins":30,"secs":0},"range":{"begin":"1892-02-08T01:52:00.000Z","end":"1903-02-28T01:29:59.999Z"}},{"name":"Africa/Johannesburg","_offset":"2:00","_rule":"SA","format":"SAST","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1903-02-28T01:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);