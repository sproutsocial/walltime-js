/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Choibalsan].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Choibalsan":[{"name":"Asia/Choibalsan","_offset":"7:38:00","_rule":"-","format":"LMT","_until":"1905 Aug"},{"name":"Asia/Choibalsan","_offset":"7:00","_rule":"-","format":"ULAT","_until":"1978"},{"name":"Asia/Choibalsan","_offset":"8:00","_rule":"-","format":"ULAT","_until":"1983 Apr"},{"name":"Asia/Choibalsan","_offset":"9:00","_rule":"Mongol","format":"CHO%sT","_until":"2008 Mar 31"},{"name":"Asia/Choibalsan","_offset":"8:00","_rule":"Mongol","format":"CHO%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);