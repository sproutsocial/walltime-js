/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Adelaide].js
    
    var tzData = {
        rules: {"Aus":[{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Jan","on":"1","at":"0:01","_save":"1:00","letter":"-"},{"name":"Aus","_from":"1917","_to":"only","type":"-","in":"Mar","on":"25","at":"2:00","_save":"0","letter":"-"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Jan","on":"1","at":"2:00","_save":"1:00","letter":"-"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Mar","on":"29","at":"2:00","_save":"0","letter":"-"},{"name":"Aus","_from":"1942","_to":"only","type":"-","in":"Sep","on":"27","at":"2:00","_save":"1:00","letter":"-"},{"name":"Aus","_from":"1943","_to":"1944","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"0","letter":"-"},{"name":"Aus","_from":"1943","_to":"only","type":"-","in":"Oct","on":"3","at":"2:00","_save":"1:00","letter":"-"}],"AS":[{"name":"AS","_from":"1971","_to":"1985","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AS","_from":"1986","_to":"only","type":"-","in":"Oct","on":"19","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AS","_from":"1987","_to":"2007","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"-"},{"name":"AS","_from":"1972","_to":"only","type":"-","in":"Feb","on":"27","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1973","_to":"1985","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1986","_to":"1990","type":"-","in":"Mar","on":"Sun>=15","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1991","_to":"only","type":"-","in":"Mar","on":"3","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1992","_to":"only","type":"-","in":"Mar","on":"22","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1993","_to":"only","type":"-","in":"Mar","on":"7","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1994","_to":"only","type":"-","in":"Mar","on":"20","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"1995","_to":"2005","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"2006","_to":"only","type":"-","in":"Apr","on":"2","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"2007","_to":"only","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"2008","_to":"max","type":"-","in":"Apr","on":"Sun>=1","at":"2:00s","_save":"0","letter":"-"},{"name":"AS","_from":"2008","_to":"max","type":"-","in":"Oct","on":"Sun>=1","at":"2:00s","_save":"1:00","letter":"-"}]},
        zones: {"Australia/Adelaide":[{"name":"Australia/Adelaide","_offset":"9:14:20","_rule":"-","format":"LMT","_until":"1895 Feb"},{"name":"Australia/Adelaide","_offset":"9:00","_rule":"-","format":"CST","_until":"1899 May"},{"name":"Australia/Adelaide","_offset":"9:30","_rule":"Aus","format":"CST","_until":"1971"},{"name":"Australia/Adelaide","_offset":"9:30","_rule":"AS","format":"CST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);