/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Indiana-Tell_City].js
    
    var tzData = {
        rules: {},
        zones: {"America/Indiana/Tell_City":[{"name":"America/Indiana/Tell_City","_offset":"-5:47:03","_rule":"-","format":"LMT","_until":"1883 Nov 18 12:12:57"},{"name":"America/Indiana/Tell_City","_offset":"-6:00","_rule":"US","format":"C%sT","_until":"1946"},{"name":"America/Indiana/Tell_City","_offset":"-6:00","_rule":"Perry","format":"C%sT","_until":"1964 Apr 26 2:00"},{"name":"America/Indiana/Tell_City","_offset":"-5:00","_rule":"-","format":"EST","_until":"1969"},{"name":"America/Indiana/Tell_City","_offset":"-5:00","_rule":"US","format":"E%sT","_until":"1971"},{"name":"America/Indiana/Tell_City","_offset":"-5:00","_rule":"-","format":"EST","_until":"2006 Apr 2 2:00"},{"name":"America/Indiana/Tell_City","_offset":"-6:00","_rule":"US","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);