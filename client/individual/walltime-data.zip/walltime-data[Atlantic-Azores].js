/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Atlantic-Azores].js
    
    var tzData = {
        rules: {},
        zones: {"Atlantic/Azores":[{"name":"Atlantic/Azores","_offset":"-1:42:40","_rule":"-","format":"LMT","_until":"1884"},{"name":"Atlantic/Azores","_offset":"-1:54:32","_rule":"-","format":"HMT","_until":"1911 May 24"},{"name":"Atlantic/Azores","_offset":"-2:00","_rule":"Port","format":"AZO%sT","_until":"1966 Apr 3 2:00"},{"name":"Atlantic/Azores","_offset":"-1:00","_rule":"Port","format":"AZO%sT","_until":"1983 Sep 25 1:00s"},{"name":"Atlantic/Azores","_offset":"-1:00","_rule":"W-Eur","format":"AZO%sT","_until":"1992 Sep 27 1:00s"},{"name":"Atlantic/Azores","_offset":"0:00","_rule":"EU","format":"WE%sT","_until":"1993 Mar 28 1:00u"},{"name":"Atlantic/Azores","_offset":"-1:00","_rule":"EU","format":"AZO%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);