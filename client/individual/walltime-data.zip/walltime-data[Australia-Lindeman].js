/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Lindeman].js
    
    var tzData = {
        rules: {},
        zones: {"Australia/Lindeman":[{"name":"Australia/Lindeman","_offset":"9:55:56","_rule":"-","format":"LMT","_until":"1895"},{"name":"Australia/Lindeman","_offset":"10:00","_rule":"Aus","format":"EST","_until":"1971"},{"name":"Australia/Lindeman","_offset":"10:00","_rule":"AQ","format":"EST","_until":"1992 Jul"},{"name":"Australia/Lindeman","_offset":"10:00","_rule":"Holiday","format":"EST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);