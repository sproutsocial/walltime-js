(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+11":[{"name":"Etc/GMT+11","_offset":"-11","_rule":"-","format":"GMT+11","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);