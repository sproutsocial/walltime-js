/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT+11":[{"name":"Etc/GMT+11","_offset":"-11","_rule":"-","format":"GMT+11","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);