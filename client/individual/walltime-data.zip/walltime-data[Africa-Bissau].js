(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Bissau":[{"name":"Africa/Bissau","_offset":"-1:02:20","_rule":"-","format":"LMT","_until":"1911 May 26"},{"name":"Africa/Bissau","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1975"},{"name":"Africa/Bissau","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);