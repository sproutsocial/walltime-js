(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Bissau":[{"name":"Africa/Bissau","_offset":"-1:02:20","_rule":"-","format":"LMT","_until":"1911 May 26","offset":{"negative":true,"hours":1,"mins":2,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-05-25T22:57:39.999Z"}},{"name":"Africa/Bissau","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1975","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1911-05-25T22:57:40.000Z","end":"1974-12-30T22:59:59.999Z"}},{"name":"Africa/Bissau","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1974-12-30T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);