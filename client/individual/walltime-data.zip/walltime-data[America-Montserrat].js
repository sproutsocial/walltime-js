(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Montserrat":[{"name":"America/Montserrat","_offset":"-4:08:52","_rule":"-","format":"LMT","_until":"1911 Jul 1 0:01","offset":{"negative":true,"hours":4,"mins":8,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-06-30T19:52:07.999Z"}},{"name":"America/Montserrat","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1911-06-30T19:52:08.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);