/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"America/Montserrat":[{"name":"America/Montserrat","_offset":"-4:08:52","_rule":"-","format":"LMT","_until":"1911 Jul 1 0:01"},{"name":"America/Montserrat","_offset":"-4:00","_rule":"-","format":"AST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);