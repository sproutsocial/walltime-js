/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Riga].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Riga":[{"name":"Europe/Riga","_offset":"1:36:24","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Riga","_offset":"1:36:24","_rule":"-","format":"RMT","_until":"1918 Apr 15 2:00"},{"name":"Europe/Riga","_offset":"1:36:24","_rule":"1:00","format":"LST","_until":"1918 Sep 16 3:00"},{"name":"Europe/Riga","_offset":"1:36:24","_rule":"-","format":"RMT","_until":"1919 Apr 1 2:00"},{"name":"Europe/Riga","_offset":"1:36:24","_rule":"1:00","format":"LST","_until":"1919 May 22 3:00"},{"name":"Europe/Riga","_offset":"1:36:24","_rule":"-","format":"RMT","_until":"1926 May 11"},{"name":"Europe/Riga","_offset":"2:00","_rule":"-","format":"EET","_until":"1940 Aug 5"},{"name":"Europe/Riga","_offset":"3:00","_rule":"-","format":"MSK","_until":"1941 Jul"},{"name":"Europe/Riga","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Oct 13"},{"name":"Europe/Riga","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1989 Mar lastSun 2:00s"},{"name":"Europe/Riga","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"1989 Sep lastSun 2:00s"},{"name":"Europe/Riga","_offset":"2:00","_rule":"Latvia","format":"EE%sT","_until":"1997 Jan 21"},{"name":"Europe/Riga","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":"2000 Feb 29"},{"name":"Europe/Riga","_offset":"2:00","_rule":"-","format":"EET","_until":"2001 Jan 2"},{"name":"Europe/Riga","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);