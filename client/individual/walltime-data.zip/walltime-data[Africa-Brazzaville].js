/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Brazzaville].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Brazzaville":[{"name":"Africa/Brazzaville","_offset":"1:01:08","_rule":"-","format":"LMT","_until":"1912"},{"name":"Africa/Brazzaville","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);