(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Brazzaville":[{"name":"Africa/Brazzaville","_offset":"1:01:08","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":false,"hours":1,"mins":1,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-31T01:01:07.999Z"}},{"name":"Africa/Brazzaville","_offset":"1:00","_rule":"-","format":"WAT","_until":"","offset":{"negative":false,"hours":1,"mins":0,"secs":0},"range":{"begin":"1911-12-31T01:01:08.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);