(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Thimphu":[{"name":"Asia/Thimphu","_offset":"5:58:36","_rule":"-","format":"LMT","_until":"1947 Aug 15","offset":{"negative":false,"hours":5,"mins":58,"secs":36},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1947-08-15T05:58:35.999Z"}},{"name":"Asia/Thimphu","_offset":"5:30","_rule":"-","format":"IST","_until":"1987 Oct","offset":{"negative":false,"hours":5,"mins":30,"secs":0},"range":{"begin":"1947-08-15T05:58:36.000Z","end":"1987-09-30T05:29:59.999Z"}},{"name":"Asia/Thimphu","_offset":"6:00","_rule":"-","format":"BTT","_until":"","offset":{"negative":false,"hours":6,"mins":0,"secs":0},"range":{"begin":"1987-09-30T05:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);