/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Thimphu":[{"name":"Asia/Thimphu","_offset":"5:58:36","_rule":"-","format":"LMT","_until":"1947 Aug 15"},{"name":"Asia/Thimphu","_offset":"5:30","_rule":"-","format":"IST","_until":"1987 Oct"},{"name":"Asia/Thimphu","_offset":"6:00","_rule":"-","format":"BTT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);