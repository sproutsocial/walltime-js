/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Australia-Sydney].js
    
    var tzData = {
        rules: {},
        zones: {"Australia/Sydney":[{"name":"Australia/Sydney","_offset":"10:04:52","_rule":"-","format":"LMT","_until":"1895 Feb"},{"name":"Australia/Sydney","_offset":"10:00","_rule":"Aus","format":"EST","_until":"1971"},{"name":"Australia/Sydney","_offset":"10:00","_rule":"AN","format":"EST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);