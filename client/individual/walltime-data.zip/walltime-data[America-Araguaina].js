/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Araguaina].js
    
    var tzData = {
        rules: {},
        zones: {"America/Araguaina":[{"name":"America/Araguaina","_offset":"-3:12:48","_rule":"-","format":"LMT","_until":"1914"},{"name":"America/Araguaina","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"1990 Sep 17"},{"name":"America/Araguaina","_offset":"-3:00","_rule":"-","format":"BRT","_until":"1995 Sep 14"},{"name":"America/Araguaina","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":"2003 Sep 24"},{"name":"America/Araguaina","_offset":"-3:00","_rule":"-","format":"BRT","_until":"2012 Oct 21"},{"name":"America/Araguaina","_offset":"-3:00","_rule":"Brazil","format":"BR%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);