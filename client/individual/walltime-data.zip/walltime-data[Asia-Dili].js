/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Dili":[{"name":"Asia/Dili","_offset":"8:22:20","_rule":"-","format":"LMT","_until":"1912"},{"name":"Asia/Dili","_offset":"8:00","_rule":"-","format":"TLT","_until":"1942 Feb 21 23:00"},{"name":"Asia/Dili","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 23"},{"name":"Asia/Dili","_offset":"9:00","_rule":"-","format":"TLT","_until":"1976 May 3"},{"name":"Asia/Dili","_offset":"8:00","_rule":"-","format":"CIT","_until":"2000 Sep 17 00:00"},{"name":"Asia/Dili","_offset":"9:00","_rule":"-","format":"TLT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);