/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Dili].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Dili":[{"name":"Asia/Dili","_offset":"8:22:20","_rule":"-","format":"LMT","_until":"1912"},{"name":"Asia/Dili","_offset":"8:00","_rule":"-","format":"TLT","_until":"1942 Feb 21 23:00"},{"name":"Asia/Dili","_offset":"9:00","_rule":"-","format":"JST","_until":"1945 Sep 23"},{"name":"Asia/Dili","_offset":"9:00","_rule":"-","format":"TLT","_until":"1976 May 3"},{"name":"Asia/Dili","_offset":"8:00","_rule":"-","format":"CIT","_until":"2000 Sep 17 00:00"},{"name":"Asia/Dili","_offset":"9:00","_rule":"-","format":"TLT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);