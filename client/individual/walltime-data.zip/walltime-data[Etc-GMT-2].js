/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-2":[{"name":"Etc/GMT-2","_offset":"2","_rule":"-","format":"GMT-2","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);