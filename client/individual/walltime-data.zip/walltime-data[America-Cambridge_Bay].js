/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Cambridge_Bay].js
    
    var tzData = {
        rules: {},
        zones: {"America/Cambridge_Bay":[{"name":"America/Cambridge_Bay","_offset":"0","_rule":"-","format":"zzz","_until":"1920"},{"name":"America/Cambridge_Bay","_offset":"-7:00","_rule":"NT_YK","format":"M%sT","_until":"1999 Oct 31 2:00"},{"name":"America/Cambridge_Bay","_offset":"-6:00","_rule":"Canada","format":"C%sT","_until":"2000 Oct 29 2:00"},{"name":"America/Cambridge_Bay","_offset":"-5:00","_rule":"-","format":"EST","_until":"2000 Nov 5 0:00"},{"name":"America/Cambridge_Bay","_offset":"-6:00","_rule":"-","format":"CST","_until":"2001 Apr 1 3:00"},{"name":"America/Cambridge_Bay","_offset":"-7:00","_rule":"Canada","format":"M%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);