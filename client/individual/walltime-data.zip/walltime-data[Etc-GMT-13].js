(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Etc/GMT-13":[{"name":"Etc/GMT-13","_offset":"13","_rule":"-","format":"GMT-13","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);