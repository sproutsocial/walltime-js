/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Prague].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Prague":[{"name":"Europe/Prague","_offset":"0:57:44","_rule":"-","format":"LMT","_until":"1850"},{"name":"Europe/Prague","_offset":"0:57:44","_rule":"-","format":"PMT","_until":"1891 Oct"},{"name":"Europe/Prague","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Sep 17 2:00s"},{"name":"Europe/Prague","_offset":"1:00","_rule":"Czech","format":"CE%sT","_until":"1979"},{"name":"Europe/Prague","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);