/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Dublin].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Dublin":[{"name":"Europe/Dublin","_offset":"-0:25:00","_rule":"-","format":"LMT","_until":"1880 Aug 2"},{"name":"Europe/Dublin","_offset":"-0:25:21","_rule":"-","format":"DMT","_until":"1916 May 21 2:00"},{"name":"Europe/Dublin","_offset":"-0:25:21","_rule":"1:00","format":"IST","_until":"1916 Oct 1 2:00s"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"GB-Eire","format":"%s","_until":"1921 Dec 6"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"GB-Eire","format":"GMT/IST","_until":"1940 Feb 25 2:00"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"1:00","format":"IST","_until":"1946 Oct 6 2:00"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"-","format":"GMT","_until":"1947 Mar 16 2:00"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"1:00","format":"IST","_until":"1947 Nov 2 2:00"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"-","format":"GMT","_until":"1948 Apr 18 2:00"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"GB-Eire","format":"GMT/IST","_until":"1968 Oct 27"},{"name":"Europe/Dublin","_offset":"1:00","_rule":"-","format":"IST","_until":"1971 Oct 31 2:00u"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"GB-Eire","format":"GMT/IST","_until":"1996"},{"name":"Europe/Dublin","_offset":"0:00","_rule":"EU","format":"GMT/IST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);