(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Atlantic/St_Helena":[{"name":"Atlantic/St_Helena","_offset":"-0:22:48","_rule":"-","format":"LMT","_until":"1890"},{"name":"Atlantic/St_Helena","_offset":"-0:22:48","_rule":"-","format":"JMT","_until":"1951"},{"name":"Atlantic/St_Helena","_offset":"0:00","_rule":"-","format":"GMT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);