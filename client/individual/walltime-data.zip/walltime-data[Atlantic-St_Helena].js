(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Atlantic/St_Helena":[{"name":"Atlantic/St_Helena","_offset":"-0:22:48","_rule":"-","format":"LMT","_until":"1890","offset":{"negative":true,"hours":0,"mins":22,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1889-12-30T23:37:11.999Z"}},{"name":"Atlantic/St_Helena","_offset":"-0:22:48","_rule":"-","format":"JMT","_until":"1951","offset":{"negative":true,"hours":0,"mins":22,"secs":48},"range":{"begin":"1889-12-30T23:37:12.000Z","end":"1950-12-30T23:37:11.999Z"}},{"name":"Atlantic/St_Helena","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1950-12-30T23:37:12.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);