/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Tongatapu].js
    
    var tzData = {
        rules: {"Tonga":[{"name":"Tonga","_from":"1999","_to":"only","type":"-","in":"Oct","on":"7","at":"2:00s","_save":"1:00","letter":"S"},{"name":"Tonga","_from":"2000","_to":"only","type":"-","in":"Mar","on":"19","at":"2:00s","_save":"0","letter":"-"},{"name":"Tonga","_from":"2000","_to":"2001","type":"-","in":"Nov","on":"Sun>=1","at":"2:00","_save":"1:00","letter":"S"},{"name":"Tonga","_from":"2001","_to":"2002","type":"-","in":"Jan","on":"lastSun","at":"2:00","_save":"0","letter":"-"}]},
        zones: {"Pacific/Tongatapu":[{"name":"Pacific/Tongatapu","_offset":"12:19:20","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Tongatapu","_offset":"12:20","_rule":"-","format":"TOT","_until":"1941"},{"name":"Pacific/Tongatapu","_offset":"13:00","_rule":"-","format":"TOT","_until":"1999"},{"name":"Pacific/Tongatapu","_offset":"13:00","_rule":"Tonga","format":"TO%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);