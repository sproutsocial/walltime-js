(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"America/Antigua":[{"name":"America/Antigua","_offset":"-4:07:12","_rule":"-","format":"LMT","_until":"1912 Mar 2","offset":{"negative":true,"hours":4,"mins":7,"secs":12},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1912-03-01T19:52:47.999Z"}},{"name":"America/Antigua","_offset":"-5:00","_rule":"-","format":"EST","_until":"1951","offset":{"negative":true,"hours":5,"mins":0,"secs":0},"range":{"begin":"1912-03-01T19:52:48.000Z","end":"1950-12-30T18:59:59.999Z"}},{"name":"America/Antigua","_offset":"-4:00","_rule":"-","format":"AST","_until":"","offset":{"negative":true,"hours":4,"mins":0,"secs":0},"range":{"begin":"1950-12-30T19:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);