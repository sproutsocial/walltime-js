(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Lubumbashi":[{"name":"Africa/Lubumbashi","_offset":"1:49:52","_rule":"-","format":"LMT","_until":"1897 Nov 9","offset":{"negative":false,"hours":1,"mins":49,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1897-11-09T01:49:51.999Z"}},{"name":"Africa/Lubumbashi","_offset":"2:00","_rule":"-","format":"CAT","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1897-11-09T01:49:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);