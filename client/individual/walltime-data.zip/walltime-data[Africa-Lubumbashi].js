/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Lubumbashi].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Lubumbashi":[{"name":"Africa/Lubumbashi","_offset":"1:49:52","_rule":"-","format":"LMT","_until":"1897 Nov 9"},{"name":"Africa/Lubumbashi","_offset":"2:00","_rule":"-","format":"CAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);