/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Barbados].js
    
    var tzData = {
        rules: {},
        zones: {"America/Barbados":[{"name":"America/Barbados","_offset":"-3:58:28","_rule":"-","format":"LMT","_until":"1924"},{"name":"America/Barbados","_offset":"-3:58:28","_rule":"-","format":"BMT","_until":"1932"},{"name":"America/Barbados","_offset":"-4:00","_rule":"Barb","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);