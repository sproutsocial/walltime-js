(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Funafuti":[{"name":"Pacific/Funafuti","_offset":"11:56:52","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Funafuti","_offset":"12:00","_rule":"-","format":"TVT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);