(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Funafuti":[{"name":"Pacific/Funafuti","_offset":"11:56:52","_rule":"-","format":"LMT","_until":"1901","offset":{"negative":false,"hours":11,"mins":56,"secs":52},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1900-12-31T11:56:51.999Z"}},{"name":"Pacific/Funafuti","_offset":"12:00","_rule":"-","format":"TVT","_until":"","offset":{"negative":false,"hours":12,"mins":0,"secs":0},"range":{"begin":"1900-12-31T11:56:52.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);