/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Auckland].js
    
    var tzData = {
        rules: {"NZ":[{"name":"NZ","_from":"1927","_to":"only","type":"-","in":"Nov","on":"6","at":"2:00","_save":"1:00","letter":"S"},{"name":"NZ","_from":"1928","_to":"only","type":"-","in":"Mar","on":"4","at":"2:00","_save":"0","letter":"M"},{"name":"NZ","_from":"1928","_to":"1933","type":"-","in":"Oct","on":"Sun>=8","at":"2:00","_save":"0:30","letter":"S"},{"name":"NZ","_from":"1929","_to":"1933","type":"-","in":"Mar","on":"Sun>=15","at":"2:00","_save":"0","letter":"M"},{"name":"NZ","_from":"1934","_to":"1940","type":"-","in":"Apr","on":"lastSun","at":"2:00","_save":"0","letter":"M"},{"name":"NZ","_from":"1934","_to":"1940","type":"-","in":"Sep","on":"lastSun","at":"2:00","_save":"0:30","letter":"S"},{"name":"NZ","_from":"1946","_to":"only","type":"-","in":"Jan","on":"1","at":"0:00","_save":"0","letter":"S"},{"name":"NZ","_from":"1974","_to":"only","type":"-","in":"Nov","on":"Sun>=1","at":"2:00s","_save":"1:00","letter":"D"},{"name":"NZ","_from":"1975","_to":"only","type":"-","in":"Feb","on":"lastSun","at":"2:00s","_save":"0","letter":"S"},{"name":"NZ","_from":"1975","_to":"1988","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"NZ","_from":"1976","_to":"1989","type":"-","in":"Mar","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"},{"name":"NZ","_from":"1989","_to":"only","type":"-","in":"Oct","on":"Sun>=8","at":"2:00s","_save":"1:00","letter":"D"},{"name":"NZ","_from":"1990","_to":"2006","type":"-","in":"Oct","on":"Sun>=1","at":"2:00s","_save":"1:00","letter":"D"},{"name":"NZ","_from":"1990","_to":"2007","type":"-","in":"Mar","on":"Sun>=15","at":"2:00s","_save":"0","letter":"S"},{"name":"NZ","_from":"2007","_to":"max","type":"-","in":"Sep","on":"lastSun","at":"2:00s","_save":"1:00","letter":"D"},{"name":"NZ","_from":"2008","_to":"max","type":"-","in":"Apr","on":"Sun>=1","at":"2:00s","_save":"0","letter":"S"}]},
        zones: {"Pacific/Auckland":[{"name":"Pacific/Auckland","_offset":"11:39:04","_rule":"-","format":"LMT","_until":"1868 Nov 2"},{"name":"Pacific/Auckland","_offset":"11:30","_rule":"NZ","format":"NZ%sT","_until":"1946 Jan 1"},{"name":"Pacific/Auckland","_offset":"12:00","_rule":"NZ","format":"NZ%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);