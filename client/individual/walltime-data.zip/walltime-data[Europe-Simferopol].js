/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Simferopol].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Simferopol":[{"name":"Europe/Simferopol","_offset":"2:16:24","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Simferopol","_offset":"2:16","_rule":"-","format":"SMT","_until":"1924 May 2"},{"name":"Europe/Simferopol","_offset":"2:00","_rule":"-","format":"EET","_until":"1930 Jun 21"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"-","format":"MSK","_until":"1941 Nov"},{"name":"Europe/Simferopol","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Apr 13"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1990"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"-","format":"MSK","_until":"1990 Jul 1 2:00"},{"name":"Europe/Simferopol","_offset":"2:00","_rule":"-","format":"EET","_until":"1992"},{"name":"Europe/Simferopol","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1994 May"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"E-Eur","format":"MSK/MSD","_until":"1996 Mar 31 3:00s"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"1:00","format":"MSD","_until":"1996 Oct 27 3:00s"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1997"},{"name":"Europe/Simferopol","_offset":"3:00","_rule":"-","format":"MSK","_until":"1997 Mar lastSun 1:00u"},{"name":"Europe/Simferopol","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);