(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Pacific/Nauru":[{"name":"Pacific/Nauru","_offset":"11:07:40","_rule":"-","format":"LMT","_until":"1921 Jan 15","offset":{"negative":false,"hours":11,"mins":7,"secs":40},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1921-01-15T11:07:39.999Z"}},{"name":"Pacific/Nauru","_offset":"11:30","_rule":"-","format":"NRT","_until":"1942 Mar 15","offset":{"negative":false,"hours":11,"mins":30,"secs":0},"range":{"begin":"1921-01-15T11:07:40.000Z","end":"1942-03-15T11:29:59.999Z"}},{"name":"Pacific/Nauru","_offset":"9:00","_rule":"-","format":"JST","_until":"1944 Aug 15","offset":{"negative":false,"hours":9,"mins":0,"secs":0},"range":{"begin":"1942-03-15T11:30:00.000Z","end":"1944-08-15T08:59:59.999Z"}},{"name":"Pacific/Nauru","_offset":"11:30","_rule":"-","format":"NRT","_until":"1979 May","offset":{"negative":false,"hours":11,"mins":30,"secs":0},"range":{"begin":"1944-08-15T09:00:00.000Z","end":"1979-04-30T11:29:59.999Z"}},{"name":"Pacific/Nauru","_offset":"12:00","_rule":"-","format":"NRT","_until":"","offset":{"negative":false,"hours":12,"mins":0,"secs":0},"range":{"begin":"1979-04-30T11:30:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);