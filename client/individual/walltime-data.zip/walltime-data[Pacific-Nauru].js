/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Nauru":[{"name":"Pacific/Nauru","_offset":"11:07:40","_rule":"-","format":"LMT","_until":"1921 Jan 15"},{"name":"Pacific/Nauru","_offset":"11:30","_rule":"-","format":"NRT","_until":"1942 Mar 15"},{"name":"Pacific/Nauru","_offset":"9:00","_rule":"-","format":"JST","_until":"1944 Aug 15"},{"name":"Pacific/Nauru","_offset":"11:30","_rule":"-","format":"NRT","_until":"1979 May"},{"name":"Pacific/Nauru","_offset":"12:00","_rule":"-","format":"NRT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);