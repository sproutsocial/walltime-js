(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Nouakchott":[{"name":"Africa/Nouakchott","_offset":"-1:03:48","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":true,"hours":1,"mins":3,"secs":48},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-30T22:56:11.999Z"}},{"name":"Africa/Nouakchott","_offset":"0:00","_rule":"-","format":"GMT","_until":"1934 Feb 26","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1911-12-30T22:56:12.000Z","end":"1934-02-25T23:59:59.999Z"}},{"name":"Africa/Nouakchott","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1960 Nov 28","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1934-02-26T00:00:00.000Z","end":"1960-11-27T22:59:59.999Z"}},{"name":"Africa/Nouakchott","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1960-11-27T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);