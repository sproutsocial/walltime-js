(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Banjul":[{"name":"Africa/Banjul","_offset":"-1:06:36","_rule":"-","format":"LMT","_until":"1912","offset":{"negative":true,"hours":1,"mins":6,"secs":36},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-12-30T22:53:23.999Z"}},{"name":"Africa/Banjul","_offset":"-1:06:36","_rule":"-","format":"BMT","_until":"1935","offset":{"negative":true,"hours":1,"mins":6,"secs":36},"range":{"begin":"1911-12-30T22:53:24.000Z","end":"1934-12-30T22:53:23.999Z"}},{"name":"Africa/Banjul","_offset":"-1:00","_rule":"-","format":"WAT","_until":"1964","offset":{"negative":true,"hours":1,"mins":0,"secs":0},"range":{"begin":"1934-12-30T22:53:24.000Z","end":"1963-12-30T22:59:59.999Z"}},{"name":"Africa/Banjul","_offset":"0:00","_rule":"-","format":"GMT","_until":"","offset":{"negative":false,"hours":0,"mins":0,"secs":0},"range":{"begin":"1963-12-30T23:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);