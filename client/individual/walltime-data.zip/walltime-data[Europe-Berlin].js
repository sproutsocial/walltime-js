/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Berlin].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Berlin":[{"name":"Europe/Berlin","_offset":"0:53:28","_rule":"-","format":"LMT","_until":"1893 Apr"},{"name":"Europe/Berlin","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945 May 24 2:00"},{"name":"Europe/Berlin","_offset":"1:00","_rule":"SovietZone","format":"CE%sT","_until":"1946"},{"name":"Europe/Berlin","_offset":"1:00","_rule":"Germany","format":"CE%sT","_until":"1980"},{"name":"Europe/Berlin","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);