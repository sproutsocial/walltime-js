/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Bucharest].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Bucharest":[{"name":"Europe/Bucharest","_offset":"1:44:24","_rule":"-","format":"LMT","_until":"1891 Oct"},{"name":"Europe/Bucharest","_offset":"1:44:24","_rule":"-","format":"BMT","_until":"1931 Jul 24"},{"name":"Europe/Bucharest","_offset":"2:00","_rule":"Romania","format":"EE%sT","_until":"1981 Mar 29 2:00s"},{"name":"Europe/Bucharest","_offset":"2:00","_rule":"C-Eur","format":"EE%sT","_until":"1991"},{"name":"Europe/Bucharest","_offset":"2:00","_rule":"Romania","format":"EE%sT","_until":"1994"},{"name":"Europe/Bucharest","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1997"},{"name":"Europe/Bucharest","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);