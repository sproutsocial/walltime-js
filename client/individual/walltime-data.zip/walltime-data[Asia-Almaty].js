/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Almaty].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Almaty":[{"name":"Asia/Almaty","_offset":"5:07:48","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Almaty","_offset":"5:00","_rule":"-","format":"ALMT","_until":"1930 Jun 21"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"RussiaAsia","format":"ALM%sT","_until":"1991"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"-","format":"ALMT","_until":"1992"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"RussiaAsia","format":"ALM%sT","_until":"2005 Mar 15"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"-","format":"ALMT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);