/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {"RussiaAsia":[{"name":"RussiaAsia","_from":"1981","_to":"1984","type":"-","in":"Apr","on":"1","at":"0:00","_save":"1:00","letter":"S"},{"name":"RussiaAsia","_from":"1981","_to":"1983","type":"-","in":"Oct","on":"1","at":"0:00","_save":"0","letter":"-"},{"name":"RussiaAsia","_from":"1984","_to":"1991","type":"-","in":"Sep","on":"lastSun","at":"2:00s","_save":"0","letter":"-"},{"name":"RussiaAsia","_from":"1985","_to":"1991","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"1:00","letter":"S"},{"name":"RussiaAsia","_from":"1992","_to":"only","type":"-","in":"Mar","on":"lastSat","at":"23:00","_save":"1:00","letter":"S"},{"name":"RussiaAsia","_from":"1992","_to":"only","type":"-","in":"Sep","on":"lastSat","at":"23:00","_save":"0","letter":"-"},{"name":"RussiaAsia","_from":"1993","_to":"max","type":"-","in":"Mar","on":"lastSun","at":"2:00s","_save":"1:00","letter":"S"},{"name":"RussiaAsia","_from":"1993","_to":"1995","type":"-","in":"Sep","on":"lastSun","at":"2:00s","_save":"0","letter":"-"},{"name":"RussiaAsia","_from":"1996","_to":"max","type":"-","in":"Oct","on":"lastSun","at":"2:00s","_save":"0","letter":"-"}]},
        zones: {"Asia/Almaty":[{"name":"Asia/Almaty","_offset":"5:07:48","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Almaty","_offset":"5:00","_rule":"-","format":"ALMT","_until":"1930 Jun 21"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"RussiaAsia","format":"ALM%sT","_until":"1991"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"-","format":"ALMT","_until":"1992"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"RussiaAsia","format":"ALM%sT","_until":"2005 Mar 15"},{"name":"Asia/Almaty","_offset":"6:00","_rule":"-","format":"ALMT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);