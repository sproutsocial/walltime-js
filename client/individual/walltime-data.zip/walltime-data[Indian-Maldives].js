(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Indian/Maldives":[{"name":"Indian/Maldives","_offset":"4:54:00","_rule":"-","format":"LMT","_until":"1880","offset":{"negative":false,"hours":4,"mins":54,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1879-12-31T04:53:59.999Z"}},{"name":"Indian/Maldives","_offset":"4:54:00","_rule":"-","format":"MMT","_until":"1960","offset":{"negative":false,"hours":4,"mins":54,"secs":0},"range":{"begin":"1879-12-31T04:54:00.000Z","end":"1959-12-31T04:53:59.999Z"}},{"name":"Indian/Maldives","_offset":"5:00","_rule":"-","format":"MVT","_until":"","offset":{"negative":false,"hours":5,"mins":0,"secs":0},"range":{"begin":"1959-12-31T04:54:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);