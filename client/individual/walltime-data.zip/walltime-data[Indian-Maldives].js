/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Indian/Maldives":[{"name":"Indian/Maldives","_offset":"4:54:00","_rule":"-","format":"LMT","_until":"1880"},{"name":"Indian/Maldives","_offset":"4:54:00","_rule":"-","format":"MMT","_until":"1960"},{"name":"Indian/Maldives","_offset":"5:00","_rule":"-","format":"MVT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);