/*
 *  WallTime 0.2.0
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-St_Johns].js
    
    var tzData = {
        rules: {"StJohns":[{"name":"StJohns","_from":"1917","_to":"only","type":"-","in":"Apr","on":"8","at":"2:00","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1917","_to":"only","type":"-","in":"Sep","on":"17","at":"2:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1919","_to":"only","type":"-","in":"May","on":"5","at":"23:00","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1919","_to":"only","type":"-","in":"Aug","on":"12","at":"23:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1920","_to":"1935","type":"-","in":"May","on":"Sun>=1","at":"23:00","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1920","_to":"1935","type":"-","in":"Oct","on":"lastSun","at":"23:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1936","_to":"1941","type":"-","in":"May","on":"Mon>=9","at":"0:00","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1936","_to":"1941","type":"-","in":"Oct","on":"Mon>=2","at":"0:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1946","_to":"1950","type":"-","in":"May","on":"Sun>=8","at":"2:00","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1946","_to":"1950","type":"-","in":"Oct","on":"Sun>=2","at":"2:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1951","_to":"1986","type":"-","in":"Apr","on":"lastSun","at":"2:00","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1951","_to":"1959","type":"-","in":"Sep","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1960","_to":"1986","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"StJohns","_from":"1987","_to":"only","type":"-","in":"Apr","on":"Sun>=1","at":"0:01","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"1987","_to":"2006","type":"-","in":"Oct","on":"lastSun","at":"0:01","_save":"0","letter":"S"},{"name":"StJohns","_from":"1988","_to":"only","type":"-","in":"Apr","on":"Sun>=1","at":"0:01","_save":"2:00","letter":"DD"},{"name":"StJohns","_from":"1989","_to":"2006","type":"-","in":"Apr","on":"Sun>=1","at":"0:01","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"2007","_to":"2011","type":"-","in":"Mar","on":"Sun>=8","at":"0:01","_save":"1:00","letter":"D"},{"name":"StJohns","_from":"2007","_to":"2010","type":"-","in":"Nov","on":"Sun>=1","at":"0:01","_save":"0","letter":"S"}],"Canada":[{"name":"Canada","_from":"1918","_to":"only","type":"-","in":"Apr","on":"14","at":"2:00","_save":"1:00","letter":"D"},{"name":"Canada","_from":"1918","_to":"only","type":"-","in":"Oct","on":"27","at":"2:00","_save":"0","letter":"S"},{"name":"Canada","_from":"1942","_to":"only","type":"-","in":"Feb","on":"9","at":"2:00","_save":"1:00","letter":"W"},{"name":"Canada","_from":"1945","_to":"only","type":"-","in":"Aug","on":"14","at":"23:00u","_save":"1:00","letter":"P"},{"name":"Canada","_from":"1945","_to":"only","type":"-","in":"Sep","on":"30","at":"2:00","_save":"0","letter":"S"},{"name":"Canada","_from":"1974","_to":"1986","type":"-","in":"Apr","on":"lastSun","at":"2:00","_save":"1:00","letter":"D"},{"name":"Canada","_from":"1974","_to":"2006","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0","letter":"S"},{"name":"Canada","_from":"1987","_to":"2006","type":"-","in":"Apr","on":"Sun>=1","at":"2:00","_save":"1:00","letter":"D"},{"name":"Canada","_from":"2007","_to":"max","type":"-","in":"Mar","on":"Sun>=8","at":"2:00","_save":"1:00","letter":"D"},{"name":"Canada","_from":"2007","_to":"max","type":"-","in":"Nov","on":"Sun>=1","at":"2:00","_save":"0","letter":"S"}]},
        zones: {"America/St_Johns":[{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"-","format":"LMT","_until":"1884"},{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"StJohns","format":"N%sT","_until":"1918"},{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"Canada","format":"N%sT","_until":"1919"},{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"StJohns","format":"N%sT","_until":"1935 Mar 30"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"StJohns","format":"N%sT","_until":"1942 May 11"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"Canada","format":"N%sT","_until":"1946"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"StJohns","format":"N%sT","_until":"2011 Nov"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"Canada","format":"N%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);