/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-St_Johns].js
    
    var tzData = {
        rules: {},
        zones: {"America/St_Johns":[{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"-","format":"LMT","_until":"1884"},{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"StJohns","format":"N%sT","_until":"1918"},{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"Canada","format":"N%sT","_until":"1919"},{"name":"America/St_Johns","_offset":"-3:30:52","_rule":"StJohns","format":"N%sT","_until":"1935 Mar 30"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"StJohns","format":"N%sT","_until":"1942 May 11"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"Canada","format":"N%sT","_until":"1946"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"StJohns","format":"N%sT","_until":"2011 Nov"},{"name":"America/St_Johns","_offset":"-3:30","_rule":"Canada","format":"N%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);