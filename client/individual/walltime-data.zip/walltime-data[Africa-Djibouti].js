(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Djibouti":[{"name":"Africa/Djibouti","_offset":"2:52:36","_rule":"-","format":"LMT","_until":"1911 Jul","offset":{"negative":false,"hours":2,"mins":52,"secs":36},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1911-06-30T02:52:35.999Z"}},{"name":"Africa/Djibouti","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1911-06-30T02:52:36.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);