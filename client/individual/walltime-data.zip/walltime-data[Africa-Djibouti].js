/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Djibouti].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Djibouti":[{"name":"Africa/Djibouti","_offset":"2:52:36","_rule":"-","format":"LMT","_until":"1911 Jul"},{"name":"Africa/Djibouti","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);