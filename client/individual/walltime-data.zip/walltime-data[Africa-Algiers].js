/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Algiers].js
    
    var tzData = {
        rules: {"Algeria":[{"name":"Algeria","_from":"1916","_to":"only","type":"-","in":"Jun","on":"14","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1916","_to":"1919","type":"-","in":"Oct","on":"Sun>=1","at":"23:00s","_save":"0","letter":"-"},{"name":"Algeria","_from":"1917","_to":"only","type":"-","in":"Mar","on":"24","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1918","_to":"only","type":"-","in":"Mar","on":"9","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1919","_to":"only","type":"-","in":"Mar","on":"1","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1920","_to":"only","type":"-","in":"Feb","on":"14","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1920","_to":"only","type":"-","in":"Oct","on":"23","at":"23:00s","_save":"0","letter":"-"},{"name":"Algeria","_from":"1921","_to":"only","type":"-","in":"Mar","on":"14","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1921","_to":"only","type":"-","in":"Jun","on":"21","at":"23:00s","_save":"0","letter":"-"},{"name":"Algeria","_from":"1939","_to":"only","type":"-","in":"Sep","on":"11","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1939","_to":"only","type":"-","in":"Nov","on":"19","at":"1:00","_save":"0","letter":"-"},{"name":"Algeria","_from":"1944","_to":"1945","type":"-","in":"Apr","on":"Mon>=1","at":"2:00","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1944","_to":"only","type":"-","in":"Oct","on":"8","at":"2:00","_save":"0","letter":"-"},{"name":"Algeria","_from":"1945","_to":"only","type":"-","in":"Sep","on":"16","at":"1:00","_save":"0","letter":"-"},{"name":"Algeria","_from":"1971","_to":"only","type":"-","in":"Apr","on":"25","at":"23:00s","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1971","_to":"only","type":"-","in":"Sep","on":"26","at":"23:00s","_save":"0","letter":"-"},{"name":"Algeria","_from":"1977","_to":"only","type":"-","in":"May","on":"6","at":"0:00","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1977","_to":"only","type":"-","in":"Oct","on":"21","at":"0:00","_save":"0","letter":"-"},{"name":"Algeria","_from":"1978","_to":"only","type":"-","in":"Mar","on":"24","at":"1:00","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1978","_to":"only","type":"-","in":"Sep","on":"22","at":"3:00","_save":"0","letter":"-"},{"name":"Algeria","_from":"1980","_to":"only","type":"-","in":"Apr","on":"25","at":"0:00","_save":"1:00","letter":"S"},{"name":"Algeria","_from":"1980","_to":"only","type":"-","in":"Oct","on":"31","at":"2:00","_save":"0","letter":"-"}]},
        zones: {"Africa/Algiers":[{"name":"Africa/Algiers","_offset":"0:12:12","_rule":"-","format":"LMT","_until":"1891 Mar 15 0:01"},{"name":"Africa/Algiers","_offset":"0:09:21","_rule":"-","format":"PMT","_until":"1911 Mar 11"},{"name":"Africa/Algiers","_offset":"0:00","_rule":"Algeria","format":"WE%sT","_until":"1940 Feb 25 2:00"},{"name":"Africa/Algiers","_offset":"1:00","_rule":"Algeria","format":"CE%sT","_until":"1946 Oct 7"},{"name":"Africa/Algiers","_offset":"0:00","_rule":"-","format":"WET","_until":"1956 Jan 29"},{"name":"Africa/Algiers","_offset":"1:00","_rule":"-","format":"CET","_until":"1963 Apr 14"},{"name":"Africa/Algiers","_offset":"0:00","_rule":"Algeria","format":"WE%sT","_until":"1977 Oct 21"},{"name":"Africa/Algiers","_offset":"1:00","_rule":"Algeria","format":"CE%sT","_until":"1979 Oct 26"},{"name":"Africa/Algiers","_offset":"0:00","_rule":"Algeria","format":"WE%sT","_until":"1981 May"},{"name":"Africa/Algiers","_offset":"1:00","_rule":"-","format":"CET","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);