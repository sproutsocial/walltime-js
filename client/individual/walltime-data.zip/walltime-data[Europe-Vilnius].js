/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Vilnius].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Vilnius":[{"name":"Europe/Vilnius","_offset":"1:41:16","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Vilnius","_offset":"1:24:00","_rule":"-","format":"WMT","_until":"1917"},{"name":"Europe/Vilnius","_offset":"1:35:36","_rule":"-","format":"KMT","_until":"1919 Oct 10"},{"name":"Europe/Vilnius","_offset":"1:00","_rule":"-","format":"CET","_until":"1920 Jul 12"},{"name":"Europe/Vilnius","_offset":"2:00","_rule":"-","format":"EET","_until":"1920 Oct 9"},{"name":"Europe/Vilnius","_offset":"1:00","_rule":"-","format":"CET","_until":"1940 Aug 3"},{"name":"Europe/Vilnius","_offset":"3:00","_rule":"-","format":"MSK","_until":"1941 Jun 24"},{"name":"Europe/Vilnius","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Aug"},{"name":"Europe/Vilnius","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1991 Mar 31 2:00s"},{"name":"Europe/Vilnius","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"1991 Sep 29 2:00s"},{"name":"Europe/Vilnius","_offset":"2:00","_rule":"C-Eur","format":"EE%sT","_until":"1998"},{"name":"Europe/Vilnius","_offset":"2:00","_rule":"-","format":"EET","_until":"1998 Mar 29 1:00u"},{"name":"Europe/Vilnius","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":"1999 Oct 31 1:00u"},{"name":"Europe/Vilnius","_offset":"2:00","_rule":"-","format":"EET","_until":"2003 Jan 1"},{"name":"Europe/Vilnius","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);