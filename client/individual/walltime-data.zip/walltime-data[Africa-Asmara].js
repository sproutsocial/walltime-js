(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Asmara":[{"name":"Africa/Asmara","_offset":"2:35:32","_rule":"-","format":"LMT","_until":"1870","offset":{"negative":false,"hours":2,"mins":35,"secs":32},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1869-12-31T02:35:31.999Z"}},{"name":"Africa/Asmara","_offset":"2:35:32","_rule":"-","format":"AMT","_until":"1890","offset":{"negative":false,"hours":2,"mins":35,"secs":32},"range":{"begin":"1869-12-31T02:35:32.000Z","end":"1889-12-31T02:35:31.999Z"}},{"name":"Africa/Asmara","_offset":"2:35:20","_rule":"-","format":"ADMT","_until":"1936 May 5","offset":{"negative":false,"hours":2,"mins":35,"secs":20},"range":{"begin":"1889-12-31T02:35:32.000Z","end":"1936-05-05T02:35:19.999Z"}},{"name":"Africa/Asmara","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1936-05-05T02:35:20.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);