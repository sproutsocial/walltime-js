(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Asmara":[{"name":"Africa/Asmara","_offset":"2:35:32","_rule":"-","format":"LMT","_until":"1870"},{"name":"Africa/Asmara","_offset":"2:35:32","_rule":"-","format":"AMT","_until":"1890"},{"name":"Africa/Asmara","_offset":"2:35:20","_rule":"-","format":"ADMT","_until":"1936 May 5"},{"name":"Africa/Asmara","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);