/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Copenhagen].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Copenhagen":[{"name":"Europe/Copenhagen","_offset":"0:50:20","_rule":"-","format":"LMT","_until":"1890"},{"name":"Europe/Copenhagen","_offset":"0:50:20","_rule":"-","format":"CMT","_until":"1894 Jan 1"},{"name":"Europe/Copenhagen","_offset":"1:00","_rule":"Denmark","format":"CE%sT","_until":"1942 Nov 2 2:00s"},{"name":"Europe/Copenhagen","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945 Apr 2 2:00"},{"name":"Europe/Copenhagen","_offset":"1:00","_rule":"Denmark","format":"CE%sT","_until":"1980"},{"name":"Europe/Copenhagen","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);