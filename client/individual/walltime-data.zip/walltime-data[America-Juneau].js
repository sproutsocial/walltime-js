/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Juneau].js
    
    var tzData = {
        rules: {},
        zones: {"America/Juneau":[{"name":"America/Juneau","_offset":"15:02:19","_rule":"-","format":"LMT","_until":"1867 Oct 18"},{"name":"America/Juneau","_offset":"-8:57:41","_rule":"-","format":"LMT","_until":"1900 Aug 20 12:00"},{"name":"America/Juneau","_offset":"-8:00","_rule":"-","format":"PST","_until":"1942"},{"name":"America/Juneau","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1946"},{"name":"America/Juneau","_offset":"-8:00","_rule":"-","format":"PST","_until":"1969"},{"name":"America/Juneau","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1980 Apr 27 2:00"},{"name":"America/Juneau","_offset":"-9:00","_rule":"US","format":"Y%sT","_until":"1980 Oct 26 2:00"},{"name":"America/Juneau","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1983 Oct 30 2:00"},{"name":"America/Juneau","_offset":"-9:00","_rule":"US","format":"Y%sT","_until":"1983 Nov 30"},{"name":"America/Juneau","_offset":"-9:00","_rule":"US","format":"AK%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);