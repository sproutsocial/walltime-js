/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Muscat].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Muscat":[{"name":"Asia/Muscat","_offset":"3:54:24","_rule":"-","format":"LMT","_until":"1920"},{"name":"Asia/Muscat","_offset":"4:00","_rule":"-","format":"GST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);