(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Asia/Muscat":[{"name":"Asia/Muscat","_offset":"3:54:20","_rule":"-","format":"LMT","_until":"1920","offset":{"negative":false,"hours":3,"mins":54,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1919-12-31T03:54:19.999Z"}},{"name":"Asia/Muscat","_offset":"4:00","_rule":"-","format":"GST","_until":"","offset":{"negative":false,"hours":4,"mins":0,"secs":0},"range":{"begin":"1919-12-31T03:54:20.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);