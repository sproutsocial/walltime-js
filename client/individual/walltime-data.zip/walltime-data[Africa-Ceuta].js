/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Africa-Ceuta].js
    
    var tzData = {
        rules: {},
        zones: {"Africa/Ceuta":[{"name":"Africa/Ceuta","_offset":"-0:21:16","_rule":"-","format":"LMT","_until":"1901"},{"name":"Africa/Ceuta","_offset":"0:00","_rule":"-","format":"WET","_until":"1918 May 6 23:00"},{"name":"Africa/Ceuta","_offset":"0:00","_rule":"1:00","format":"WEST","_until":"1918 Oct 7 23:00"},{"name":"Africa/Ceuta","_offset":"0:00","_rule":"-","format":"WET","_until":"1924"},{"name":"Africa/Ceuta","_offset":"0:00","_rule":"Spain","format":"WE%sT","_until":"1929"},{"name":"Africa/Ceuta","_offset":"0:00","_rule":"SpainAfrica","format":"WE%sT","_until":"1984 Mar 16"},{"name":"Africa/Ceuta","_offset":"1:00","_rule":"-","format":"CET","_until":"1986"},{"name":"Africa/Ceuta","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);