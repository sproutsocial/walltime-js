(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Dar_es_Salaam":[{"name":"Africa/Dar_es_Salaam","_offset":"2:37:08","_rule":"-","format":"LMT","_until":"1931","offset":{"negative":false,"hours":2,"mins":37,"secs":8},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1930-12-31T02:37:07.999Z"}},{"name":"Africa/Dar_es_Salaam","_offset":"3:00","_rule":"-","format":"EAT","_until":"1948","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1930-12-31T02:37:08.000Z","end":"1947-12-31T02:59:59.999Z"}},{"name":"Africa/Dar_es_Salaam","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1961","offset":{"negative":false,"hours":2,"mins":45,"secs":0},"range":{"begin":"1947-12-31T03:00:00.000Z","end":"1960-12-31T02:44:59.999Z"}},{"name":"Africa/Dar_es_Salaam","_offset":"3:00","_rule":"-","format":"EAT","_until":"","offset":{"negative":false,"hours":3,"mins":0,"secs":0},"range":{"begin":"1960-12-31T02:45:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);