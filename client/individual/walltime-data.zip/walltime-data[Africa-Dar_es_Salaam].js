(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Dar_es_Salaam":[{"name":"Africa/Dar_es_Salaam","_offset":"2:37:08","_rule":"-","format":"LMT","_until":"1931"},{"name":"Africa/Dar_es_Salaam","_offset":"3:00","_rule":"-","format":"EAT","_until":"1948"},{"name":"Africa/Dar_es_Salaam","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1961"},{"name":"Africa/Dar_es_Salaam","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);