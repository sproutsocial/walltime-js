/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Africa/Dar_es_Salaam":[{"name":"Africa/Dar_es_Salaam","_offset":"2:37:08","_rule":"-","format":"LMT","_until":"1931"},{"name":"Africa/Dar_es_Salaam","_offset":"3:00","_rule":"-","format":"EAT","_until":"1948"},{"name":"Africa/Dar_es_Salaam","_offset":"2:45","_rule":"-","format":"BEAUT","_until":"1961"},{"name":"Africa/Dar_es_Salaam","_offset":"3:00","_rule":"-","format":"EAT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);