/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Tallinn].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Tallinn":[{"name":"Europe/Tallinn","_offset":"1:39:00","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Tallinn","_offset":"1:39:00","_rule":"-","format":"TMT","_until":"1918 Feb"},{"name":"Europe/Tallinn","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1919 Jul"},{"name":"Europe/Tallinn","_offset":"1:39:00","_rule":"-","format":"TMT","_until":"1921 May"},{"name":"Europe/Tallinn","_offset":"2:00","_rule":"-","format":"EET","_until":"1940 Aug 6"},{"name":"Europe/Tallinn","_offset":"3:00","_rule":"-","format":"MSK","_until":"1941 Sep 15"},{"name":"Europe/Tallinn","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1944 Sep 22"},{"name":"Europe/Tallinn","_offset":"3:00","_rule":"Russia","format":"MSK/MSD","_until":"1989 Mar 26 2:00s"},{"name":"Europe/Tallinn","_offset":"2:00","_rule":"1:00","format":"EEST","_until":"1989 Sep 24 2:00s"},{"name":"Europe/Tallinn","_offset":"2:00","_rule":"C-Eur","format":"EE%sT","_until":"1998 Sep 22"},{"name":"Europe/Tallinn","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":"1999 Nov 1"},{"name":"Europe/Tallinn","_offset":"2:00","_rule":"-","format":"EET","_until":"2002 Feb 21"},{"name":"Europe/Tallinn","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);