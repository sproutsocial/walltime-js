(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Kinshasa":[{"name":"Africa/Kinshasa","_offset":"1:01:12","_rule":"-","format":"LMT","_until":"1897 Nov 9","offset":{"negative":false,"hours":1,"mins":1,"secs":12},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1897-11-09T01:01:11.999Z"}},{"name":"Africa/Kinshasa","_offset":"1:00","_rule":"-","format":"WAT","_until":"","offset":{"negative":false,"hours":1,"mins":0,"secs":0},"range":{"begin":"1897-11-09T01:01:12.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);