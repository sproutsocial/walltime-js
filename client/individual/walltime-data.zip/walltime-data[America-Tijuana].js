/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Tijuana].js
    
    var tzData = {
        rules: {},
        zones: {"America/Tijuana":[{"name":"America/Tijuana","_offset":"-7:48:04","_rule":"-","format":"LMT","_until":"1922 Jan 1 0:11:56"},{"name":"America/Tijuana","_offset":"-7:00","_rule":"-","format":"MST","_until":"1924"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"-","format":"PST","_until":"1927 Jun 10 23:00"},{"name":"America/Tijuana","_offset":"-7:00","_rule":"-","format":"MST","_until":"1930 Nov 15"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"-","format":"PST","_until":"1931 Apr 1"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"1:00","format":"PDT","_until":"1931 Sep 30"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"-","format":"PST","_until":"1942 Apr 24"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"1:00","format":"PWT","_until":"1945 Aug 14 23:00u"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"1:00","format":"PPT","_until":"1945 Nov 12"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"-","format":"PST","_until":"1948 Apr 5"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"1:00","format":"PDT","_until":"1949 Jan 14"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"-","format":"PST","_until":"1954"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"CA","format":"P%sT","_until":"1961"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"-","format":"PST","_until":"1976"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1996"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"Mexico","format":"P%sT","_until":"2001"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"2002 Feb 20"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"Mexico","format":"P%sT","_until":"2010"},{"name":"America/Tijuana","_offset":"-8:00","_rule":"US","format":"P%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);