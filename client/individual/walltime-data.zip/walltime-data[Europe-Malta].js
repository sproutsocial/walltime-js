/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Malta].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Malta":[{"name":"Europe/Malta","_offset":"0:58:04","_rule":"-","format":"LMT","_until":"1893 Nov 2 0:00s"},{"name":"Europe/Malta","_offset":"1:00","_rule":"Italy","format":"CE%sT","_until":"1942 Nov 2 2:00s"},{"name":"Europe/Malta","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945 Apr 2 2:00s"},{"name":"Europe/Malta","_offset":"1:00","_rule":"Italy","format":"CE%sT","_until":"1973 Mar 31"},{"name":"Europe/Malta","_offset":"1:00","_rule":"Malta","format":"CE%sT","_until":"1981"},{"name":"Europe/Malta","_offset":"1:00","_rule":"EU","format":"CE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);