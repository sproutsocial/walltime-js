/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Europe-Sofia].js
    
    var tzData = {
        rules: {},
        zones: {"Europe/Sofia":[{"name":"Europe/Sofia","_offset":"1:33:16","_rule":"-","format":"LMT","_until":"1880"},{"name":"Europe/Sofia","_offset":"1:56:56","_rule":"-","format":"IMT","_until":"1894 Nov 30"},{"name":"Europe/Sofia","_offset":"2:00","_rule":"-","format":"EET","_until":"1942 Nov 2 3:00"},{"name":"Europe/Sofia","_offset":"1:00","_rule":"C-Eur","format":"CE%sT","_until":"1945"},{"name":"Europe/Sofia","_offset":"1:00","_rule":"-","format":"CET","_until":"1945 Apr 2 3:00"},{"name":"Europe/Sofia","_offset":"2:00","_rule":"-","format":"EET","_until":"1979 Mar 31 23:00"},{"name":"Europe/Sofia","_offset":"2:00","_rule":"Bulg","format":"EE%sT","_until":"1982 Sep 26 2:00"},{"name":"Europe/Sofia","_offset":"2:00","_rule":"C-Eur","format":"EE%sT","_until":"1991"},{"name":"Europe/Sofia","_offset":"2:00","_rule":"E-Eur","format":"EE%sT","_until":"1997"},{"name":"Europe/Sofia","_offset":"2:00","_rule":"EU","format":"EE%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);