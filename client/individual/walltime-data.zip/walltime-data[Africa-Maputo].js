(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Maputo":[{"name":"Africa/Maputo","_offset":"2:10:20","_rule":"-","format":"LMT","_until":"1903 Mar","offset":{"negative":false,"hours":2,"mins":10,"secs":20},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1903-02-28T02:10:19.999Z"}},{"name":"Africa/Maputo","_offset":"2:00","_rule":"-","format":"CAT","_until":"","offset":{"negative":false,"hours":2,"mins":0,"secs":0},"range":{"begin":"1903-02-28T02:10:20.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);