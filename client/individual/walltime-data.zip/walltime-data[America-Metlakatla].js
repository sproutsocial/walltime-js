/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Metlakatla].js
    
    var tzData = {
        rules: {},
        zones: {"America/Metlakatla":[{"name":"America/Metlakatla","_offset":"15:13:42","_rule":"-","format":"LMT","_until":"1867 Oct 18"},{"name":"America/Metlakatla","_offset":"-8:46:18","_rule":"-","format":"LMT","_until":"1900 Aug 20 12:00"},{"name":"America/Metlakatla","_offset":"-8:00","_rule":"-","format":"PST","_until":"1942"},{"name":"America/Metlakatla","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1946"},{"name":"America/Metlakatla","_offset":"-8:00","_rule":"-","format":"PST","_until":"1969"},{"name":"America/Metlakatla","_offset":"-8:00","_rule":"US","format":"P%sT","_until":"1983 Oct 30 2:00"},{"name":"America/Metlakatla","_offset":"-8:00","_rule":"-","format":"MeST","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);