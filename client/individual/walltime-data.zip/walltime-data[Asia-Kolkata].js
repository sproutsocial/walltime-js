/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Asia/Kolkata":[{"name":"Asia/Kolkata","_offset":"5:53:28","_rule":"-","format":"LMT","_until":"1880"},{"name":"Asia/Kolkata","_offset":"5:53:20","_rule":"-","format":"HMT","_until":"1941 Oct"},{"name":"Asia/Kolkata","_offset":"6:30","_rule":"-","format":"BURT","_until":"1942 May 15"},{"name":"Asia/Kolkata","_offset":"5:30","_rule":"-","format":"IST","_until":"1942 Sep"},{"name":"Asia/Kolkata","_offset":"5:30","_rule":"1:00","format":"IST","_until":"1945 Oct 15"},{"name":"Asia/Kolkata","_offset":"5:30","_rule":"-","format":"IST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);