/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Baghdad].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Baghdad":[{"name":"Asia/Baghdad","_offset":"2:57:40","_rule":"-","format":"LMT","_until":"1890"},{"name":"Asia/Baghdad","_offset":"2:57:36","_rule":"-","format":"BMT","_until":"1918"},{"name":"Asia/Baghdad","_offset":"3:00","_rule":"-","format":"AST","_until":"1982 May"},{"name":"Asia/Baghdad","_offset":"3:00","_rule":"Iraq","format":"A%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);