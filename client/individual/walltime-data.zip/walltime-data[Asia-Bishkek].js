/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Asia-Bishkek].js
    
    var tzData = {
        rules: {},
        zones: {"Asia/Bishkek":[{"name":"Asia/Bishkek","_offset":"4:58:24","_rule":"-","format":"LMT","_until":"1924 May 2"},{"name":"Asia/Bishkek","_offset":"5:00","_rule":"-","format":"FRUT","_until":"1930 Jun 21"},{"name":"Asia/Bishkek","_offset":"6:00","_rule":"RussiaAsia","format":"FRU%sT","_until":"1991 Mar 31 2:00s"},{"name":"Asia/Bishkek","_offset":"5:00","_rule":"1:00","format":"FRUST","_until":"1991 Aug 31 2:00"},{"name":"Asia/Bishkek","_offset":"5:00","_rule":"Kyrgyz","format":"KG%sT","_until":"2005 Aug 12"},{"name":"Asia/Bishkek","_offset":"6:00","_rule":"-","format":"KGT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);