/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"HST":[{"name":"HST","_offset":"-10:00","_rule":"-","format":"HST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);