/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[America-Bahia_Banderas].js
    
    var tzData = {
        rules: {},
        zones: {"America/Bahia_Banderas":[{"name":"America/Bahia_Banderas","_offset":"-7:01:00","_rule":"-","format":"LMT","_until":"1921 Dec 31 23:59:00"},{"name":"America/Bahia_Banderas","_offset":"-7:00","_rule":"-","format":"MST","_until":"1927 Jun 10 23:00"},{"name":"America/Bahia_Banderas","_offset":"-6:00","_rule":"-","format":"CST","_until":"1930 Nov 15"},{"name":"America/Bahia_Banderas","_offset":"-7:00","_rule":"-","format":"MST","_until":"1931 May 1 23:00"},{"name":"America/Bahia_Banderas","_offset":"-6:00","_rule":"-","format":"CST","_until":"1931 Oct"},{"name":"America/Bahia_Banderas","_offset":"-7:00","_rule":"-","format":"MST","_until":"1932 Apr 1"},{"name":"America/Bahia_Banderas","_offset":"-6:00","_rule":"-","format":"CST","_until":"1942 Apr 24"},{"name":"America/Bahia_Banderas","_offset":"-7:00","_rule":"-","format":"MST","_until":"1949 Jan 14"},{"name":"America/Bahia_Banderas","_offset":"-8:00","_rule":"-","format":"PST","_until":"1970"},{"name":"America/Bahia_Banderas","_offset":"-7:00","_rule":"Mexico","format":"M%sT","_until":"2010 Apr 4 2:00"},{"name":"America/Bahia_Banderas","_offset":"-6:00","_rule":"Mexico","format":"C%sT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);