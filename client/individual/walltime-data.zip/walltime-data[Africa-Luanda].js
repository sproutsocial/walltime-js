(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Luanda":[{"name":"Africa/Luanda","_offset":"0:52:56","_rule":"-","format":"LMT","_until":"1892"},{"name":"Africa/Luanda","_offset":"0:52:04","_rule":"-","format":"AOT","_until":"1911 May 26"},{"name":"Africa/Luanda","_offset":"1:00","_rule":"-","format":"WAT","_until":""}]}
      };
      window.WallTime.autoinit = true;
}).call(this);