(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Africa/Luanda":[{"name":"Africa/Luanda","_offset":"0:52:56","_rule":"-","format":"LMT","_until":"1892","offset":{"negative":false,"hours":0,"mins":52,"secs":56},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1891-12-31T00:52:55.999Z"}},{"name":"Africa/Luanda","_offset":"0:52:04","_rule":"-","format":"AOT","_until":"1911 May 26","offset":{"negative":false,"hours":0,"mins":52,"secs":4},"range":{"begin":"1891-12-31T00:52:56.000Z","end":"1911-05-26T00:52:03.999Z"}},{"name":"Africa/Luanda","_offset":"1:00","_rule":"-","format":"WAT","_until":"","offset":{"negative":false,"hours":1,"mins":0,"secs":0},"range":{"begin":"1911-05-26T00:52:04.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);