/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Mawson":[{"name":"Antarctica/Mawson","_offset":"0","_rule":"-","format":"zzz","_until":"1954 Feb 13"},{"name":"Antarctica/Mawson","_offset":"6:00","_rule":"-","format":"MAWT","_until":"2009 Oct 18 2:00"},{"name":"Antarctica/Mawson","_offset":"5:00","_rule":"-","format":"MAWT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);