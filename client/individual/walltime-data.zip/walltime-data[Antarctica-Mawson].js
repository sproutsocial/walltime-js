(function() {
      window.WallTime || (window.WallTime = {});
      window.WallTime.data = {
        rules: {},
        zones: {"Antarctica/Mawson":[{"name":"Antarctica/Mawson","_offset":"0","_rule":"-","format":"zzz","_until":"1954 Feb 13","offset":{"negative":null,"hours":0,"mins":0,"secs":0},"range":{"begin":"-025410-12-06T00:00:00.000Z","end":"1954-02-12T23:59:59.999Z"}},{"name":"Antarctica/Mawson","_offset":"6:00","_rule":"-","format":"MAWT","_until":"2009 Oct 18 2:00","offset":{"negative":false,"hours":6,"mins":0,"secs":0},"range":{"begin":"1954-02-13T00:00:00.000Z","end":"2009-10-18T07:59:59.999Z"}},{"name":"Antarctica/Mawson","_offset":"5:00","_rule":"-","format":"MAWT","_until":"","offset":{"negative":false,"hours":5,"mins":0,"secs":0},"range":{"begin":"2009-10-18T08:00:00.000Z","end":"+029349-01-26T00:00:00.000Z"}}]}
      };
      window.WallTime.autoinit = true;
}).call(this);