/*
 *  WallTime 0.1.1
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Antarctica-Mawson].js
    
    var tzData = {
        rules: {},
        zones: {"Antarctica/Mawson":[{"name":"Antarctica/Mawson","_offset":"0","_rule":"-","format":"zzz","_until":"1954 Feb 13"},{"name":"Antarctica/Mawson","_offset":"6:00","_rule":"-","format":"MAWT","_until":"2009 Oct 18 2:00"},{"name":"Antarctica/Mawson","_offset":"5:00","_rule":"-","format":"MAWT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);