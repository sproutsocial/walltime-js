/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {"LH":[{"name":"LH","_from":"1981","_to":"1984","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"1:00","letter":"-"},{"name":"LH","_from":"1982","_to":"1985","type":"-","in":"Mar","on":"Sun>=1","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"1985","_to":"only","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0:30","letter":"-"},{"name":"LH","_from":"1986","_to":"1989","type":"-","in":"Mar","on":"Sun>=15","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"1986","_to":"only","type":"-","in":"Oct","on":"19","at":"2:00","_save":"0:30","letter":"-"},{"name":"LH","_from":"1987","_to":"1999","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0:30","letter":"-"},{"name":"LH","_from":"1990","_to":"1995","type":"-","in":"Mar","on":"Sun>=1","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"1996","_to":"2005","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"2000","_to":"only","type":"-","in":"Aug","on":"lastSun","at":"2:00","_save":"0:30","letter":"-"},{"name":"LH","_from":"2001","_to":"2007","type":"-","in":"Oct","on":"lastSun","at":"2:00","_save":"0:30","letter":"-"},{"name":"LH","_from":"2006","_to":"only","type":"-","in":"Apr","on":"Sun>=1","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"2007","_to":"only","type":"-","in":"Mar","on":"lastSun","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"2008","_to":"max","type":"-","in":"Apr","on":"Sun>=1","at":"2:00","_save":"0","letter":"-"},{"name":"LH","_from":"2008","_to":"max","type":"-","in":"Oct","on":"Sun>=1","at":"2:00","_save":"0:30","letter":"-"}]},
        zones: {"Australia/Lord_Howe":[{"name":"Australia/Lord_Howe","_offset":"10:36:20","_rule":"-","format":"LMT","_until":"1895 Feb"},{"name":"Australia/Lord_Howe","_offset":"10:00","_rule":"-","format":"EST","_until":"1981 Mar"},{"name":"Australia/Lord_Howe","_offset":"10:30","_rule":"LH","format":"LHST","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);