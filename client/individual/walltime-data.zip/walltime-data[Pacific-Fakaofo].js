/*
 *  WallTime 0.1.2
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (http://bit.ly/walltime-license)
 */
 (function () {
    "use strict";
    // walltime-data[Pacific-Fakaofo].js
    
    var tzData = {
        rules: {},
        zones: {"Pacific/Fakaofo":[{"name":"Pacific/Fakaofo","_offset":"-11:24:56","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Fakaofo","_offset":"-11:00","_rule":"-","format":"TKT","_until":"2011 Dec 30"},{"name":"Pacific/Fakaofo","_offset":"13:00","_rule":"-","format":"TKT","_until":""}]}
    };

    if (typeof window == 'undefined') {
        module.exports = tzData;
    } else if (typeof define != 'undefined') {
        define("walltime-data", [], function () {
            return tzData;
        });
    } else {
        this.WallTime || (this.WallTime = {});
        this.WallTime.data = tzData;
        this.WallTime.autoinit = true;
    }
}).call(this);