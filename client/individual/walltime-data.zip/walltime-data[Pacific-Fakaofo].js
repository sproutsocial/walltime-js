/*
 *  WallTime 0.0.16
 *  Copyright (c) 2013 Sprout Social, Inc.
 *  Available under the MIT License (https://github.com/sproutsocial/walltime-js/blob/master/LICENSE)
 */
 (function() {
      this.WallTime || (this.WallTime = {});
      this.WallTime.data = {
        rules: {},
        zones: {"Pacific/Fakaofo":[{"name":"Pacific/Fakaofo","_offset":"-11:24:56","_rule":"-","format":"LMT","_until":"1901"},{"name":"Pacific/Fakaofo","_offset":"-11:00","_rule":"-","format":"TKT","_until":"2011 Dec 30"},{"name":"Pacific/Fakaofo","_offset":"13:00","_rule":"-","format":"TKT","_until":""}]}
      };
      this.WallTime.autoinit = true;
}).call(this);